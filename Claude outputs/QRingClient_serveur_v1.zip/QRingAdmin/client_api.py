"""
QRingClient API — service de l'app téléphone QRingClient (Flutter).

Indépendant de QRing Admin (Flask) : ce service a son propre process pm2.
- Se connecte lui-même à Mosquitto : état des bagues en temps réel (flux SSE vers l'app)
- Lit PostgreSQL : comptes, droits, historique (QRing Admin reste celui qui ENREGISTRE les mesures)
- Envoie les mesures demandées par l'app sur eis/colmi/<MAC>/cmd (reqId « app-… »),
  même règle que l'admin et le bot : une seule mesure à la fois par bague
- Alertes (retirée, hors portée, TV hors ligne, batterie faible) : liste dans l'app,
  flux en direct et notifications Firebase (FCM) même app fermée

Lancement :  pm2 start client_api.py --name qring-client-api --interpreter ./venv/bin/python
Configuration : le même .env que QRing Admin et le bot (voir .env.example, section QRingClient).
"""
import json
import logging
import os
import queue
import re
import threading
import time
import uuid
from functools import wraps
from pathlib import Path

from dotenv import load_dotenv

# ---------------------------------------------------------------------------- .env (avant dbq)
HERE = Path(__file__).resolve().parent
for candidate in [os.getenv("QRING_ENV_FILE"), HERE / ".env", HERE.parent / ".env"]:
    if candidate and Path(candidate).is_file():
        load_dotenv(candidate, override=False)


def _env_number(name, default, cast, pattern):
    raw = os.getenv(name)
    if raw is None or not str(raw).strip():
        raw = default
    m = re.search(pattern, str(raw))
    if not m:
        m = re.search(pattern, str(default))
    return cast(m.group(0).replace(",", "."))


def env_int(name, default):
    return _env_number(name, default, int, r"-?\d+")


def env_float(name, default):
    return _env_number(name, default, float, r"-?\d+(?:[.,]\d+)?")


import paho.mqtt.client as mqtt  # noqa: E402
from flask import Flask, Response, g, jsonify, request  # noqa: E402
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer  # noqa: E402

import clientdb  # noqa: E402
import dbq  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("qring.client")

MQTT_HOST = os.getenv("MQTT_HOST", "51.83.40.138")
MQTT_PORT = env_int("MQTT_PORT", "1883")
MQTT_USER = os.getenv("MQTT_USER", "")
MQTT_PASS = os.getenv("MQTT_PASSWORD", os.getenv("MQTT_PASS", ""))
PREFIX = (os.getenv("MQTT_PREFIX") or os.getenv("MQTT_TOPIC", "eis/colmi/#")).replace("#", "").strip("/")
OFFLINE_AFTER = env_int("QRING_OFFLINE_AFTER", "150")

PORT = env_int("CLIENT_API_PORT", "5060")
TOKEN_DAYS = max(1, env_int("CLIENT_TOKEN_DAYS", "30"))
ALERT_CONFIRM = max(0, env_int("CLIENT_ALERT_CONFIRM_SECONDS", os.getenv("TELEGRAM_ALERT_CONFIRM_SECONDS") or "60"))
BATTERY_LOW = env_int("CLIENT_ALERT_BATTERY_LOW", os.getenv("TELEGRAM_ALERT_BATTERY_LOW") or "20")
WEAR_CHECK_SECONDS = max(5, env_int("TELEGRAM_WEAR_CHECK_SECONDS", "15"))
FCM_FILE = os.getenv("FCM_SERVICE_ACCOUNT_FILE", "").strip()
# HTTPS direct (sinon mettre le service derrière Nginx en HTTPS) : chemins du certificat et de la clé
SSL_CERT = os.getenv("CLIENT_API_SSL_CERT", "").strip()
SSL_KEY = os.getenv("CLIENT_API_SSL_KEY", "").strip()

SECRET = (os.getenv("CLIENT_API_SECRET") or os.getenv("QRING_SECRET_KEY") or "").strip()
if not SECRET:
    SECRET = uuid.uuid4().hex + uuid.uuid4().hex
    log.warning("CLIENT_API_SECRET absent du .env : clé temporaire, les téléphones devront se reconnecter "
                "à chaque redémarrage du service.")
signer = URLSafeTimedSerializer(SECRET, salt="qringclient-v1")

MEASURES = ["hr", "spo2", "temp", "bp", "hrv", "stress", "all"]
# Mesures proposées par défaut (allowed_measures NULL) : la tension n'existe pas sur toutes les bagues
DEFAULT_MEASURES = ["hr", "spo2", "temp", "hrv", "stress", "steps"]
LIMITS = {"hr": 60, "spo2": 90, "temp": 60, "bp": 60, "hrv": 60, "stress": 60, "steps": 30, "all": 90}
DB_METRIC = {"hr": "heart_rate", "spo2": "spo2", "temp": "temperature", "bp": "blood_pressure",
             "hrv": "hrv", "stress": "stress", "steps": "steps", "battery": "battery"}
APP_TYPE = {v: k for k, v in DB_METRIC.items()}

app = Flask(__name__)


def now():
    return int(time.time())


# ============================================================================ état des bagues (MQTT)

lock = threading.RLock()
rings = {}        # mac -> état en direct
gateways = {}     # nom -> {"online", "statusTs"}
ring_ids = {}     # mac -> rings.id en base


def new_ring(mac):
    return {"mac": mac, "name": "", "model": "", "firmware": "", "gateway": "", "deviceName": "",
            "online": False, "ring": "unknown", "worn": None, "battery": None, "charging": False,
            "statusTs": 0, "pending": {}, "errors": {}, "values": {}}


def mac_from_topic(t):
    t = t.upper()
    return ":".join(t[i:i + 2] for i in range(0, 12, 2)) if len(t) == 12 else t


def topic_mac(mac):
    return mac.replace(":", "").replace("-", "").upper()


def mac_from_key(key):
    k = re.sub(r"[^0-9a-fA-F]", "", str(key or "")).upper()
    return ":".join(k[i:i + 2] for i in range(0, 12, 2)) if len(k) == 12 else None


def seed_from_db():
    try:
        rows = dbq.load_rings()
    except Exception as e:
        log.warning("Bagues PostgreSQL non chargées : %s", e)
        return
    with lock:
        for row in rows:
            mac = row["mac"].upper()
            ring_ids[mac] = row["id"]
            r = rings.setdefault(mac, new_ring(mac))
            r.update({"name": row["name"] or "", "model": row["model"] or "", "firmware": row["fw_version"] or "",
                      "gateway": row["gateway"] or "", "charging": bool(row["charging"]),
                      "battery": int(row["battery"]) if row["battery"] is not None else None,
                      "worn": True if row["wear_status"] == "worn" else False if row["wear_status"] == "removed" else None,
                      "statusTs": 0})
            for m in row["latest"]:
                typ = APP_TYPE.get(m["metric"])
                if not typ:
                    continue
                ex = m["extra"] or {}
                data = {"value": m["value"]}
                if typ == "bp":
                    data = {"sbp": ex.get("sbp", m["value"]), "dbp": ex.get("dbp")}
                if typ == "steps":
                    data = {"steps": int(m["value"] or 0)}
                r["values"][typ] = {"ts": int(m["time"].timestamp()), "data": data,
                                    "dur": ex.get("duration_s"), "source": ex.get("origin") or "db"}
    log.info("%d bague(s) chargée(s) depuis PostgreSQL", len(rows))


def ring_id(mac):
    rid = ring_ids.get(mac)
    if rid is None:
        try:
            rid = clientdb.ring_id_by_mac(mac)
        except Exception:
            rid = None
        if rid is not None:
            ring_ids[mac] = rid
    return rid


def on_connect(client, userdata, flags, reason_code, properties=None):
    if reason_code == 0 or str(reason_code) == "Success":
        client.subscribe(f"{PREFIX}/#", qos=1)
        log.info("Connecté au broker %s:%d", MQTT_HOST, MQTT_PORT)
    else:
        log.error("Connexion broker refusée : %s", reason_code)


def on_message(client, userdata, msg):
    try:
        p = json.loads(msg.payload.decode("utf-8"))
    except Exception:
        return
    if not isinstance(p, dict):
        return
    parts = msg.topic.split("/")
    base = PREFIX.split("/")
    if parts[: len(base)] != base:
        return
    rest = parts[len(base):]
    try:
        if len(rest) >= 3 and rest[0] == "gateway":
            if rest[2] == "status":
                with lock:
                    gateways[rest[1]] = {"online": bool(p.get("online")), "statusTs": now()}
        elif len(rest) == 2 and len(rest[0]) == 12:
            handle_ring(mac_from_topic(rest[0]), rest[1], p)
    except Exception:
        log.exception("message %s", msg.topic)


def handle_ring(mac, sub, p):
    with lock:
        r = rings.setdefault(mac, new_ring(mac))
        if sub == "cmd":
            # Commande d'un autre lanceur (admin, bot, Web App) : la bague devient occupée
            cmd = p.get("cmd")
            if cmd in MEASURES and cmd not in r["pending"]:
                r["pending"][cmd] = {"since": now(), "requested": now(), "reqId": p.get("reqId"), "confirmed": False}
                r["errors"].pop(cmd, None)
            else:
                return
        else:
            r["gateway"] = p.get("gateway") or r["gateway"]
            if p.get("ringModel"):
                r["model"] = p["ringModel"]
            if sub == "status":
                r.update({"online": bool(p.get("online")), "ring": p.get("ring", r["ring"]),
                          "name": r["name"] or p.get("ringName") or "", "firmware": p.get("firmware") or r["firmware"],
                          "battery": p.get("battery", r["battery"]), "charging": bool(p.get("charging")),
                          "worn": p.get("worn", r["worn"]), "deviceName": p.get("deviceName") or r["deviceName"],
                          "statusTs": now()})
            else:
                handle_result(r, sub, p)
        snapshot = json.loads(json.dumps(r, default=str))
    alerts.observe(mac, snapshot)
    push_ring(mac)


def handle_result(r, sub, p):
    st = p.get("status")
    if st in ("measuring", "searching"):
        old = r["pending"].get(sub) or {}
        r["pending"][sub] = {"since": now(), "requested": old.get("requested") or now(),
                             "reqId": p.get("reqId") or old.get("reqId"), "confirmed": True}
        r["errors"].pop(sub, None)
        return
    pnd = r["pending"].pop(sub, None) or {}
    ts = p.get("ts") or now()
    started = pnd.get("since") or pnd.get("requested")
    dur = max(0, now() - started) if started else None
    if st == "ok":
        data = {k: v for k, v in p.items() if k not in (
            "reqId", "type", "status", "source", "ringMac", "ringModel", "gateway", "ts")}
        meta = {"ts": ts, "dur": dur, "source": p.get("source")}
        r["values"][sub] = dict(meta, data=data)
        r["errors"].pop(sub, None)
        if sub == "all":
            for k in ("hr", "spo2", "temp", "hrv", "stress"):
                if k in data:
                    r["values"][k] = dict(meta, data={"value": data[k]})
            if "sbp" in data:
                r["values"]["bp"] = dict(meta, data={"sbp": data["sbp"], "dbp": data.get("dbp")})
        if sub == "battery":
            r["battery"] = data.get("value", r["battery"])
            r["charging"] = bool(data.get("charging"))
        if sub in MEASURES:
            r["worn"] = True
    elif st == "error":
        err = p.get("error", "error")
        r["errors"][sub] = {"ts": ts, "code": err, "dur": dur}
        if err == "ring_removed":
            r["worn"] = False


mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"qring-client-api-{uuid.uuid4().hex[:8]}")


def start_mqtt():
    mqttc.on_connect = on_connect
    mqttc.on_message = on_message
    if MQTT_USER:
        mqttc.username_pw_set(MQTT_USER, MQTT_PASS)
    mqttc.reconnect_delay_set(min_delay=1, max_delay=30)
    mqttc.connect_async(MQTT_HOST, MQTT_PORT, keepalive=30)
    mqttc.loop_start()


def gateway_online(r):
    """TV en ligne : statut récent (moins de QRING_OFFLINE_AFTER secondes)."""
    return bool(r["online"] and r["statusTs"] and now() - r["statusTs"] <= OFFLINE_AFTER)


def live_state(mac, acc=None):
    """État en direct pour l'app, filtré selon les droits du compte."""
    with lock:
        r = rings.get(mac)
        r = json.loads(json.dumps(r, default=str)) if r else new_ring(mac)
    visible = set(visible_measures(acc)) | {"battery"} if acc else None
    vals = r["values"]
    if visible is not None:
        vals = {k: v for k, v in vals.items() if k in visible}
    return {"online": gateway_online(r), "ring": r["ring"], "worn": r["worn"], "battery": r["battery"],
            "charging": r["charging"], "gateway": r["gateway"], "deviceName": r["deviceName"],
            "model": r["model"], "firmware": r["firmware"], "statusTs": r["statusTs"],
            "pending": {k: {"since": v.get("since"), "requested": v.get("requested"), "confirmed": v.get("confirmed")}
                        for k, v in r["pending"].items()},
            "errors": r["errors"], "values": vals, "now": now()}


# ============================================================================ droits

def visible_measures(acc):
    allowed = acc.get("allowed_measures")
    return list(allowed) if allowed else list(DEFAULT_MEASURES)


def rights(acc):
    vis = visible_measures(acc)
    return {"history": bool(acc["can_view_history"]), "live": bool(acc["can_live"]),
            "measures": vis if acc["can_live"] else [], "visible": vis,
            "alerts": bool(acc["can_receive_alerts"])}


def ring_payload(acc, with_live=True):
    mac = acc["mac"].upper()
    out = {"mac": mac, "key": topic_mac(mac).lower(), "label": acc["label"] or acc["ring_name"] or mac,
           "name": acc["ring_name"] or "", "model": acc["model"] or "", "rights": rights(acc),
           "notify": bool(acc["notify"])}
    if with_live:
        out["live"] = live_state(mac, acc)
    return out


# ============================================================================ authentification

def make_token(user):
    return signer.dumps({"u": int(user["id"]), "v": int(user["token_version"])})


def ok(**kw):
    return jsonify(dict(ok=True, **kw))


def fail(msg, code=400, **kw):
    return jsonify(dict(ok=False, error=str(msg), **kw)), code


def user_from_token(token):
    if not token:
        return None
    try:
        data = signer.loads(token, max_age=TOKEN_DAYS * 86400)
    except (BadSignature, SignatureExpired):
        return None
    user = clientdb.get_user(data.get("u"))
    if not user or not user["active"] or int(user["token_version"]) != int(data.get("v", -1)):
        return None
    return user


def auth_required(f):
    @wraps(f)
    def w(*a, **k):
        h = request.headers.get("Authorization", "")
        token = h[7:].strip() if h.lower().startswith("bearer ") else request.args.get("token")
        try:
            user = user_from_token(token)
        except Exception as e:
            return fail(f"Base indisponible : {e}", 503)
        if not user:
            return fail("Session expirée, reconnectez-vous", 401, reason="auth")
        g.user = user
        return f(*a, **k)
    return w


def access_for(mac):
    """Droits du compte connecté sur une bague (None si non affectée)."""
    for acc in clientdb.user_rings(g.user["id"]):
        if acc["mac"].upper() == mac:
            return acc
    return None


def user_json(u):
    return {"id": u["id"], "login": u["login"], "name": u["display_name"] or u["login"], "lang": u["lang"],
            "alertsEnabled": bool(u["alerts_enabled"]), "fcm": fcm.enabled}


# ============================================================================ API

@app.get("/api/client/health")
def health():
    return ok(broker=mqttc.is_connected(), db=dbq.status().get("connected"), fcm=fcm.enabled, now=now())


@app.post("/api/client/login")
def api_login():
    body = request.get_json(silent=True) or {}
    try:
        user, reason = clientdb.check_login(body.get("login"), body.get("password"))
    except Exception as e:
        log.exception("login")
        return fail(f"Base indisponible : {e}", 503)
    if not user:
        msg = {"locked": "Trop d'essais : réessayez dans 5 minutes",
               "disabled": "Compte désactivé, contactez l'administrateur"}.get(reason, "Identifiant ou mot de passe incorrect")
        return fail(msg, 401 if reason == "bad" else 403, reason=reason)
    log.info("Connexion de %s", user["login"])
    return ok(token=make_token(user), user=user_json(user))


@app.get("/api/client/me")
@auth_required
def api_me():
    return ok(user=user_json(g.user))


@app.post("/api/client/password")
@auth_required
def api_password():
    body = request.get_json(silent=True) or {}
    try:
        user = clientdb.change_password(g.user["id"], body.get("old"), body.get("new"))
    except PermissionError as e:
        return fail(e, 403)
    except ValueError as e:
        return fail(e)
    # Les autres téléphones sont déconnectés ; celui-ci reçoit un nouveau jeton
    return ok(token=make_token(user), user=user_json(user))


@app.post("/api/client/prefs")
@auth_required
def api_prefs():
    user = clientdb.set_prefs(g.user["id"], request.get_json(silent=True) or {})
    return ok(user=user_json(user))


@app.post("/api/client/device")
@auth_required
def api_device():
    body = request.get_json(silent=True) or {}
    token = (body.get("fcmToken") or "").strip()
    if not token:
        return fail("fcmToken manquant")
    clientdb.add_device(g.user["id"], token, body.get("platform"), body.get("appVersion"))
    return ok(fcm=fcm.enabled)


@app.post("/api/client/logout")
@auth_required
def api_logout():
    token = ((request.get_json(silent=True) or {}).get("fcmToken") or "").strip()
    if token:
        clientdb.remove_device(token)
    return ok()


@app.get("/api/client/rings")
@auth_required
def api_rings():
    return ok(rings=[ring_payload(a) for a in clientdb.user_rings(g.user["id"])], user=user_json(g.user))


@app.post("/api/client/rings/notify")
@auth_required
def api_notify_all():
    notify = bool((request.get_json(silent=True) or {}).get("notify"))
    clientdb.set_notify(g.user["id"], notify)
    return ok(notify=notify)


def ring_or_404(key):
    mac = mac_from_key(key)
    acc = access_for(mac) if mac else None
    return mac, acc


@app.get("/api/client/ring/<key>")
@auth_required
def api_ring(key):
    mac, acc = ring_or_404(key)
    if not acc:
        return fail("Bague non affectée à ce compte", 404)
    out = ring_payload(acc)
    # Valeurs en base si le service vient de démarrer et ne connaît pas encore la bague
    if not out["live"]["values"]:
        try:
            latest = dbq.latest_values(acc["ring_id"])
            vis = set(visible_measures(acc))
            out["live"]["values"] = {k: v for k, v in latest.items() if k in vis}
        except Exception:
            pass
    out["limits"] = LIMITS
    out["wearCheck"] = WEAR_CHECK_SECONDS
    return ok(ring=out)


@app.post("/api/client/ring/<key>/notify")
@auth_required
def api_notify(key):
    mac, acc = ring_or_404(key)
    if not acc:
        return fail("Bague non affectée à ce compte", 404)
    notify = bool((request.get_json(silent=True) or {}).get("notify"))
    clientdb.set_notify(g.user["id"], notify, mac)
    return ok(notify=notify)


def ring_ready(mac):
    """(état, erreur) : la TV doit être en ligne et la bague connectée."""
    with lock:
        r = rings.get(mac)
        state = json.loads(json.dumps(r, default=str)) if r else None
    if not state or not state["statusTs"]:
        return None, fail("Aucune TV ne signale cette bague", 409, reason="unknown")
    if not gateway_online(state):
        return None, fail("TV hors ligne", 409, reason="gateway_offline")
    if state["ring"] != "connected":
        return None, fail("Bague hors portée", 409, reason="ring_disconnected")
    return state, None


def send_cmd(mac, cmd, who):
    """Même règle que l'admin : une seule mesure à la fois (même mesure = partagée, autre = refusée)."""
    with lock:
        r = rings.setdefault(mac, new_ring(mac))
        if cmd in MEASURES:
            running = [k for k in r["pending"] if k in MEASURES]
            if running and cmd not in running:
                return {"ok": False, "error": f"Mesure {running[0].upper()} déjà en cours", "busy": running[0]}, 409
            if cmd in running:
                return {"ok": True, "already": True, "reqId": r["pending"][cmd].get("reqId")}, 200
        req = "app-" + uuid.uuid4().hex[:8]
        info = mqttc.publish(f"{PREFIX}/{topic_mac(mac)}/cmd", json.dumps({"cmd": cmd, "reqId": req}), qos=1)
        r["pending"][cmd] = {"since": now(), "requested": now(), "reqId": req, "confirmed": False}
        r["errors"].pop(cmd, None)
    log.info("Commande %s envoyée à %s (%s)", cmd, mac, who)
    push_ring(mac)
    return {"ok": True, "sent": info.rc == mqtt.MQTT_ERR_SUCCESS, "reqId": req}, 200


@app.post("/api/client/ring/<key>/cmd")
@auth_required
def api_cmd(key):
    mac, acc = ring_or_404(key)
    if not acc:
        return fail("Bague non affectée à ce compte", 404)
    cmd = (request.get_json(silent=True) or {}).get("cmd")
    if cmd not in rights(acc)["measures"]:
        return fail("Mesure non autorisée", 403)
    _, err = ring_ready(mac)
    if err:
        return err
    res, code = send_cmd(mac, cmd, g.user["login"])
    return jsonify(res), code


@app.post("/api/client/ring/<key>/check")
@auth_required
def api_check(key):
    """« Actualiser l'état » : une mesure HR sert de test de port (15 s sans problème = portée).
    Si une mesure tourne déjà : busy (l'app fait patienter puis relance à la fin)."""
    mac, acc = ring_or_404(key)
    if not acc:
        return fail("Bague non affectée à ce compte", 404)
    state, err = ring_ready(mac)
    if err:
        return err
    running = [k for k in state["pending"] if k in MEASURES]
    if running:
        return ok(busy=running[0], since=state["pending"][running[0]].get("since"))
    # La batterie d'abord (la TV exécute les commandes dans l'ordre), puis la mesure HR
    mqttc.publish(f"{PREFIX}/{topic_mac(mac)}/cmd", json.dumps({"cmd": "battery", "reqId": "app-" + uuid.uuid4().hex[:8]}), qos=1)
    res, code = send_cmd(mac, "hr", g.user["login"] + " (état)")
    if code == 409 and res.get("busy"):
        return ok(busy=res["busy"])
    if not res.get("ok"):
        return jsonify(res), code
    return ok(cmd="hr", reqId=res.get("reqId"), started=now(), wearCheck=WEAR_CHECK_SECONDS)


@app.get("/api/client/ring/<key>/history")
@auth_required
def api_history(key):
    mac, acc = ring_or_404(key)
    if not acc:
        return fail("Bague non affectée à ce compte", 404)
    if not acc["can_view_history"]:
        return fail("Historique non autorisé", 403)
    typ = request.args.get("type", "hr")
    if typ not in visible_measures(acc) or typ not in DB_METRIC:
        return fail("Mesure non autorisée", 403)
    try:
        hours = min(max(int(request.args.get("hours", "24")), 1), 24 * 90)
    except ValueError:
        hours = 24
    try:
        rows = dbq.history(mac, DB_METRIC[typ], 2000)
    except Exception as e:
        return fail(f"Base indisponible : {e}", 503)
    limit = now() - hours * 3600
    out = []
    for x in rows:
        t = int(x["time"].timestamp())
        if t < limit:
            continue
        ex = x["extra"] or {}
        out.append({"ts": t, "value": x["value"], "dbp": ex.get("dbp"), "status": x["status"],
                    "reason": x["reason"], "dur": ex.get("duration_s"), "source": ex.get("origin")})
    return ok(rows=out, type=typ, hours=hours)


@app.get("/api/client/alerts")
@auth_required
def api_alerts():
    rows = clientdb.user_alerts(g.user["id"], min(int(request.args.get("limit", "50")), 200))
    return ok(alerts=[{"id": a["id"], "kind": a["kind"], "title": a["title"], "message": a["message"],
                       "ts": int(a["created_at"].timestamp()), "mac": a["mac"].upper(), "label": a["label"]}
                      for a in rows])


# ============================================================================ temps réel (SSE)

subscribers = []   # {"uid", "q", "macs": {mac: acc}}
subs_lock = threading.Lock()


def push_ring(mac):
    with subs_lock:
        subs = list(subscribers)
    for s in subs:
        acc = s["macs"].get(mac)
        if not acc:
            continue
        msg = json.dumps({"type": "ring", "mac": mac, "live": live_state(mac, acc)}, default=str)
        try:
            s["q"].put_nowait(msg)
        except queue.Full:
            pass


def push_user(uid, payload):
    msg = json.dumps(payload, default=str)
    with subs_lock:
        subs = [s for s in subscribers if s["uid"] == uid]
    for s in subs:
        try:
            s["q"].put_nowait(msg)
        except queue.Full:
            pass


@app.get("/api/client/stream")
@auth_required
def api_stream():
    uid = g.user["id"]
    accs = {a["mac"].upper(): a for a in clientdb.user_rings(uid)}
    sub = {"uid": uid, "q": queue.Queue(maxsize=500), "macs": accs}
    with subs_lock:
        subscribers.append(sub)
    hello = json.dumps({"type": "hello", "rings": [ring_payload(a) for a in accs.values()]}, default=str)

    def gen():
        last_reload = time.time()
        try:
            yield "retry: 3000\n\n"
            yield f"data: {hello}\n\n"
            while True:
                try:
                    yield f"data: {sub['q'].get(timeout=15)}\n\n"
                except queue.Empty:
                    yield ": ping\n\n"
                # Droits relus régulièrement : une bague retirée par l'admin disparaît du flux
                if time.time() - last_reload > 60:
                    last_reload = time.time()
                    try:
                        sub["macs"] = {a["mac"].upper(): a for a in clientdb.user_rings(uid)}
                    except Exception:
                        pass
        finally:
            with subs_lock:
                if sub in subscribers:
                    subscribers.remove(sub)

    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ============================================================================ Firebase (FCM)

class Fcm:
    """Envoi des notifications Firebase (API HTTP v1). Désactivé si FCM_SERVICE_ACCOUNT_FILE est absent."""

    def __init__(self, path):
        self.enabled = False
        self.creds = None
        self.project = None
        self.lock = threading.Lock()
        if not path:
            log.info("FCM désactivé (FCM_SERVICE_ACCOUNT_FILE absent du .env)")
            return
        p = Path(path)
        if not p.is_absolute():
            p = HERE / p
        try:
            from google.oauth2 import service_account  # noqa: F401
            import google.auth.transport.requests  # noqa: F401
            import requests  # noqa: F401
            info = json.loads(p.read_text(encoding="utf-8"))
            self.project = info["project_id"]
            self.creds = service_account.Credentials.from_service_account_info(
                info, scopes=["https://www.googleapis.com/auth/firebase.messaging"])
            self.enabled = True
            log.info("FCM activé (projet Firebase %s)", self.project)
        except ImportError:
            log.warning("FCM désactivé : pip install google-auth requests")
        except Exception as e:
            log.warning("FCM désactivé : clé de service illisible (%s)", e)

    def _bearer(self):
        import google.auth.transport.requests as gtr
        with self.lock:
            if not self.creds.valid:
                self.creds.refresh(gtr.Request())
            return self.creds.token

    def send(self, token, title, body, data):
        """True si envoyé ; False si le jeton est invalide (à supprimer) ; None sinon."""
        if not self.enabled:
            return None
        import requests
        msg = {"message": {"token": token, "notification": {"title": title, "body": body},
                           "data": {k: str(v) for k, v in data.items()},
                           "android": {"priority": "high", "notification": {"sound": "default"}}}}
        try:
            r = requests.post(f"https://fcm.googleapis.com/v1/projects/{self.project}/messages:send",
                              headers={"Authorization": f"Bearer {self._bearer()}"}, json=msg, timeout=10)
        except Exception as e:
            log.warning("FCM : envoi impossible (%s)", e)
            return None
        if r.status_code == 200:
            return True
        if r.status_code in (400, 404) and ("UNREGISTERED" in r.text or "INVALID_ARGUMENT" in r.text):
            return False
        log.warning("FCM : réponse %s %s", r.status_code, r.text[:200])
        return None


fcm = Fcm(FCM_FILE)


# ============================================================================ alertes

TEXTS = {
    "removed": {"fr": ("🖐 Bague retirée", "{label} : la bague n'est pas portée."),
                "en": ("🖐 Ring removed", "{label}: the ring is not being worn."),
                "ar": ("🖐 الخاتم منزوع", "{label}: الخاتم غير مرتدى.")},
    "out_of_range": {"fr": ("🔴 Bague hors portée", "{label} : la bague s'est éloignée de la TV."),
                     "en": ("🔴 Ring out of range", "{label}: the ring is out of reach of the TV."),
                     "ar": ("🔴 الخاتم خارج النطاق", "{label}: ابتعد الخاتم عن التلفاز.")},
    "gateway_offline": {"fr": ("⚫ TV hors ligne", "{label} : la TV ne répond plus."),
                        "en": ("⚫ TV offline", "{label}: the TV is not responding."),
                        "ar": ("⚫ التلفاز غير متصل", "{label}: التلفاز لا يستجيب.")},
    "battery_low": {"fr": ("🪫 Batterie faible", "{label} : batterie à {battery} %."),
                    "en": ("🪫 Low battery", "{label}: battery at {battery}%."),
                    "ar": ("🪫 بطارية منخفضة", "{label}: البطارية {battery}٪.")},
    "restored_range": {"fr": ("✅ Bague reconnectée", "{label} : la bague est de nouveau à portée."),
                       "en": ("✅ Ring reconnected", "{label}: the ring is back in range."),
                       "ar": ("✅ عاد الاتصال بالخاتم", "{label}: الخاتم ضمن النطاق مجددًا.")},
    "restored_gateway": {"fr": ("✅ TV en ligne", "{label} : la TV répond de nouveau."),
                         "en": ("✅ TV online", "{label}: the TV is responding again."),
                         "ar": ("✅ التلفاز متصل", "{label}: التلفاز يستجيب مجددًا.")},
}


class Alerts:
    """Même logique que les alertes du bot : hors portée / TV hors ligne confirmés après
    CLIENT_ALERT_CONFIRM_SECONDS, retirée immédiate, batterie faible une fois.
    Pas d'alerte pour l'état déjà présent quand le service découvre la bague."""

    def __init__(self):
        self.st = {}
        self.q = queue.Queue(maxsize=1000)
        self.lock = threading.Lock()

    def _s(self, mac):
        return self.st.setdefault(mac, {"base": False, "worn": None, "out_since": None, "out_sent": False,
                                        "gw_since": None, "gw_sent": False, "batt_sent": False, "battery": None})

    def observe(self, mac, r):
        """Appelé à chaque message de la bague (état déjà mis à jour)."""
        with self.lock:
            s = self._s(mac)
            gw_on = gateway_online(r)
            out = gw_on and r["ring"] in ("disconnected", "connecting")
            batt = r["battery"]
            low = batt is not None and batt < BATTERY_LOW and not r["charging"]
            if not s["base"]:
                if not r["statusTs"]:
                    return
                # Premier statut reçu : état de départ, sans alerte
                s.update(base=True, worn=r["worn"], out_since=now() if out else None, out_sent=out,
                         gw_since=None, gw_sent=False, batt_sent=low, battery=batt)
                return
            if r["worn"] is False and s["worn"] is not False:
                self.q.put((mac, "removed", {}))
            s["worn"] = r["worn"]
            if gw_on:
                if s["gw_sent"]:
                    self.q.put((mac, "restored_gateway", {}))
                s["gw_since"], s["gw_sent"] = None, False
            if out:
                s["out_since"] = s["out_since"] or now()
            else:
                if s["out_sent"] and r["ring"] == "connected":
                    self.q.put((mac, "restored_range", {}))
                if r["ring"] == "connected" or not gw_on:
                    s["out_since"], s["out_sent"] = None, False
            if low and not s["batt_sent"]:
                s["batt_sent"] = True
                self.q.put((mac, "battery_low", {"battery": batt}))
            elif batt is not None and (batt >= BATTERY_LOW + 5 or r["charging"]):
                s["batt_sent"] = False

    def tick(self):
        """Toutes les 5 s : confirmation des coupures (hors portée, TV hors ligne)."""
        t = now()
        with lock:
            snap = {m: json.loads(json.dumps(r, default=str)) for m, r in rings.items()}
        with self.lock:
            for mac, r in snap.items():
                s = self.st.get(mac)
                if not s or not s["base"]:
                    continue
                if not gateway_online(r):
                    s["gw_since"] = s["gw_since"] or t
                    if not s["gw_sent"] and t - s["gw_since"] >= ALERT_CONFIRM:
                        s["gw_sent"] = True
                        self.q.put((mac, "gateway_offline", {}))
                if s["out_since"] and not s["out_sent"] and t - s["out_since"] >= ALERT_CONFIRM:
                    s["out_sent"] = True
                    self.q.put((mac, "out_of_range", {}))

    def worker(self):
        while True:
            mac, kind, extra = self.q.get()
            try:
                self._dispatch(mac, kind, extra)
            except Exception:
                log.exception("alerte %s %s", kind, mac)

    def _dispatch(self, mac, kind, extra):
        rid = ring_id(mac)
        if rid is None:
            return
        with lock:
            name = (rings.get(mac) or {}).get("name") or mac
        fr_t, fr_b = TEXTS[kind]["fr"]
        row = clientdb.add_alert(rid, kind, fr_t, fr_b.format(label=name, **extra))
        users = clientdb.recipients(rid)
        log.info("Alerte %s pour %s → %d compte(s)", kind, mac, len(users))
        if not users:
            return
        by_user = {u["user_id"]: u for u in users}
        for u in users:
            t, b = TEXTS[kind].get(u["lang"]) or TEXTS[kind]["fr"]
            push_user(u["user_id"], {"type": "alert", "alert": {
                "id": row["id"], "kind": kind, "title": t, "message": b.format(label=u["label"], **extra),
                "ts": int(row["created_at"].timestamp()), "mac": mac, "label": u["label"]}})
        if not fcm.enabled:
            return
        for d in clientdb.device_tokens(list(by_user)):
            u = by_user[d["user_id"]]
            t, b = TEXTS[kind].get(u["lang"]) or TEXTS[kind]["fr"]
            res = fcm.send(d["fcm_token"], t, b.format(label=u["label"], **extra),
                           {"mac": mac, "kind": kind, "alertId": row["id"]})
            if res is False:
                clientdb.remove_device(d["fcm_token"])


alerts = Alerts()


def watchdog():
    while True:
        time.sleep(5)
        try:
            alerts.tick()
        except Exception:
            log.exception("watchdog")
        # TV sans statut depuis trop longtemps : l'app voit « TV hors ligne »
        t = now()
        stale = []
        with lock:
            for mac, r in rings.items():
                if r["online"] and r["statusTs"] and t - r["statusTs"] > OFFLINE_AFTER:
                    r["online"] = False
                    stale.append(mac)
                for k, p in list(r["pending"].items()):
                    if t - p["since"] > 150:
                        r["pending"].pop(k, None)
                        stale.append(mac)
        for mac in set(stale):
            push_ring(mac)


def main():
    dbq.test()
    if not clientdb.tables_ready():
        log.warning("Tables QRingClient absentes : lancez client_migration.sql une fois")
    seed_from_db()
    start_mqtt()
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=alerts.worker, daemon=True).start()
    ssl = (SSL_CERT, SSL_KEY) if SSL_CERT and SSL_KEY else None
    log.info("QRingClient API sur %s://0.0.0.0:%d (broker %s:%d, préfixe %s, PostgreSQL %s, FCM %s)",
             "https" if ssl else "http", PORT, MQTT_HOST, MQTT_PORT, PREFIX, dbq.status()["message"],
             "oui" if fcm.enabled else "non")
    app.run(host="0.0.0.0", port=PORT, threaded=True, debug=False, ssl_context=ssl)


if __name__ == "__main__":
    main()
