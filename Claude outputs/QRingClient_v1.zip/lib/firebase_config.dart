// Firebase (notifications quand l'app est fermée).
//
// Remplir avec les valeurs du fichier google-services.json téléchargé depuis
// console.firebase.google.com (projet QRingClient, app Android « com.eis.qring_client ») :
//   apiKey            = client[0].api_key[0].current_key
//   appId             = client[0].client_info.mobilesdk_app_id
//   messagingSenderId = project_info.project_number
//   projectId         = project_info.project_id
//
// Laisser vide = l'app fonctionne sans notifications (les alertes restent visibles dans l'app).
class FirebaseConfig {
  static const String apiKey = '';
  static const String appId = '';
  static const String messagingSenderId = '';
  static const String projectId = '';

  static bool get ready => apiKey.isNotEmpty && appId.isNotEmpty && messagingSenderId.isNotEmpty && projectId.isNotEmpty;
}
