// Traductions FR / EN / AR (même vocabulaire que l'app TV Gateway RHM).

String appLang = 'fr';

bool get isRtl => appLang == 'ar';

/// tr('rs.checked_at', ['12:51'])
String tr(String key, [List<Object?> args = const []]) {
  final row = _s[key];
  if (row == null) return key;
  var s = appLang == 'en' ? row[1] : appLang == 'ar' ? row[2] : row[0];
  for (final a in args) {
    s = s.replaceFirst('%s', '${a ?? ''}');
  }
  return s;
}

const Map<String, List<String>> _s = {
  // ------------------------------------------------ général
  'app.sub': ['Suivi des bagues RHM', 'RHM ring monitoring', 'متابعة خواتم RHM'],
  'btn.ok': ['OK', 'OK', 'حسنًا'],
  'btn.cancel': ['Annuler', 'Cancel', 'إلغاء'],
  'btn.close': ['Fermer', 'Close', 'إغلاق'],
  'btn.retry': ['Réessayer', 'Try again', 'إعادة المحاولة'],
  'btn.save': ['Enregistrer', 'Save', 'حفظ'],
  'err.network': ['Serveur injoignable. Vérifiez la connexion internet.', 'Server unreachable. Check your internet connection.', 'تعذر الوصول إلى الخادم. تحقق من الاتصال.'],
  'live.on': ['en direct', 'live', 'مباشر'],
  'live.off': ['reconnexion…', 'reconnecting…', 'إعادة الاتصال…'],

  // ------------------------------------------------ connexion
  'login.user': ['Identifiant', 'Username', 'اسم المستخدم'],
  'login.pass': ['Mot de passe', 'Password', 'كلمة المرور'],
  'login.keep': ['Rester connecté', 'Stay signed in', 'البقاء متصلًا'],
  'login.go': ['Se connecter', 'Sign in', 'تسجيل الدخول'],
  'login.server': ['Adresse du serveur', 'Server address', 'عنوان الخادم'],
  'login.server_adv': ['Paramètres du serveur', 'Server settings', 'إعدادات الخادم'],
  'login.admin': ['Compte créé par l\'administrateur', 'Account created by the administrator', 'حساب أنشأه المسؤول'],

  // ------------------------------------------------ onglets
  'tab.rings': ['Bagues', 'Rings', 'الخواتم'],
  'tab.alerts': ['Alertes', 'Alerts', 'التنبيهات'],
  'tab.profile': ['Profil', 'Profile', 'الملف'],
  'rings.title': ['Mes bagues', 'My rings', 'خواتمي'],
  'rings.none': ['Aucune bague ne vous est affectée pour l\'instant.\nContactez l\'administrateur.', 'No ring is assigned to you yet.\nContact the administrator.', 'لا يوجد خاتم مخصص لك بعد.\nتواصل مع المسؤول.'],
  'rings.alerts_all': ['Alertes : toutes les bagues', 'Alerts: all rings', 'التنبيهات: كل الخواتم'],
  'rings.alerts_off_global': ['Alertes désactivées dans le Profil', 'Alerts turned off in Profile', 'التنبيهات معطلة في الملف'],

  // ------------------------------------------------ état de la bague
  'rs.gw_off': ['TV hors ligne', 'TV offline', 'التلفاز غير متصل'],
  'rs.out': ['Bague hors portée', 'Ring out of range', 'الخاتم خارج النطاق'],
  'rs.bt_off': ['Bluetooth de la TV désactivé', 'TV Bluetooth off', 'بلوتوث التلفاز مغلق'],
  'rs.no_ring': ['Aucune bague sur la TV', 'No ring on the TV', 'لا يوجد خاتم على التلفاز'],
  'rs.removed': ['Bague retirée', 'Ring removed', 'الخاتم منزوع'],
  'rs.worn': ['Bague portée', 'Ring worn', 'الخاتم مرتدى'],
  'rs.connected': ['Bague connectée', 'Ring connected', 'الخاتم متصل'],
  'rs.unknown': ['Aucune nouvelle de la TV', 'No news from the TV', 'لا أخبار من التلفاز'],
  'rs.measuring': ['Mesure %s en cours · %s s', '%s measuring · %s s', 'قياس %s جارٍ · %s ث'],
  'rs.tv': ['TV : %s', 'TV: %s', 'التلفاز: %s'],
  'rs.status_at': ['dernier statut %s', 'last status %s', 'آخر حالة %s'],

  // ------------------------------------------------ mesures
  'm.hr': ['Fréquence cardiaque', 'Heart rate', 'نبض القلب'],
  'm.spo2': ['SpO2', 'SpO2', 'أكسجين الدم'],
  'm.temp': ['Température', 'Temperature', 'الحرارة'],
  'm.bp': ['Tension', 'Blood pressure', 'ضغط الدم'],
  'm.hrv': ['HRV', 'HRV', 'تقلب النبض'],
  'm.stress': ['Stress', 'Stress', 'التوتر'],
  'm.steps': ['Pas', 'Steps', 'الخطوات'],
  'm.battery': ['Batterie', 'Battery', 'البطارية'],
  'btn.hr': ['HR', 'HR', 'النبض'],
  'btn.spo2': ['SpO2', 'SpO2', 'الأكسجين'],
  'btn.temp': ['T°', 'T°', 'الحرارة'],
  'btn.bp': ['Tension', 'BP', 'الضغط'],
  'btn.hrv': ['HRV', 'HRV', 'HRV'],
  'btn.stress': ['Stress', 'Stress', 'التوتر'],
  'btn.steps': ['Pas', 'Steps', 'الخطوات'],
  'ring.last': ['Dernières mesures', 'Latest readings', 'آخر القياسات'],
  'ring.launch': ['Lancer une mesure', 'Start a measurement', 'بدء قياس'],
  'ring.no_value': ['Aucune mesure', 'No reading', 'لا قياس'],
  'ring.history': ['Historique', 'History', 'السجل'],
  'ring.alerts': ['Alertes pour cette bague', 'Alerts for this ring', 'تنبيهات هذا الخاتم'],
  'ring.alerts_no_right': ['Alertes non autorisées pour cette bague', 'Alerts not allowed for this ring', 'التنبيهات غير مسموح بها لهذا الخاتم'],
  'ring.duration': ['⏱ %s s', '⏱ %s s', '⏱ %s ث'],
  'ring.error': ['%s · %s', '%s · %s', '%s · %s'],
  'ring.km': ['%s km · %s kcal', '%s km · %s kcal', '%s كم · %s سعرة'],
  'src.manual': ['via TV', 'on TV', 'عبر التلفاز'],
  'src.mqtt': ['à distance', 'remote', 'عن بُعد'],
  'src.auto': ['auto', 'auto', 'تلقائي'],
  'cmd.sent': ['Demande envoyée à la TV', 'Request sent to the TV', 'تم إرسال الطلب إلى التلفاز'],
  'cmd.already': ['Mesure déjà en cours : résultat partagé', 'Already measuring: shared result', 'القياس جارٍ: نتيجة مشتركة'],

  // ------------------------------------------------ erreurs de mesure (codes de la TV)
  'err.ring_disconnected': ['Bague hors portée', 'Ring out of range', 'الخاتم خارج النطاق'],
  'err.ring_removed': ['Bague retirée', 'Ring removed', 'الخاتم منزوع'],
  'err.timeout': ['Pas de résultat', 'No result', 'لا توجد نتيجة'],
  'err.measure_failed': ['Mesure échouée', 'Measurement failed', 'فشل القياس'],
  'err.not_supported': ['Non supporté par cette bague', 'Not supported by this ring', 'غير مدعوم'],
  'err.busy': ['Bague occupée', 'Ring busy', 'الخاتم مشغول'],
  'err.cancelled': ['Mesure annulée', 'Measurement cancelled', 'تم إلغاء القياس'],
  'err.no_data': ['Aucune donnée', 'No data', 'لا توجد بيانات'],

  // ------------------------------------------------ vérification « État »
  'st.refresh': ['Actualiser l\'état de la bague', 'Refresh ring status', 'تحديث حالة الخاتم'],
  'st.checking': ['Vérification… %s s / %s s', 'Checking… %s s / %s s', 'جارٍ التحقق… %s ث / %s ث'],
  'st.requested': ['Demande envoyée à la TV…', 'Request sent to the TV…', 'تم إرسال الطلب…'],
  'st.waiting': ['En attente de la fin de la mesure…', 'Waiting for the measurement to end…', 'في انتظار انتهاء القياس…'],
  'st.worn': ['Bague portée — vérifiée à %s', 'Ring worn — checked at %s', 'الخاتم مرتدى — تم التحقق في %s'],
  'st.removed': ['Bague retirée — veuillez porter la bague', 'Ring removed — please wear the ring', 'الخاتم منزوع — يرجى ارتداؤه'],
  'st.unconfirmed': ['Pas de réponse de la bague', 'No answer from the ring', 'لا رد من الخاتم'],
  'pop.busy_title': ['Mesure en cours', 'Measurement in progress', 'القياس جارٍ'],
  'pop.busy_text': ['Veuillez patienter : la vérification de la bague sera lancée à la fin de la mesure en cours (%s).', 'Please wait: the ring check will start when the current measurement ends (%s).', 'يرجى الانتظار: سيبدأ فحص الخاتم عند انتهاء القياس الجاري (%s).'],

  // ------------------------------------------------ historique
  'hist.24h': ['24 h', '24 h', '24 س'],
  'hist.7d': ['7 j', '7 d', '7 أيام'],
  'hist.30d': ['30 j', '30 d', '30 يومًا'],
  'hist.none': ['Aucune mesure sur cette période.', 'No reading in this period.', 'لا توجد قياسات في هذه الفترة.'],
  'hist.stats': ['moy. %s · min %s · max %s', 'avg %s · min %s · max %s', 'المتوسط %s · الأدنى %s · الأعلى %s'],
  'hist.no_right': ['Historique non autorisé', 'History not allowed', 'السجل غير مسموح'],

  // ------------------------------------------------ alertes
  'al.none': ['Aucune alerte pour l\'instant.', 'No alert yet.', 'لا توجد تنبيهات بعد.'],

  // ------------------------------------------------ profil
  'pr.rings': ['%s bague(s) suivie(s)', '%s ring(s) followed', '%s خاتم'],
  'pr.lang': ['Langue', 'Language', 'اللغة'],
  'pr.alerts': ['Recevoir les alertes', 'Receive alerts', 'استلام التنبيهات'],
  'pr.alerts_sub': ['Retirée · hors portée · TV hors ligne · batterie faible', 'Removed · out of range · TV offline · low battery', 'منزوع · خارج النطاق · التلفاز غير متصل · بطارية منخفضة'],
  'pr.notif_on': ['Notifications du téléphone actives', 'Phone notifications active', 'إشعارات الهاتف مفعلة'],
  'pr.notif_off': ['Notifications du téléphone non configurées (alertes visibles dans l\'app)', 'Phone notifications not configured (alerts shown in the app)', 'إشعارات الهاتف غير مهيأة (التنبيهات داخل التطبيق)'],
  'pr.password': ['Changer mon mot de passe', 'Change my password', 'تغيير كلمة المرور'],
  'pr.old': ['Mot de passe actuel', 'Current password', 'كلمة المرور الحالية'],
  'pr.new': ['Nouveau mot de passe (6 caractères min.)', 'New password (6 characters min.)', 'كلمة مرور جديدة (6 أحرف على الأقل)'],
  'pr.pass_ok': ['Mot de passe changé', 'Password changed', 'تم تغيير كلمة المرور'],
  'pr.logout': ['Se déconnecter', 'Sign out', 'تسجيل الخروج'],
  'pr.server': ['Serveur : %s', 'Server: %s', 'الخادم: %s'],

  // ------------------------------------------------ temps
  't.now': ['à l\'instant', 'just now', 'الآن'],
  't.min': ['il y a %s min', '%s min ago', 'منذ %s د'],
  't.h': ['il y a %s h', '%s h ago', 'منذ %s س'],
  't.yesterday': ['hier', 'yesterday', 'أمس'],
};
