import 'package:flutter/material.dart';

import '../i18n.dart';
import '../main.dart';
import '../model.dart';
import '../widgets.dart';
import 'ring.dart';

/// « Mes bagues » : état de chaque bague en temps réel (Mosquitto → serveur → flux de l'app).
class RingsScreen extends StatelessWidget {
  const RingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final m = ModelScope.of(context);
    final alertable = m.rings.where((r) => r.canAlerts).toList();
    final allOn = alertable.isNotEmpty && alertable.every((r) => r.notify);
    final globalOff = m.user?['alertsEnabled'] == false;

    return RefreshIndicator(
      onRefresh: m.refreshRings,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 20),
        children: [
          Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
            const SizedBox(width: 10),
            Expanded(child: Text(tr('rings.title'), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            Icon(Icons.circle, size: 9, color: m.streaming ? C.ok : C.warn),
            const SizedBox(width: 5),
            Text(m.streaming ? tr('live.on') : tr('live.off'), style: const TextStyle(color: C.muted, fontSize: 12)),
          ]),
          const SizedBox(height: 12),
          if (alertable.isNotEmpty)
            Panel(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Row(children: [
                const Icon(Icons.notifications_active_outlined, color: C.muted, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(tr('rings.alerts_all'), style: const TextStyle(fontWeight: FontWeight.w600)),
                    if (globalOff)
                      Text(tr('rings.alerts_off_global'), style: const TextStyle(color: C.warn, fontSize: 11)),
                  ]),
                ),
                Switch(value: allOn, onChanged: (v) => m.setNotifyAll(v).catchError((Object e) {
                  if (context.mounted) toast(context, '$e', color: C.err);
                })),
              ]),
            ),
          const SizedBox(height: 10),
          if (m.rings.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 60),
              child: Text(tr('rings.none'), textAlign: TextAlign.center, style: const TextStyle(color: C.muted)),
            ),
          for (final r in m.rings) _RingCard(r),
        ],
      ),
    );
  }
}

class _RingCard extends StatelessWidget {
  final RingItem r;
  const _RingCard(this.r);

  @override
  Widget build(BuildContext context) {
    final s = ringStatus(r);
    // Dernière valeur (la plus récente parmi les mesures visibles)
    MapEntry<String, dynamic>? last;
    for (final e in r.values.entries) {
      if (e.key == 'battery' || e.key == 'all') continue;
      final ts = ((e.value as Map)['ts'] as num?) ?? 0;
      if (last == null || ts > (((last.value as Map)['ts'] as num?) ?? 0)) last = e;
    }
    String? lastText;
    if (last != null) {
      final mt = metricOf(last.key);
      final v = last.value as Map;
      lastText = '${mt.icon} ${formatValue(last.key, v['data'] as Map?)} ${mt.unit} · ${ago(((v['ts'] as num?) ?? 0).toInt())}';
    }
    final tv = (r.live['deviceName'] as String?)?.isNotEmpty == true ? r.live['deviceName'] : r.live['gateway'];

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => RingScreen(mac: r.mac))),
        child: Panel(
          border: s.color,
          child: Row(children: [
            BatteryRing(r.battery, size: 50),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text('💍 ${r.label}',
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  ),
                  if (r.canAlerts)
                    Icon(r.notify ? Icons.notifications_active : Icons.notifications_off, size: 17,
                        color: r.notify ? C.accent : C.muted),
                ]),
                const SizedBox(height: 5),
                StatusPill(s),
                if (s.detail != null)
                  Padding(padding: const EdgeInsets.only(top: 3),
                      child: Text(s.detail!, style: const TextStyle(color: C.muted, fontSize: 12))),
                const SizedBox(height: 4),
                Text(
                  [if (lastText != null) lastText, if (tv != null && '$tv'.isNotEmpty) '📺 $tv'].join(' · '),
                  maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: C.muted, fontSize: 12),
                ),
              ]),
            ),
            const Icon(Icons.chevron_right, color: C.muted),
          ]),
        ),
      ),
    );
  }
}
