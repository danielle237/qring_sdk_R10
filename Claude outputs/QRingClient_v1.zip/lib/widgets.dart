// Couleurs, formats et petits composants partagés (même style sombre que l'app TV Gateway RHM).
import 'package:flutter/material.dart';

import 'i18n.dart';
import 'model.dart';

class C {
  static const bg = Color(0xFF0F1320);
  static const surface = Color(0xFF151A29);
  static const card = Color(0xFF1E2438);
  static const card2 = Color(0xFF252C45);
  static const line = Color(0xFF2A3150);
  static const text = Color(0xFFEEF1FA);
  static const muted = Color(0xFF8B93B0);
  static const accent = Color(0xFF6C8CFF);
  static const ok = Color(0xFF3ECF8E);
  static const warn = Color(0xFFFFB547);
  static const err = Color(0xFFFF6B6B);
  static const off = Color(0xFF6B7390);
}

class Metric {
  final String key;
  final String icon;
  final Color color;
  final String unit;
  const Metric(this.key, this.icon, this.color, this.unit);
  String get label => tr('m.$key');
}

const metrics = <Metric>[
  Metric('hr', '❤️', Color(0xFFFF5D73), 'bpm'),
  Metric('spo2', '💧', Color(0xFF4FC3F7), '%'),
  Metric('temp', '🌡', Color(0xFFFFA04D), '°C'),
  Metric('bp', '🩸', Color(0xFFB18CFF), 'mmHg'),
  Metric('hrv', '💓', Color(0xFF3ECF8E), 'ms'),
  Metric('stress', '⚡', Color(0xFFFFD23F), '/100'),
  Metric('steps', '🚶', Color(0xFF22C1A4), ''),
];

Metric metricOf(String key) => metrics.firstWhere((m) => m.key == key, orElse: () => Metric(key, '•', C.accent, ''));

String two(int n) => n.toString().padLeft(2, '0');

String hm(int tsSec) {
  final d = DateTime.fromMillisecondsSinceEpoch(tsSec * 1000);
  return '${two(d.hour)}:${two(d.minute)}';
}

String dayHm(int tsSec) {
  final d = DateTime.fromMillisecondsSinceEpoch(tsSec * 1000);
  final n = DateTime.now();
  if (d.year == n.year && d.month == n.month && d.day == n.day) return hm(tsSec);
  return '${two(d.day)}/${two(d.month)} ${hm(tsSec)}';
}

String ago(int tsSec) {
  final d = nowSec() - tsSec;
  if (d < 60) return tr('t.now');
  if (d < 3600) return tr('t.min', [d ~/ 60]);
  if (d < 86400) return tr('t.h', [d ~/ 3600]);
  if (d < 2 * 86400) return tr('t.yesterday');
  final t = DateTime.fromMillisecondsSinceEpoch(tsSec * 1000);
  return '${two(t.day)}/${two(t.month)}';
}

String sourceLabel(String? s) {
  if (s == 'manual') return tr('src.manual');
  if (s == 'mqtt') return tr('src.mqtt');
  if (s == 'auto') return tr('src.auto');
  return '';
}

/// « 72 », « 120/80 », « 2 615 »…
String formatValue(String key, Map? data) {
  if (data == null) return '--';
  switch (key) {
    case 'temp':
      final v = (data['value'] as num?)?.toDouble();
      return v == null ? '--' : v.toStringAsFixed(1).replaceAll('.', appLang == 'en' ? '.' : ',');
    case 'bp':
      return '${data['sbp'] ?? '--'}/${data['dbp'] ?? '--'}';
    case 'steps':
      final s = (data['steps'] as num?)?.toInt() ?? (data['value'] as num?)?.toInt();
      if (s == null) return '--';
      return s.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]} ');
    default:
      final v = data['value'] as num?;
      return v == null ? '--' : v.round().toString();
  }
}

/// État d'une bague : couleur, texte, détail.
class RingStatus {
  final Color color;
  final String text;
  final String? detail;
  const RingStatus(this.color, this.text, [this.detail]);
}

RingStatus ringStatus(RingItem r) {
  final ts = (r.live['statusTs'] as num?)?.toInt() ?? 0;
  if (ts == 0) return RingStatus(C.off, tr('rs.unknown'));
  if (!r.online) return RingStatus(C.off, tr('rs.gw_off'), tr('rs.status_at', [dayHm(ts)]));
  final running = r.runningMeasure;
  String? detail;
  if (running != null) {
    final since = ((r.pending[running] as Map?)?['since'] as num?)?.toInt() ?? nowSec();
    detail = tr('rs.measuring', [tr('btn.$running'), (nowSec() - since).clamp(0, 999)]);
  }
  switch (r.ringState) {
    case 'disconnected':
    case 'connecting':
      return RingStatus(C.err, tr('rs.out'), detail);
    case 'bluetooth_off':
      return RingStatus(C.err, tr('rs.bt_off'), detail);
    case 'no_ring':
    case 'unbound':
      return RingStatus(C.off, tr('rs.no_ring'), detail);
  }
  if (r.worn == false) return RingStatus(C.warn, tr('rs.removed'), detail);
  if (r.worn == true) return RingStatus(C.ok, tr('rs.worn'), detail);
  return RingStatus(C.accent, tr('rs.connected'), detail);
}

class StatusPill extends StatelessWidget {
  final RingStatus s;
  final double size;
  const StatusPill(this.s, {super.key, this.size = 12});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: s.color.withOpacity(.18), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: s.color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Flexible(child: Text(s.text, style: TextStyle(color: s.color, fontWeight: FontWeight.w700, fontSize: size))),
        ]),
      );
}

class BatteryRing extends StatelessWidget {
  final int? value;
  final double size;
  const BatteryRing(this.value, {super.key, this.size = 52});
  @override
  Widget build(BuildContext context) {
    final v = value;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        SizedBox(
          width: size,
          height: size,
          child: CircularProgressIndicator(
            value: (v ?? 0) / 100,
            strokeWidth: 5,
            backgroundColor: C.line,
            color: (v ?? 100) < 20 ? C.err : C.ok,
          ),
        ),
        Text(v == null ? '--' : '$v%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.text)),
      ]),
    );
  }
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final Color? border;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(12), this.color = C.card, this.border});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          border: border == null ? null : Border.all(color: border!.withOpacity(.45)),
        ),
        child: child,
      );
}

void toast(BuildContext context, String text, {Color color = C.card2}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text), backgroundColor: color, behavior: SnackBarBehavior.floating));
}
