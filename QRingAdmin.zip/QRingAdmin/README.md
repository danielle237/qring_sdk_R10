# QRing Admin (Flask)

Tableau de bord web qui supervise les bagues QRing via MQTT.

- **Une ligne par bague (MAC)**, mise à jour en direct sans recharger la page
- Valeurs : cœur, SpO2, température, tension, HRV, stress, pas, batterie
- **Mesures à distance** (boutons ♥ O₂ T° BP ⚡ + menu : HRV, stress, pas, sommeil…)
- Chargement visible pendant la mesure, puis résultat ou erreur
- **Alertes** (bandeau, compteur, son optionnel) : bague retirée, bague déconnectée,
  gateway hors ligne (aucun statut depuis 150 s), mesure en échec
- **Gateways** : IP LAN / WAN, langue, scanner les bagues proches, associer une MAC,
  dissocier, changer la langue de la TV
- **Historique** de chaque bague (courbe + tableau), stocké dans SQLite (`qring.db`)
- Journal des événements, recherche, filtres, thème sombre / clair

## Installation

```bash
cd QRingAdmin
python -m venv venv
source venv/bin/activate          # Windows : venv\Scripts\activate
pip install -r requirements.txt
```

## Lancement

```bash
export MQTT_HOST=51.83.40.138
export MQTT_PORT=1883
export MQTT_USER=tvclient
export MQTT_PASS='mot-de-passe-du-broker'
export ADMIN_PASSWORD='choisir-un-mot-de-passe'
export SECRET_KEY='une-longue-chaine-aleatoire'
python app.py
```

Windows (PowerShell) : `$env:MQTT_PASS="..."` au lieu de `export`.

Puis ouvrir **http://localhost:5000** (ou l'IP du serveur, port 5000).

| Variable | Défaut | Rôle |
|---|---|---|
| `MQTT_HOST` / `MQTT_PORT` | 51.83.40.138 / 1883 | broker |
| `MQTT_USER` / `MQTT_PASS` | tvclient / mot de passe actuel | identifiants broker |
| `MQTT_PREFIX` | eis/colmi | préfixe des topics |
| `ADMIN_PASSWORD` | admin | mot de passe de la page — **à changer** |
| `SECRET_KEY` | aléatoire | clé des sessions (fixez-la pour garder la connexion après redémarrage) |
| `PORT` | 5000 | port web |
| `DB_PATH` | ./qring.db | base SQLite |
| `OFFLINE_AFTER` | 150 | secondes sans statut avant « hors ligne » |

## Tester sans TV ni bague

Un simulateur se comporte comme l'application Android (statut chaque minute, réponses aux commandes) :

```bash
python simulate_gateway.py --host 51.83.40.138 --user tvclient --password '...' \
       --name TV-Test-1 --mac AA:BB:CC:DD:EE:01
python simulate_gateway.py ... --name TV-Test-2 --mac AA:BB:CC:DD:EE:02 --removed   # bague retirée
```

## Service permanent (Linux, systemd)

`/etc/systemd/system/qring-admin.service` :

```ini
[Unit]
Description=QRing Admin
After=network.target

[Service]
WorkingDirectory=/opt/QRingAdmin
Environment=MQTT_HOST=51.83.40.138 MQTT_USER=tvclient MQTT_PASS=... ADMIN_PASSWORD=... SECRET_KEY=...
ExecStart=/opt/QRingAdmin/venv/bin/python app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now qring-admin
```

Pour un accès depuis Internet, placez-le derrière Nginx en HTTPS
(désactiver le buffering pour `/stream` : `proxy_buffering off;`).

## API (utilisée par la page)

| Méthode | URL | Corps |
|---|---|---|
| GET | `/api/state` | état complet (bagues, gateways, événements) |
| POST | `/api/ring/<MAC>/cmd` | `{"cmd":"spo2"}` (hr, spo2, temp, bp, hrv, stress, all, steps, sleep, sedentary, workouts, history, battery, info, cancel, ping) |
| POST | `/api/gateway/<nom>/cmd` | `{"cmd":"bind","mac":"…"}`, `{"cmd":"unbind"}`, `{"cmd":"scan"}`, `{"cmd":"lang","value":"ar"}`, `{"cmd":"ping"}` |
| GET | `/api/ring/<MAC>/history?type=hr` | historique SQLite |
| GET | `/stream` | flux temps réel (Server-Sent Events) |
