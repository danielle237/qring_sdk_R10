"""
QRing Admin — supervision des bagues QRing via MQTT.

- Écoute eis/colmi/# en permanence
- Une ligne par bague (MAC), mise à jour en direct (Server-Sent Events)
- Lance les mesures à distance, gère les gateways (bind / unbind / scan / langue)
- Alerte quand une bague est retirée, déconnectée ou qu'un gateway tombe
- Historique des mesures dans SQLite

Configuration par variables d'environnement (voir README.md).
"""
import json
import os
import queue
import sqlite3
import threading
import time
import uuid
from functools import wraps

import paho.mqtt.client as mqtt
from flask import Flask, Response, jsonify, redirect, render_template, request, session, url_for

# ---------------------------------------------------------------------------- configuration

MQTT_HOST = os.environ.get("MQTT_HOST", "51.83.40.138")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
MQTT_USER = os.environ.get("MQTT_USER", "tvclient")
MQTT_PASS = os.environ.get("MQTT_PASS", "tvclient210367@Tunis")
PREFIX = os.environ.get("MQTT_PREFIX", "eis/colmi").strip("/")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin")
DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(__file__), "qring.db"))
OFFLINE_AFTER = int(os.environ.get("OFFLINE_AFTER", "150"))  # s sans statut → hors ligne

MEASURES = ["hr", "spo2", "temp", "bp", "hrv", "stress", "all"]
SYNCS = ["steps", "sleep", "sedentary", "workouts", "history", "battery", "info"]

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-" + uuid.uuid4().hex)

# ---------------------------------------------------------------------------- base de données

_db_lock = threading.Lock()


def db():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with _db_lock, db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS measures (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER, mac TEXT, gateway TEXT, type TEXT,
                status TEXT, data TEXT, error TEXT, req_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_measures_mac ON measures(mac, type, ts);
            CREATE TABLE IF NOT EXISTS rings (mac TEXT PRIMARY KEY, data TEXT);
            CREATE TABLE IF NOT EXISTS gateways (name TEXT PRIMARY KEY, data TEXT);
            """
        )


def save_measure(ts, mac, gateway, typ, status, data, error, req_id):
    with _db_lock, db() as con:
        con.execute(
            "INSERT INTO measures(ts, mac, gateway, type, status, data, error, req_id) VALUES (?,?,?,?,?,?,?,?)",
            (ts, mac, gateway, typ, status, json.dumps(data), error, req_id),
        )


def persist(table, key, obj):
    col = "mac" if table == "rings" else "name"
    with _db_lock, db() as con:
        con.execute(f"INSERT OR REPLACE INTO {table}({col}, data) VALUES (?, ?)", (key, json.dumps(obj)))


# ---------------------------------------------------------------------------- état en mémoire

state_lock = threading.RLock()
rings = {}      # mac → dict
gateways = {}   # nom → dict
events = []     # journal (200 derniers)
subscribers = []  # files SSE


def now():
    return int(time.time())


def mac_from_topic(t):
    """C4A15F22A4F1 → C4:A1:5F:22:A4:F1"""
    t = t.upper()
    return ":".join(t[i:i + 2] for i in range(0, 12, 2)) if len(t) == 12 else t


def topic_mac(mac):
    return mac.replace(":", "").replace("-", "").upper()


def new_ring(mac):
    return {
        "mac": mac, "name": "", "model": "", "firmware": "", "gateway": "", "deviceName": "",
        "online": False, "ring": "unknown", "worn": None, "battery": None, "charging": False,
        "lanIp": None, "wanIp": None, "lang": None, "statusTs": 0, "measuring": None,
        "values": {}, "pending": {}, "errors": {}, "unbound": False,
    }


def new_gateway(name):
    return {
        "name": name, "deviceName": "", "ringMac": "", "online": False, "ring": "unknown",
        "lanIp": None, "wanIp": None, "lang": None, "statusTs": 0, "scan": None, "bind": None,
        "appVersion": "",
    }


def broadcast(kind, data):
    msg = json.dumps({"kind": kind, "data": data})
    for q in list(subscribers):
        try:
            q.put_nowait(msg)
        except queue.Full:
            pass


def add_event(level, text, mac=None, gateway=None):
    """level : info | ok | warn | error"""
    ev = {"ts": now(), "level": level, "text": text, "mac": mac, "gateway": gateway}
    with state_lock:
        events.insert(0, ev)
        del events[200:]
    broadcast("event", ev)


def push_ring(mac):
    with state_lock:
        r = rings.get(mac)
        if r:
            persist("rings", mac, r)
            broadcast("ring", r)


def push_gateway(name):
    with state_lock:
        g = gateways.get(name)
        if g:
            persist("gateways", name, g)
            broadcast("gateway", g)


def load_state():
    with _db_lock, db() as con:
        for row in con.execute("SELECT mac, data FROM rings"):
            r = new_ring(row["mac"])
            r.update(json.loads(row["data"]))
            r["online"] = False
            r["pending"] = {}
            rings[row["mac"]] = r
        for row in con.execute("SELECT name, data FROM gateways"):
            g = new_gateway(row["name"])
            g.update(json.loads(row["data"]))
            g["online"] = False
            gateways[row["name"]] = g


# ---------------------------------------------------------------------------- MQTT

ERROR_LABELS = {
    "ring_disconnected": "Bague déconnectée",
    "ring_removed": "Bague retirée",
    "timeout": "Pas de résultat",
    "measure_failed": "Mesure échouée",
    "not_supported": "Non supporté",
    "busy": "Bague occupée",
    "invalid_value": "Valeur incohérente",
    "cancelled": "Annulée",
    "no_data": "Aucune donnée",
    "not_found": "Bague introuvable",
    "bluetooth_off": "Bluetooth désactivé",
    "bad_request": "Paramètre manquant",
    "unknown_command": "Commande inconnue",
}


def on_connect(client, userdata, flags, reason_code, properties=None):
    if reason_code == 0 or str(reason_code) == "Success":
        client.subscribe(f"{PREFIX}/#", qos=1)
        add_event("ok", f"Connecté au broker {MQTT_HOST}:{MQTT_PORT}")
    else:
        add_event("error", f"Connexion broker refusée : {reason_code}")
    broadcast("broker", {"online": True})


def on_disconnect(client, userdata, flags, reason_code, properties=None):
    add_event("error", "Déconnecté du broker, reconnexion…")
    broadcast("broker", {"online": False})


def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode("utf-8"))
    except Exception:
        return  # commandes en texte brut, ignorées
    if not isinstance(payload, dict):
        return
    parts = msg.topic.split("/")
    base = PREFIX.split("/")
    if parts[: len(base)] != base:
        return
    rest = parts[len(base):]
    try:
        if len(rest) >= 3 and rest[0] == "gateway":
            handle_gateway(rest[1], rest[2], payload)
        elif len(rest) >= 2:
            handle_ring(mac_from_topic(rest[0]), rest[1], payload)
    except Exception as e:  # ne jamais casser la boucle MQTT
        add_event("error", f"Message illisible sur {msg.topic} : {e}")


def handle_gateway(name, sub, p):
    if sub == "cmd":
        return
    with state_lock:
        g = gateways.setdefault(name, new_gateway(name))
        if sub == "status":
            was_online = g["online"]
            g.update({
                "online": bool(p.get("online")), "ring": p.get("ring", "unknown"),
                "ringMac": p.get("ringMac") or "", "deviceName": p.get("deviceName") or g["deviceName"],
                "lanIp": p.get("lanIp"), "wanIp": p.get("wanIp"), "lang": p.get("lang"),
                "appVersion": p.get("appVersion", ""), "statusTs": now(),
            })
            if g["online"] and not was_online:
                add_event("ok", f"Gateway {name} en ligne", gateway=name)
            elif not g["online"] and was_online:
                add_event("error", f"Gateway {name} hors ligne", gateway=name)
        elif sub == "scan" and p.get("status") == "ok":
            g["scan"] = {"ts": now(), "rings": p.get("rings", [])}
            add_event("info", f"{name} : {p.get('count', 0)} bague(s) à proximité", gateway=name)
        elif sub == "bind":
            g["bind"] = {"ts": now(), "status": p.get("status"), "error": p.get("error"), "mac": p.get("ringMac") or p.get("mac")}
            if p.get("status") == "ok":
                add_event("ok", f"{name} associé à la bague {p.get('ringMac')}", gateway=name, mac=p.get("ringMac"))
            elif p.get("status") == "error":
                add_event("error", f"{name} : association impossible ({ERROR_LABELS.get(p.get('error'), p.get('error'))})", gateway=name)
        elif sub == "unbind" and p.get("status") == "ok":
            add_event("warn", f"{name} : bague {p.get('ringMac')} dissociée", gateway=name, mac=p.get("ringMac"))
        elif sub == "lang" and p.get("status") == "ok":
            g["lang"] = p.get("lang")
            add_event("info", f"{name} : langue {p.get('lang')}", gateway=name)
    push_gateway(name)


def handle_ring(mac, sub, p):
    if sub == "cmd":
        return
    with state_lock:
        r = rings.setdefault(mac, new_ring(mac))
        gw = p.get("gateway") or r["gateway"]
        r["gateway"] = gw
        if p.get("ringModel"):
            r["model"] = p["ringModel"]

        if sub == "status":
            was_online, was_worn, was_ring = r["online"], r["worn"], r["ring"]
            r.update({
                "online": bool(p.get("online")), "ring": p.get("ring", r["ring"]),
                "name": p.get("ringName") or r["name"], "firmware": p.get("firmware") or r["firmware"],
                "battery": p.get("battery", r["battery"]), "charging": bool(p.get("charging")),
                "worn": p.get("worn", r["worn"]), "measuring": p.get("measuring"),
                "deviceName": p.get("deviceName") or r["deviceName"], "lanIp": p.get("lanIp"),
                "wanIp": p.get("wanIp"), "lang": p.get("lang"), "statusTs": now(),
                "unbound": p.get("ring") == "unbound",
            })
            label = r["name"] or mac
            if r["unbound"] and was_ring != "unbound":
                add_event("warn", f"{label} dissociée de {gw}", mac, gw)
            elif r["online"] and not was_online:
                add_event("ok", f"{label} : gateway {gw} en ligne", mac, gw)
            elif not r["online"] and was_online:
                add_event("error", f"{label} : gateway {gw} hors ligne", mac, gw)
            if r["online"] and r["ring"] != was_ring and r["ring"] == "disconnected":
                add_event("error", f"{label} : bague déconnectée (Bluetooth)", mac, gw)
            if r["online"] and r["ring"] != was_ring and r["ring"] == "connected" and was_ring in ("disconnected", "connecting"):
                add_event("ok", f"{label} : bague reconnectée", mac, gw)
            if r["worn"] is False and was_worn is not False:
                add_event("warn", f"{label} : bague retirée", mac, gw)
        else:
            handle_result(r, mac, sub, p, gw)
    push_ring(mac)


def handle_result(r, mac, sub, p, gw):
    status = p.get("status")
    req = p.get("reqId")
    label = r["name"] or mac
    if status == "measuring":
        r["pending"][sub] = {"since": now(), "reqId": req, "source": p.get("source")}
        r["errors"].pop(sub, None)
        return
    r["pending"].pop(sub, None)
    ts = p.get("ts") or now()
    if status == "ok":
        data = {k: v for k, v in p.items() if k not in (
            "reqId", "type", "status", "source", "ringMac", "ringModel", "gateway", "ts")}
        r["values"][sub] = {"ts": ts, "data": data, "source": p.get("source")}
        r["errors"].pop(sub, None)
        if sub == "all":  # on range aussi chaque valeur
            for k, key in (("hr", "hr"), ("spo2", "spo2"), ("temp", "temp"), ("hrv", "hrv"), ("stress", "stress")):
                if k in data:
                    r["values"][key] = {"ts": ts, "data": {"value": data[k]}, "source": p.get("source")}
            if "sbp" in data:
                r["values"]["bp"] = {"ts": ts, "data": {"sbp": data["sbp"], "dbp": data.get("dbp")}, "source": p.get("source")}
        if sub == "battery":
            r["battery"] = data.get("value", r["battery"])
            r["charging"] = bool(data.get("charging"))
        if sub in MEASURES:
            r["worn"] = True
        save_measure(ts, mac, gw, sub, "ok", data, None, req)
        if sub in MEASURES:
            add_event("ok", f"{label} : {sub.upper()} = {short_value(sub, data)}", mac, gw)
    elif status == "error":
        err = p.get("error", "error")
        r["errors"][sub] = {"ts": ts, "code": err, "label": ERROR_LABELS.get(err, err)}
        if err == "ring_removed":
            r["worn"] = False
        save_measure(ts, mac, gw, sub, "error", {}, err, req)
        level = "warn" if err in ("ring_removed", "cancelled") else "error"
        add_event(level, f"{label} : {sub.upper()} → {ERROR_LABELS.get(err, err)}", mac, gw)


def short_value(sub, d):
    if sub == "bp":
        return f"{d.get('sbp')}/{d.get('dbp')} mmHg"
    if sub == "all":
        return " · ".join(f"{k} {d[k]}" for k in ("hr", "spo2", "temp") if k in d)
    unit = {"hr": " bpm", "spo2": " %", "temp": " °C", "hrv": " ms"}.get(sub, "")
    return f"{d.get('value')}{unit}"


mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"qring-admin-{uuid.uuid4().hex[:8]}")


def publish_cmd(topic, payload):
    info = mqttc.publish(topic, json.dumps(payload), qos=1)
    return info.rc == mqtt.MQTT_ERR_SUCCESS


def start_mqtt():
    mqttc.on_connect = on_connect
    mqttc.on_disconnect = on_disconnect
    mqttc.on_message = on_message
    if MQTT_USER:
        mqttc.username_pw_set(MQTT_USER, MQTT_PASS)
    mqttc.reconnect_delay_set(min_delay=1, max_delay=30)
    mqttc.connect_async(MQTT_HOST, MQTT_PORT, keepalive=30)
    mqttc.loop_start()


def watchdog():
    """Gateway sans statut depuis OFFLINE_AFTER s → hors ligne ; mesure bloquée → expirée."""
    while True:
        time.sleep(10)
        t = now()
        changed_r, changed_g = [], []
        with state_lock:
            for mac, r in rings.items():
                if r["online"] and r["statusTs"] and t - r["statusTs"] > OFFLINE_AFTER:
                    r["online"] = False
                    changed_r.append(mac)
                    add_event("error", f"{r['name'] or mac} : plus de nouvelles de {r['gateway']} depuis {OFFLINE_AFTER} s", mac, r["gateway"])
                for k, pnd in list(r["pending"].items()):
                    if t - pnd["since"] > 120:
                        r["pending"].pop(k, None)
                        changed_r.append(mac)
            for name, g in gateways.items():
                if g["online"] and g["statusTs"] and t - g["statusTs"] > OFFLINE_AFTER:
                    g["online"] = False
                    changed_g.append(name)
                    add_event("error", f"Gateway {name} : aucun statut depuis {OFFLINE_AFTER} s", gateway=name)
        for m in set(changed_r):
            push_ring(m)
        for n in changed_g:
            push_gateway(n)


# ---------------------------------------------------------------------------- web

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            if request.path.startswith("/api") or request.path == "/stream":
                return jsonify({"error": "auth"}), 401
            return redirect(url_for("login"))
        return f(*a, **k)
    return w


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        if request.form.get("password") == ADMIN_PASSWORD:
            session["ok"] = True
            return redirect(url_for("index"))
        error = "Mot de passe incorrect"
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template("index.html", prefix=PREFIX, broker=f"{MQTT_HOST}:{MQTT_PORT}")


@app.route("/api/state")
@login_required
def api_state():
    with state_lock:
        return jsonify({
            "rings": list(rings.values()), "gateways": list(gateways.values()),
            "events": events[:100], "broker": mqttc.is_connected(), "now": now(),
        })


@app.route("/api/ring/<mac>/cmd", methods=["POST"])
@login_required
def api_ring_cmd(mac):
    body = request.get_json(force=True, silent=True) or {}
    cmd = body.get("cmd")
    if cmd not in MEASURES + SYNCS + ["cancel", "ping"]:
        return jsonify({"error": "commande inconnue"}), 400
    req = "adm-" + uuid.uuid4().hex[:8]
    payload = {"cmd": cmd, "reqId": req}
    if "day" in body:
        payload["day"] = int(body["day"])
    ok = publish_cmd(f"{PREFIX}/{topic_mac(mac)}/cmd", payload)
    with state_lock:
        r = rings.get(mac)
        label = (r and r["name"]) or mac
        if r and cmd in MEASURES + SYNCS:
            r["pending"][cmd] = {"since": now(), "reqId": req, "source": "admin"}
            r["errors"].pop(cmd, None)
    push_ring(mac)
    add_event("info", f"Commande {cmd.upper()} envoyée à {label}", mac)
    return jsonify({"ok": ok, "reqId": req})


@app.route("/api/gateway/<name>/cmd", methods=["POST"])
@login_required
def api_gateway_cmd(name):
    body = request.get_json(force=True, silent=True) or {}
    cmd = body.get("cmd")
    if cmd not in ("bind", "unbind", "scan", "lang", "ping"):
        return jsonify({"error": "commande inconnue"}), 400
    payload = {"cmd": cmd, "reqId": "adm-" + uuid.uuid4().hex[:8]}
    if cmd == "bind":
        mac = (body.get("mac") or "").strip()
        if len([c for c in mac if c.isalnum()]) != 12:
            return jsonify({"error": "MAC invalide"}), 400
        payload["mac"] = mac
    if cmd == "lang":
        if body.get("value") not in ("fr", "en", "ar"):
            return jsonify({"error": "langue invalide"}), 400
        payload["value"] = body["value"]
    ok = publish_cmd(f"{PREFIX}/gateway/{name}/cmd", payload)
    add_event("info", f"Commande {cmd} envoyée au gateway {name}", gateway=name)
    return jsonify({"ok": ok, "reqId": payload["reqId"]})


@app.route("/api/ring/<mac>/history")
@login_required
def api_history(mac):
    typ = request.args.get("type", "hr")
    limit = min(int(request.args.get("limit", "300")), 2000)
    with _db_lock, db() as con:
        rows = con.execute(
            "SELECT ts, gateway, status, data, error, req_id FROM measures WHERE mac=? AND type=? ORDER BY ts DESC LIMIT ?",
            (mac, typ, limit),
        ).fetchall()
    return jsonify([
        {"ts": x["ts"], "gateway": x["gateway"], "status": x["status"], "data": json.loads(x["data"] or "{}"),
         "error": x["error"], "reqId": x["req_id"]}
        for x in rows
    ])


@app.route("/api/ring/<mac>", methods=["DELETE"])
@login_required
def api_forget(mac):
    """Retire une bague du tableau (l'historique SQLite est conservé)."""
    with state_lock:
        rings.pop(mac, None)
    with _db_lock, db() as con:
        con.execute("DELETE FROM rings WHERE mac=?", (mac,))
    broadcast("ring_removed_from_list", {"mac": mac})
    return jsonify({"ok": True})


@app.route("/stream")
@login_required
def stream():
    q = queue.Queue(maxsize=500)
    subscribers.append(q)

    def gen():
        try:
            yield "retry: 3000\n\n"
            while True:
                try:
                    msg = q.get(timeout=20)
                    yield f"data: {msg}\n\n"
                except queue.Empty:
                    yield ": ping\n\n"  # garde la connexion ouverte
        finally:
            if q in subscribers:
                subscribers.remove(q)

    return Response(gen(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


def main():
    init_db()
    load_state()
    start_mqtt()
    threading.Thread(target=watchdog, daemon=True).start()
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False)


if __name__ == "__main__":
    main()
