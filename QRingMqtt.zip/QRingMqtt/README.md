# QRing MQTT

Application Android (téléphone + Android TV) qui relie une bague QRing / Colmi à un broker MQTT.
Un service en tâche de fond garde la bague et le broker connectés : les mesures se lancent
par MQTT même si l'application est fermée, et le service démarre avec l'appareil.

## Compiler

1. Ouvrir le dossier `QRingMqtt` dans Android Studio.
2. Laisser Gradle synchroniser (Kotlin 1.9.24, AGP 8.6.0, Gradle 8.10.2).
3. Run ▶ sur le téléphone ou la box TV.

Le SDK du fabricant est dans `app/libs/qring_sdk_1.0.0.7.aar`.

## Premier lancement

L'app demande une seule fois :
1. Bluetooth + localisation + notifications (obligatoire)
2. L'exclusion de l'optimisation de batterie (arrière-plan)
3. Le démarrage automatique (Xiaomi, Huawei, Oppo, Vivo… uniquement)

Puis **Accueil → Scanner** pour associer la bague.

Code PIN des écrans Journal et Réglages : **12345** (modifiable dans Réglages).

## Topics

`{prefixe}` = `eis/colmi` par défaut, `{MAC}` = MAC de la bague sans « : » (ex. `C4A15F22A4F1`).

| Topic | Sens | Contenu |
|---|---|---|
| `eis/colmi/{MAC}/cmd` | serveur → app | commande |
| `eis/colmi/{MAC}/status` | app → serveur (retenu) | statut chaque minute + Last Will |
| `eis/colmi/{MAC}/{type}` | app → serveur | résultat (`hr`, `spo2`, `temp`…) |
| `eis/colmi/gateway/{nom}/…` | | utilisé tant qu'aucune bague n'est associée |

## Commandes

Envoyer sur `…/cmd` du JSON `{"cmd":"spo2","reqId":"a7"}` ou simplement le texte `spo2`.
`reqId` est facultatif et renvoyé tel quel. `day` (0 = aujourd'hui, 1 = hier… jusqu'à 6) pour les synchronisations.

| Commande | Réponse |
|---|---|
| `hr` | `value` (bpm), `rri` (ms) |
| `spo2` | `value` (%) |
| `temp` | `value` (°C) |
| `bp` | `sbp`, `dbp` (mmHg) |
| `hrv` | `value` (ms) |
| `stress` | `value` (score) |
| `all` | `hr`, `rri`, `spo2`, `hrv`, `stress`, `temp`, `sbp`, `dbp` |
| `steps` | `steps`, `distance` (m), `calories`, `activeSeconds`, `hourly[24]` |
| `sleep` | `totalSeconds`, `deepSeconds`, `lightSeconds`, `remSeconds`, `awakeSeconds`, `phases`/`sequence` |
| `sedentary` | `stillMinutes`, `sedentaryMinutes`, `movingMinutes`, `sequence` |
| `workouts` | `count`, `workouts[]` |
| `history` | séries `hr`, `stress`, `hrv`, `spo2`, `temp` : `[{minute, value}]` |
| `battery` | `value` (%), `charging` |
| `info` | nom, firmware, matériel, batterie, fonctions supportées |
| `ping` | republie le statut |
| `cancel` | annule la mesure en cours |

Exemples :

```bash
mosquitto_pub -h 51.83.40.138 -p 1883 -u tvclient -P '***' -t eis/colmi/C4A15F22A4F1/cmd -m '{"cmd":"spo2","reqId":"a7"}'
mosquitto_sub -h 51.83.40.138 -p 1883 -u tvclient -P '***' -t 'eis/colmi/#' -v
```

Pendant une mesure : `{"reqId":"a7","type":"spo2","status":"measuring",…}`
Résultat :
```json
{"reqId":"a7","type":"spo2","status":"ok","value":97,"unit":"%","source":"mqtt",
 "ringMac":"C4:A1:5F:22:A4:F1","ringModel":"R06","gateway":"TV-salon","ts":1727184612}
```
Erreur :
```json
{"reqId":"a7","type":"spo2","status":"error","error":"ring_disconnected", …}
```
Codes d'erreur : `ring_disconnected`, `timeout`, `measure_failed`, `not_supported`,
`invalid_value`, `cancelled`, `no_data`, `unknown_command`.

## Statut (chaque minute, message retenu)

```json
{"online":true,"ring":"connected","ringMac":"C4:A1:5F:22:A4:F1","ringModel":"R06",
 "ringName":"R06_A4F1","firmware":"2.1.8","battery":82,"charging":false,
 "measuring":null,"gateway":"TV-salon","appVersion":"1.0.0","ts":1727184612}
```
`ring` : `connected`, `connecting`, `disconnected`, `bluetooth_off`, `no_ring`.
Si le gateway disparaît (réseau, courant), le broker publie `{"online":false,…}` (Last Will).
La batterie est lue à l'ouverture de l'app (ou avec la commande `battery`).

## Organisation du code

```
app/src/main/java/com/eis/qringmqtt/
  App.kt                  initialisation
  ble/RingManager.kt      connexion bague, reconnexion, scan, batterie, infos
  ble/Measurer.kt         mesures manuelles (cœur, SpO2, temp, tension, HRV, stress, tout)
  ble/Syncer.kt           pas, sommeil, sédentarité, entraînements, historique
  mqtt/MqttManager.kt     broker, Last Will, file hors ligne
  service/RingService.kt  service en tâche de fond + notification
  service/CommandProcessor.kt  file des commandes, JSON
  service/BootReceiver.kt démarrage automatique
  data/                   état partagé, réglages, historique local
  ui/                     écrans Compose (téléphone + TV)
```

## À vérifier sur la vraie bague

- Échelle de la température (conversion automatique dans `Measurer.tempC`).
- Unités du sommeil (minutes ou secondes, détection automatique dans l'interface).
- Stress / HRV de l'historique : valeurs brutes de la bague.
