package com.eis.qringmqtt.data

import org.json.JSONObject

/** État de la connexion Bluetooth avec la bague. */
enum class RingConn(val label: String, val json: String) {
    NO_RING("Aucune bague associée", "no_ring"),
    CONNECTING("Connexion…", "connecting"),
    CONNECTED("Connectée", "connected"),
    DISCONNECTED("Déconnectée", "disconnected"),
    BLUETOOTH_OFF("Bluetooth désactivé", "bluetooth_off")
}

/** État de la connexion au broker MQTT. */
enum class BrokerConn(val label: String) {
    OFFLINE("Hors ligne"),
    CONNECTING("Connexion…"),
    ONLINE("En ligne")
}

/**
 * Toutes les commandes acceptées sur eis/colmi/{mac}/cmd.
 * [measure] = mesure « live » sur la bague (une seule à la fois, avec chargement à l'écran).
 */
enum class Cmd(val key: String, val label: String, val measure: Boolean, val durationSec: Int) {
    HR("hr", "Fréquence cardiaque", true, 30),
    SPO2("spo2", "SpO2", true, 30),
    TEMP("temp", "Température", true, 30),
    BP("bp", "Tension", true, 45),
    HRV("hrv", "HRV", true, 45),
    STRESS("stress", "Stress", true, 45),
    ALL("all", "Tout mesurer", true, 60),
    STEPS("steps", "Pas", false, 0),
    SLEEP("sleep", "Sommeil", false, 0),
    SEDENTARY("sedentary", "Sédentarité", false, 0),
    WORKOUTS("workouts", "Entraînements", false, 0),
    HISTORY("history", "Historique", false, 0),
    BATTERY("battery", "Batterie", false, 0),
    INFO("info", "Infos bague", false, 0),
    PING("ping", "Ping", false, 0),
    CANCEL("cancel", "Annuler", false, 0);

    companion object {
        fun from(key: String?): Cmd? = values().firstOrNull { it.key.equals(key?.trim(), ignoreCase = true) }
    }
}

/** D'où vient une commande. */
enum class Source(val json: String, val label: String) { MQTT("mqtt", "MQTT"), MANUAL("manual", "manuel"), AUTO("auto", "auto") }

/** Une commande à exécuter (MQTT ou bouton). */
data class Command(
    val cmd: Cmd,
    val reqId: String?,
    val source: Source,
    val day: Int = 0
)

/** Une valeur affichée sur une carte + publiée sur MQTT. */
data class Reading(
    val type: String,            // hr, spo2, temp, bp, hrv, stress, battery, steps, sleep…
    val values: JSONObject,      // {"value":72,"rri":833} ou {"sbp":120,"dbp":80}…
    val ts: Long,                // secondes
    val source: Source
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type); put("values", values); put("ts", ts); put("source", source.json)
    }

    companion object {
        fun fromJson(o: JSONObject): Reading = Reading(
            o.getString("type"),
            o.optJSONObject("values") ?: JSONObject(),
            o.optLong("ts"),
            Source.values().firstOrNull { it.json == o.optString("source") } ?: Source.AUTO
        )
    }
}

/** Mesure en cours (pour le chargement à l'écran). */
data class ActiveMeasure(
    val cmd: Cmd,
    val source: Source,
    val startedAtMs: Long,
    val liveText: String? = null
)

/** Erreur temporaire affichée sur une carte. */
data class CardError(val message: String, val untilMs: Long)

/** Infos de la bague. */
data class RingInfo(
    val mac: String = "",
    val name: String = "",
    val model: String = "",
    val firmware: String = "",
    val hardware: String = "",
    val battery: Int? = null,
    val charging: Boolean = false,
    val supports: Set<String> = emptySet(),
    val supportsKnown: Boolean = false
)

/** Ligne du journal MQTT. */
data class LogEntry(
    val ts: Long,
    val kind: Kind,
    val topic: String,
    val payload: String
) {
    enum class Kind(val label: String) { IN("⬇ CMD"), OUT("⬆ RÉSULTAT"), STATUS("⬆ STATUT"), MEASURING("⬆ MESURE"), ERROR("⬆ ERREUR"), INFO("ℹ INFO") }
}

/** Un appareil trouvé pendant le scan. */
data class ScannedRing(val name: String, val mac: String, val rssi: Int)

/** Codes d'erreur envoyés sur MQTT. */
object Err {
    const val RING_DISCONNECTED = "ring_disconnected"
    const val TIMEOUT = "timeout"
    const val MEASURE_FAILED = "measure_failed"
    const val NOT_SUPPORTED = "not_supported"
    const val BUSY = "busy"
    const val INVALID_VALUE = "invalid_value"
    const val CANCELLED = "cancelled"
    const val UNKNOWN_COMMAND = "unknown_command"
    const val NO_DATA = "no_data"

    fun label(code: String): String = when (code) {
        RING_DISCONNECTED -> "Bague déconnectée"
        TIMEOUT -> "Pas de réponse de la bague"
        MEASURE_FAILED -> "Mesure échouée (bague mal portée ?)"
        NOT_SUPPORTED -> "Non supporté par cette bague"
        BUSY -> "Bague occupée"
        INVALID_VALUE -> "Valeur incohérente"
        CANCELLED -> "Mesure annulée"
        NO_DATA -> "Aucune donnée"
        else -> code
    }
}
