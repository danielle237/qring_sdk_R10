package com.eis.qringmqtt.ui

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eis.qringmqtt.ble.RingManager
import com.eis.qringmqtt.data.AppState
import com.eis.qringmqtt.data.BrokerConn
import com.eis.qringmqtt.data.RingConn
import com.eis.qringmqtt.service.CommandProcessor
import com.eis.qringmqtt.service.RingService
import kotlinx.coroutines.delay

enum class Tab(val label: String, val icon: ImageVector, val locked: Boolean) {
    HOME("Accueil", Icons.Filled.Home, false),
    ACTIVITY("Activité", Icons.Filled.DirectionsWalk, false),
    HISTORY("Historique", Icons.Filled.ShowChart, false),
    JOURNAL("Journal", Icons.Filled.List, true),
    SETTINGS("Réglages", Icons.Filled.Settings, true)
}

class MainActivity : ComponentActivity() {

    private val isTv: Boolean by lazy { detectTv(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QRingTheme {
                Box(Modifier.fillMaxSize().background(C.bg)) {
                    var onboarding by remember {
                        mutableStateOf(!AppState.prefs.onboardingDone || !Background.hasBlePermissions(this@MainActivity))
                    }
                    if (onboarding) {
                        Onboarding(isTv) {
                            AppState.prefs.onboardingDone = true
                            onboarding = false
                            startServiceIfAllowed()
                        }
                    } else {
                        AppRoot(isTv)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        startServiceIfAllowed()
        // La batterie est lue à chaque ouverture de l'app
        RingManager.requestBatteryOnOpen()
    }

    override fun onStop() {
        super.onStop()
        PinLock.lock()
    }

    private fun startServiceIfAllowed() {
        if (Background.hasBlePermissions(this)) RingService.start(applicationContext)
    }

    companion object {
        fun detectTv(ctx: Context): Boolean {
            val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
            return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
                    ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        }
    }
}

// ====================================================================== structure

@Composable
fun AppRoot(isTv: Boolean) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var scan by remember { mutableStateOf(false) }

    BackHandler(enabled = scan || tab != Tab.HOME) {
        if (scan) scan = false else tab = Tab.HOME
    }

    val content: @Composable () -> Unit = {
        if (scan) {
            ScanScreen(isTv) { scan = false }
        } else when (tab) {
            Tab.HOME -> HomeScreen(isTv) { scan = true }
            Tab.ACTIVITY -> ActivityScreen(isTv)
            Tab.HISTORY -> HistoryScreen(isTv)
            Tab.JOURNAL -> PinGate("Journal MQTT") { JournalScreen(isTv) }
            Tab.SETTINGS -> PinGate("Réglages") { SettingsScreen(isTv) { scan = true } }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (isTv) {
            Row(Modifier.fillMaxSize()) {
                SideNav(tab) { tab = it; scan = false }
                Box(Modifier.weight(1f).fillMaxHeight()) { content() }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                TopTitle(if (scan) "Scan" else tab.label)
                Box(Modifier.weight(1f).fillMaxWidth()) { content() }
                BottomNav(tab) { tab = it; scan = false }
            }
        }
        if (isTv) MeasureOverlay()
    }
}

@Composable
private fun TopTitle(title: String) {
    Text(
        title, color = C.text, fontSize = 22.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 2.dp)
    )
}

@Composable
private fun BottomNav(tab: Tab, onSelect: (Tab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.surface).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        Tab.values().forEach { t ->
            val sel = t == tab
            Column(
                Modifier.focusClick(RoundedCornerShape(12.dp)) { onSelect(t) }.padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box {
                    Icon(t.icon, t.label, tint = if (sel) C.accent else C.muted, modifier = Modifier.size(22.dp))
                    if (t.locked) Icon(
                        Icons.Filled.Lock, null, tint = C.muted,
                        modifier = Modifier.size(10.dp).align(Alignment.BottomEnd)
                    )
                }
                Text(t.label, color = if (sel) C.accent else C.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun SideNav(tab: Tab, onSelect: (Tab) -> Unit) {
    val ring by AppState.ring.collectAsState()
    val broker by AppState.broker.collectAsState()
    val info by AppState.info.collectAsState()
    Column(
        Modifier.width(230.dp).fillMaxHeight().background(C.surface).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("◎ QRing", color = C.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 12.dp))
        Tab.values().forEach { t ->
            val sel = t == tab
            Row(
                Modifier
                    .fillMaxWidth()
                    .focusClick(RoundedCornerShape(12.dp)) { onSelect(t) }
                    .background(if (sel) C.card else Color.Transparent)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(t.icon, null, tint = if (sel) C.accent else C.muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text(t.label, color = if (sel) C.text else C.muted, fontSize = 15.sp, modifier = Modifier.weight(1f))
                if (t.locked) Icon(Icons.Filled.Lock, null, tint = C.muted, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.weight(1f))
        StatusPill(
            "Bague", if (ring == RingConn.CONNECTED) "${info.name} · ${info.battery ?: "--"}%" else ring.label,
            if (ring == RingConn.CONNECTED) C.ok else if (ring == RingConn.CONNECTING) C.warn else C.err,
            Modifier.fillMaxWidth()
        )
        StatusPill(
            "Broker MQTT", broker.label,
            if (broker == BrokerConn.ONLINE) C.ok else if (broker == BrokerConn.CONNECTING) C.warn else C.err,
            Modifier.fillMaxWidth()
        )
    }
}

// ====================================================================== TV : mesure plein écran

@Composable
private fun MeasureOverlay() {
    val active by AppState.active.collectAsState()
    var hiddenFor by remember { mutableLongStateOf(0L) }
    val a = active ?: return
    if (hiddenFor == a.startedAtMs) return

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(a.startedAtMs) { while (true) { now = System.currentTimeMillis(); delay(500) } }
    val elapsed = ((now - a.startedAtMs) / 1000).toInt()
    val focus = remember { FocusRequester() }
    LaunchedEffect(a.startedAtMs) { delay(100); try { focus.requestFocus() } catch (_: Exception) {} }
    val color = METRICS.firstOrNull { it.cmd == a.cmd }?.color ?: C.spo2

    Box(Modifier.fillMaxSize().background(C.bg.copy(alpha = 0.97f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                if (a.source.json == "mqtt") "Mesure demandée par le serveur" else "Mesure en cours",
                color = C.muted, fontSize = 16.sp
            )
            RingProgress(elapsed / a.cmd.durationSec.toFloat(), color, Modifier.size(220.dp), 14.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(a.liveText ?: a.cmd.label, color = color, fontSize = if (a.liveText != null) 44.sp else 26.sp,
                        fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Text("$elapsed s / ${a.cmd.durationSec} s", color = C.muted, fontSize = 14.sp)
                }
            }
            Text("Gardez la bague au doigt et restez immobile", color = C.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.focusRequester(focus)
                        .focusClick(RoundedCornerShape(14.dp)) { CommandProcessor.cancelCurrent() }
                        .background(C.card).padding(horizontal = 28.dp, vertical = 12.dp)
                ) { Text("Annuler", color = C.text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                Box(
                    Modifier.focusClick(RoundedCornerShape(14.dp)) { hiddenFor = a.startedAtMs }
                        .background(C.card).padding(horizontal = 28.dp, vertical = 12.dp)
                ) { Text("Masquer", color = C.text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            }
        }
    }
}

// ====================================================================== premier lancement

@Composable
private fun Onboarding(isTv: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    // Revenir des réglages Android met à jour l'affichage
    LaunchedEffect(Unit) { while (true) { delay(1500); refresh++ } }

    val perms = remember(refresh) { Background.hasBlePermissions(ctx) }
    val battery = remember(refresh) { Background.isIgnoringBattery(ctx) }
    val autostart = remember { Background.hasAutostartPage(ctx) }

    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.widthIn(max = 560.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Bienvenue", color = C.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Pour mesurer en tâche de fond (même app fermée), l'application a besoin de quelques autorisations. " +
                        "Elles ne sont demandées qu'une seule fois.",
                color = C.muted, fontSize = 14.sp
            )
            Step(1, "Bluetooth, localisation et notifications", "Pour trouver et rester connecté à la bague.", perms) {
                launcher.launch(Background.runtimePermissions())
            }
            Step(2, "Fonctionner en arrière-plan", "Empêche Android d'arrêter le service.", battery) {
                Background.requestIgnoreBattery(ctx)
            }
            if (autostart) {
                Step(3, "Démarrage automatique", "Réglage du fabricant : activez QRing MQTT dans la liste.", null) {
                    Background.openAutostart(ctx)
                }
            }
            Spacer(Modifier.height(4.dp))
            BigButton("Continuer", Modifier.fillMaxWidth(), enabled = perms, onClick = onDone)
            if (!perms) Text("L'étape 1 est obligatoire.", color = C.warn, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Step(n: Int, title: String, text: String, done: Boolean?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .focusClick(RoundedCornerShape(16.dp), onClick = onClick)
            .background(C.card)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(50))
                .background(if (done == true) C.ok else C.accent.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) { Text(if (done == true) "✓" else "$n", color = Color.White, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = C.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(text, color = C.muted, fontSize = 12.sp)
        }
        Text(if (done == true) "OK" else "Autoriser", color = if (done == true) C.ok else C.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
