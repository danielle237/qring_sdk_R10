package com.eis.qringmqtt.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eis.qringmqtt.BuildConfig
import com.eis.qringmqtt.ble.RingManager
import com.eis.qringmqtt.data.AppState
import com.eis.qringmqtt.mqtt.MqttManager
import com.eis.qringmqtt.service.RingService

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(isTv: Boolean, onScan: () -> Unit) {
    val ctx = LocalContext.current
    val p = AppState.prefs
    val info by AppState.info.collectAsState()

    var host by remember { mutableStateOf(p.host) }
    var port by remember { mutableStateOf(p.port.toString()) }
    var user by remember { mutableStateOf(p.user) }
    var pass by remember { mutableStateOf(p.password) }
    var showPass by remember { mutableStateOf(false) }
    var prefix by remember { mutableStateOf(p.topicPrefix) }
    var gateway by remember { mutableStateOf(p.gatewayName) }
    var newPin by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(if (isTv) 20.dp else 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // ---------------- Broker
        SectionTitle("Broker MQTT")
        Panel(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Field("Hôte", host) { host = it; PinLock.touch() }
                Field("Port", port, KeyboardType.Number) { port = it.filter(Char::isDigit); PinLock.touch() }
                Field("Utilisateur", user) { user = it; PinLock.touch() }
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it; PinLock.touch() },
                    label = { Text("Mot de passe") }, singleLine = true,
                    visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showPass = !showPass }) {
                            Icon(if (showPass) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Afficher", tint = C.muted)
                        }
                    },
                    colors = fieldColors(), modifier = Modifier.fillMaxWidth()
                )
                Field("Préfixe des topics", prefix) { prefix = it; PinLock.touch() }
                Field("Nom du gateway (cet appareil)", gateway) { gateway = it; PinLock.touch() }
                val mac = info.mac.takeIf { it.isNotBlank() }
                Text(
                    "Topic : $prefix/${mac?.let { MqttManager.macForTopic(it) } ?: "gateway/$gateway"}/…",
                    color = C.muted, fontSize = 11.sp
                )
                BigButton("Enregistrer et reconnecter", Modifier.fillMaxWidth()) {
                    p.host = host; p.port = port.toIntOrNull() ?: 1883; p.user = user; p.password = pass
                    p.topicPrefix = prefix; p.gatewayName = gateway
                    RingService.restartMqtt(ctx)
                    toast(ctx, "Réglages enregistrés")
                }
            }
        }

        // ---------------- Bague
        SectionTitle("Bague")
        Panel(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                InfoLine("Nom", info.name.ifBlank { "—" })
                InfoLine("Adresse MAC", info.mac.ifBlank { "—" })
                InfoLine("Modèle", info.model.ifBlank { "—" })
                InfoLine("Firmware", info.firmware.ifBlank { "—" })
                InfoLine("Matériel", info.hardware.ifBlank { "—" })
                InfoLine("Batterie", info.battery?.let { "$it %" + if (info.charging) " (en charge)" else "" } ?: "—")
                if (info.supports.isNotEmpty()) {
                    Text("Fonctions supportées", color = C.muted, fontSize = 11.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        METRICS.filter { it.cmd.measure }.forEach { m ->
                            val ok = !info.supportsKnown || m.key in info.supports
                            Text(
                                m.label, fontSize = 11.sp,
                                color = if (ok) C.ok else C.muted,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    BigButton("Changer de bague", Modifier.weight(1f), onClick = onScan)
                    BigButton("Reconnecter", Modifier.weight(1f), color = C.card2) { RingManager.reconnectNow() }
                }
            }
        }

        // ---------------- Tâche de fond
        SectionTitle("Fonctionnement en arrière-plan")
        Panel(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (Background.isIgnoringBattery(ctx)) "✓ Optimisation de batterie désactivée pour l'app"
                    else "⚠ L'optimisation de batterie peut arrêter le service",
                    color = if (Background.isIgnoringBattery(ctx)) C.ok else C.warn, fontSize = 13.sp
                )
                BigButton("Autoriser l'arrière-plan", Modifier.fillMaxWidth(), color = C.card2) {
                    Background.requestIgnoreBattery(ctx)
                }
                if (Background.hasAutostartPage(ctx)) {
                    BigButton("Autoriser le démarrage automatique", Modifier.fillMaxWidth(), color = C.card2) {
                        Background.openAutostart(ctx)
                    }
                }
            }
        }

        // ---------------- PIN
        SectionTitle("Code PIN")
        Panel(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Field("Nouveau code PIN (4 à 8 chiffres)", newPin, KeyboardType.NumberPassword) {
                    newPin = it.filter(Char::isDigit).take(8); PinLock.touch()
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton("Changer le PIN", Modifier.weight(1f), enabled = newPin.length >= 4) {
                        p.setPin(newPin); newPin = ""; toast(ctx, "Code PIN modifié")
                    }
                    BigButton("Verrouiller", Modifier.weight(1f), color = C.card2) { PinLock.lock() }
                }
            }
        }
        Text("QRing MQTT v${BuildConfig.VERSION_NAME}", color = C.muted, fontSize = 11.sp, modifier = Modifier.padding(8.dp))
    }
}

@Composable
private fun Field(label: String, value: String, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        visualTransformation = if (type == KeyboardType.NumberPassword) PasswordVisualTransformation() else VisualTransformation.None,
        colors = fieldColors(), modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = C.accent, unfocusedBorderColor = C.line,
    focusedTextColor = C.text, unfocusedTextColor = C.text,
    focusedLabelColor = C.accent, unfocusedLabelColor = C.muted, cursorColor = C.accent
)

@Composable
private fun InfoLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = C.muted, fontSize = 12.sp)
        Text(v, color = C.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
