COLMI / DANY - FLASK COMPLET
=============================

Contenu :
- app.py
- db_service.py
- templates/index.html
- templates/history.html
- templates/telegram_users.html
- templates/_device_rows.html
- requirements.txt
- .env.example

Cette version inclut :
- MQTT TCP Paho, topic eis/colmi/#
- flux MQTT brut
- PostgreSQL/TimescaleDB via db_service.py
- Batterie / HR / SpO2 / Fatigue / Health-check / Steps
- statuts En cours / In progress
- En attente de données / Waiting for data
- Terminé / Done
- timeout mesure en_cours > 30 min
- OUTSIDE / HORS PORTEE conservé
- historique
- utilisateurs Telegram
- affectation Telegram existante
- notification Telegram automatique lors d'une NOUVELLE affectation

Installation :
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env
    nano .env

Lancement :
    python3 app.py

Lors d'un POST /api/telegram/<mac> :
- l'affectation est enregistrée
- si elle est nouvelle, Flask envoie un message à id_telegram
- si Telegram échoue, l'affectation reste enregistrée
- la réponse JSON contient notification_sent et notification_error


TELEGRAM UI BILINGUE
--------------------

Colonne Action :
  📜 Historique / History
  ✈️ Telegram

Popup :
  Utilisateur / User
  Voir / View
  Historique / History
  LIVE
  Alertes / Alerts
  Affecter / Assign
  Retirer / Remove

Notification nouvelle affectation :
  Nouvelle bague affectée / New ring assigned
  Ouvrir la bague / Open ring

Statuts capteurs :
  En cours / In progress
  En attente de données / Waiting for data
  Terminé / Done


CORRECTIF OUTSIDE 4 CAPTEURS
----------------------------

Quand le topic /outside reçoit :

    fault_code = device_not_found
ou :
    fault_code = device_out_of_range

les 4 capteurs passent maintenant immédiatement à :

    Hors portée / Out of range

Capteurs concernés :
- HR
- SpO2
- Fatigue
- Health-check

Les anciennes valeurs Fatigue et Health-check ne restent plus affichées.

PostgreSQL :
ring_current_state met également à NULL :
- heart_rate
- spo2
- fatigue
- health_check

Les anciennes mesures historiques ring_measurements ne sont pas supprimées.

DIAGNOSTIC MQTT
---------------
Le bandeau supérieur affiche maintenant clairement :

    Flask reçoit MQTT / Flask is receiving MQTT

avec :
- nombre de messages reçus
- dernier timestamp
- dernier topic


DIAGNOSTIC POSTGRESQL DANS FLASK
--------------------------------

Le dashboard affiche maintenant sous MQTT :

    ✅ PostgreSQL connecté / PostgreSQL connected

ou :

    ❌ PostgreSQL non connecté / PostgreSQL not connected

Informations affichées :
- Insertions OK / Successful inserts
- File / Queue
- Abandonnés / Dropped
- Erreurs insertion / Insert errors
- Dernière insertion réussie
- Dernier topic inséré

En cas d'erreur d'insertion, un warning reste visible :

    ⚠ Erreur insertion PostgreSQL / PostgreSQL insert error

avec :
- heure
- topic MQTT
- message d'erreur

La dernière erreur reste mémorisée même si PostgreSQL se reconnecte ensuite,
afin de ne pas masquer un problème transitoire.


ENTETE COMPACTE MQTT / POSTGRESQL
---------------------------------

Les gros bandeaux ont été remplacés par deux boutons déroulants :

    ✅ MQTT connecté / MQTT connected ▼

    ✅ PostgreSQL connecté / PostgreSQL connected ▼

ou, selon l'état :

    ⚠ PostgreSQL connecté — warning / connected — warning ▼
    ❌ PostgreSQL non connecté / not connected ▼

Les détails restent cachés par défaut et apparaissent uniquement au clic.

Le détail PostgreSQL contient :
- insertions OK
- queue
- dropped
- insert errors
- dernière insertion OK
- dernière erreur d'insertion
- heure
- topic

Le haut du dashboard reste donc beaucoup plus compact.


============================================================
TELEGRAM V2 + QR PAIRING
============================================================

1. AFFICHAGE LIVE TELEGRAM

Le LIVE affiche :

    💍 COLMI R10_6401

    🟢 ONLINE — PORTÉ / WORN
ou
    🟠 ONLINE — NON PORTÉ / NOT WORN
ou
    🟡 HORS PORTÉE / OUT OF RANGE

Puis :
- batterie
- état charging / not charging
- HR samples
- SpO2 samples
- Fatigue samples
- Health-check samples
- HRV
- température
- pas / distance / calories / RSSI / wear_status

Quand /outside arrive :
HR + SpO2 + Fatigue + Health-check passent immédiatement à
"Hors portée / Out of range".

2. ALERTE HORS PORTEE TELEGRAM

Lors du PREMIER passage vers hors portée :
- tous les TELEGRAM_ADMIN_IDS reçoivent une alerte ;
- les utilisateurs affectés avec can_receive_alerts=TRUE la reçoivent aussi.

Les répétitions du même état hors portée ne doivent pas spammer Telegram.

3. HISTORIQUE

Flux :
    HISTORIQUE
       -> HR / SpO2 / Fatigue / Health
       -> 1h / 24h / 7 jours / 30 jours
       -> affichage des mesures et samples PostgreSQL

4. NOTIFICATION AFFECTATION

Une nouvelle affectation faite dans Flask envoie :
    Nouvelle bague affectée / New ring assigned

avec bouton :
    Ouvrir la bague / Open ring

5. NOTIFICATION DESAFFECTATION

Une suppression d'affectation dans Flask envoie :
    Bague désaffectée / Ring unassigned

La route Flask garde id_telegram avant la suppression,
supprime l'accès, puis notifie uniquement si la suppression a réussi.

6. QR PAIRING - PRINCIPE SECURISE

IMPORTANT :
Le QR NE FAIT PAS une affectation automatique.

Le QR contient un deep-link Telegram :
    https://t.me/BOT?start=pair_<TOKEN>

Quand le client le scanne :
1) Telegram ouvre le bot ;
2) le bot sait exactement quelle bague est demandée ;
3) une demande PENDING est enregistrée ;
4) les administrateurs Telegram reçoivent :
       Autoriser / Approve
       Refuser / Reject
5) si l'admin accepte, ring_telegram_access est créé/réactivé ;
6) le client reçoit la notification d'affectation.

Ainsi, une photo du QR ne suffit pas pour voler une bague :
l'administrateur doit toujours accepter.

7. INSTALLATION QR

Exécuter UNE FOIS :

    psql -d dany -f qr_pairing.sql

Configurer .env :

    TELEGRAM_BOT_TOKEN=...
    TELEGRAM_BOT_USERNAME=NomDuBot
    TELEGRAM_ADMIN_IDS=123456789
    PAIRING_DEFAULT_ALERTS=0

8. GENERER LE QR D'UNE BAGUE

    python generate_pairing_qr.py \
        --mac 30:32:42:32:64:01

Le script :
- génère un token aléatoire ;
- désactive l'ancien token actif de la bague ;
- enregistre le nouveau token PostgreSQL ;
- crée un PNG QR.

Le QR n'expose pas directement la MAC comme secret de pairing.

9. LANCER LE BOT

    python telegram_bot.py

Commandes principales :
    /start
    /rings
    /status

============================================================


============================================================
APPROBATION QR DEPUIS LE DASHBOARD FLASK
============================================================

Le même pairing QR peut maintenant être traité depuis :

1) Telegram admin
2) Dashboard Flask admin

Nouvelle page :

    /telegram/pairing

Elle montre :
- client Telegram
- Telegram ID
- bague
- MAC
- date de demande
- état pending / approved / rejected
- source de la décision

Pour une demande PENDING :

    ✅ Autoriser / Approve
    ❌ Refuser / Reject

APPROBATION FLASK
-----------------
Quand l'admin clique Autoriser :
1) la demande passe à approved ;
2) ring_telegram_access est créé/réactivé ;
3) les permissions View / History / LIVE sont activées ;
4) can_receive_alerts dépend de PAIRING_DEFAULT_ALERTS ;
5) le client reçoit la notification Telegram d'affectation ;
6) il reçoit le bouton "Ouvrir la bague / Open ring".

REFUS FLASK
-----------
Quand l'admin clique Refuser :
1) la demande passe à rejected ;
2) aucun ring_telegram_access n'est créé ;
3) le client reçoit une notification Telegram de refus.

IMPORTANT SQL
-------------
Réexécuter le fichier :

    psql -d dany -f qr_pairing.sql

Il contient des ALTER TABLE ... ADD COLUMN IF NOT EXISTS,
donc il peut être relancé sur une installation qui avait déjà
la première version QR.

Les nouvelles colonnes permettent de savoir si la décision vient de :
- telegram
- flask

============================================================


============================================================
SMART REFRESH / RELOAD INTELLIGENT
============================================================

Le dashboard principal ne recharge plus toute la page.

La page HTML complète est chargée UNE SEULE FOIS.

Ensuite :

Toutes les ~2 secondes :
    GET /api/table
        -> met à jour uniquement <tbody id="device-table-body">

    GET /api/mqtt/raw
        -> met à jour uniquement <div id="mqtt-raw-console">

Toutes les 5 secondes :
    GET /api/status
        -> met à jour uniquement :
           - bouton MQTT
           - détail MQTT
           - bouton PostgreSQL
           - détail PostgreSQL

Les fragments ne sont remplacés que lorsque leur HTML a réellement changé.

AVANTAGES
---------
- plus de window.location.reload()
- popup Telegram ne se ferme plus
- popup Historique ne se ferme plus
- menu MQTT/PostgreSQL ouvert reste ouvert
- boutons QR / pairing ne bougent pas
- moins de trafic HTTP
- moins de scintillement
- tableau rings et MQTT continuent d'être temps réel

ROUTES UTILISEES
----------------
    /api/table
    /api/mqtt/raw
    /api/status

Aucun changement dans :
- acquisition MQTT
- PostgreSQL
- notifications Telegram
- affectation / désaffectation
- QR pairing
- approbation Flask / Telegram
============================================================


============================================================
TELEGRAM - ETATS COMPLETS + REFRESH MANUEL + WARNING LIVE
============================================================

ETAT GLOBAL
-----------
Priorité :

1. device_not_found / device_out_of_range
   -> 🟡 HORS PORTÉE / OUT OF RANGE

2. bague joignable + charging=True
   -> 🟠 ONLINE — NON PORTÉ / NOT WORN

3. bague joignable + plusieurs measurement_failed récents
   -> 🟠 ONLINE — NON PORTÉ / NOT WORN

4. une mesure physiologique valide
   -> 🟢 ONLINE — PORTÉ / WORN

Par défaut :
    TELEGRAM_WEAR_FAILURE_THRESHOLD=2
    TELEGRAM_WEAR_FAILURE_WINDOW_SECONDS=180

Donc deux capteurs physiologiques en measurement_failed dans 3 minutes
suffisent pour considérer la bague ONLINE mais NON PORTÉE.

AFFICHAGE measurement_failed
----------------------------
Si la bague est inférée NON PORTÉE :

    🟠 Mesure impossible — Bague non portée /
       Measurement failed — Ring not worn

On n'affiche plus "Non connecté" car le BLE fonctionne.

BOUTON ACTUALISER
-----------------
Le LIVE contient :

    🔄 Actualiser / Refresh

Au clic :
- l'état est relu depuis PostgreSQL ;
- le message LIVE est actualisé ;
- Telegram affiche une vraie alerte popup :

    ✅ LIVE actualisé / LIVE refreshed

Même si le texte n'a pas changé, l'alerte de confirmation apparaît.

FIN DU LIVE
-----------
Par défaut :

    TELEGRAM_LIVE_SESSION_MINUTES=30
    TELEGRAM_LIVE_WARNING_MINUTES=5

Moins de 5 minutes avant la fin :
une notification UNIQUE est envoyée :

    ⚠️ LIVE bientôt arrêté / LIVE ending soon

avec bouton :

    🔄 Prolonger 30 min / Extend

Si le bouton est utilisé :
- expiration repoussée de 30 minutes ;
- warning réarmé ;
- DB telegram_live_sessions mise à jour.

HORS PORTEE
-----------
Hors portée ne ferme JAMAIS le LIVE.

Le LIVE reste ouvert :
    HORS PORTEE
      -> retour BLE
      -> ONLINE PORTÉ ou ONLINE NON PORTÉ
============================================================


============================================================
PANNEAUX MQTT / POSTGRESQL - ETAT PERSISTANT
============================================================

Le clic sur MQTT ou PostgreSQL mémorise maintenant l'état ouvert/fermé
dans localStorage.

Comportement :
- refresh AJAX 5 s : le panneau reste ouvert ;
- refresh des rings : aucun effet sur le panneau ;
- refresh MQTT brut : aucun effet sur le panneau ;
- F5 / vrai reload navigateur : l'état ouvert est restauré ;
- retour sur le dashboard : l'état précédent est restauré ;
- seul un nouveau clic utilisateur ferme le panneau.

Clés navigateur :
- dany_status_panel_mqtt-status-detail_open
- dany_status_panel_postgres-status-detail_open
============================================================


============================================================
CORRECTION CYCLE COURANT - DASHBOARD
============================================================

Problème corrigé :

Un nouveau cycle pouvait afficher simultanément :
- HR du nouveau cycle
- SpO2 du nouveau cycle
- Fatigue de l'ancien cycle
- Health-check "en_cours" de l'ancien cycle

Exemple observé :
    HR      12:17:34  OK
    SpO2    12:17:36  en cours
    Fatigue 12:14:56  OK        <- ancien cycle
    Health  12:14:56  en cours  <- ancien cycle

NOUVELLE LOGIQUE
-----------------
Séquence :

    HR -> SpO2 -> Fatigue -> Health-check

Quand un nouveau stade arrive, les stades suivants qui contiennent encore
des timestamps plus anciens sont remis à :

    En attente / Waiting
    Valeur : —

Le timestamp ancien n'est plus affiché dans le bloc du cycle courant.

Exemple pendant SpO2 :

    HR          Terminé / Done
    SpO2        En cours / In progress
    Fatigue     En attente / Waiting
    Health      En attente / Waiting

Les anciennes mesures restent :
- dans PostgreSQL
- dans Historique

Elles ne sont simplement plus mélangées au cycle courant.

PROTECTION MESSAGES MQTT RETARDES
---------------------------------
La comparaison des timestamps empêche également un vieux message MQTT
arrivé en retard d'effacer un bloc plus récent.
============================================================


============================================================
TELEGRAM - SYNCHRONISATION ONLINE + TIMESTAMP BATTERIE
============================================================

CORRECTION HORS PORTEE / ONLINE
-------------------------------

Avant :
un ancien message device_out_of_range pouvait laisser :

    ble_status = device_out_of_range

même après réception d'une nouvelle Batterie / HR / SpO2.
Le LIVE pouvait donc afficher simultanément :

    HORS PORTEE
    + nouvelles mesures valides

Ce cas est maintenant interdit.

Toute NOUVELLE donnée BLE valide :
- batterie
- steps
- HR
- SpO2
- fatigue
- health-check
- température
- RSSI / autre donnée reconnue

remet immédiatement :

    online = True
    outside = False
    ble_status = "ok"
    outside_timestamp = None

Une ancienne valeur simplement présente dans le cache/DB ne suffit pas :
c'est la réception d'une nouvelle donnée qui fait revenir ONLINE.

TIMESTAMP BATTERIE
------------------
Le LIVE Telegram affiche maintenant :

    🔋 Batterie : 16 %
    🔌 Statut : Débranchée du chargeur / Not charging
    🕒 Batterie / Battery timestamp : 23/09 12:33:01

Le timestamp est :
1) pris directement du message MQTT batterie en LIVE ;
2) rechargé depuis ring_measurements après redémarrage du bot.
============================================================


============================================================
TELEGRAM - ECRAN RING EN TEMPS REEL
============================================================

L'écran visible après avoir choisi une bague affiche maintenant :

    💍 COLMI R10_6401

    🟢 ONLINE — PORTÉ / WORN
    MAC : 30:32:42:32:64:01

    🔋 Batterie : 16 %
    🔌 Statut : Débranchée du chargeur / Not charging
    🕒 Batterie / Battery timestamp : 23/09 12:33:01

    Choisis une fonction / Choose a function:

Cet écran est maintenant réellement actualisé depuis MQTT, sans avoir
besoin d'entrer dans LIVE.

Par défaut :
    TELEGRAM_RING_OVERVIEW_REFRESH_SECONDS=2

Comportement :
- nouvelle batterie -> pourcentage + statut charge + timestamp actualisés ;
- nouvelle donnée valide -> OUT OF RANGE est annulé et ONLINE apparaît ;
- device_out_of_range -> HORS PORTEE apparaît immédiatement ;
- mesure physiologique OK -> l'état de port peut repasser à PORTÉ ;
- charging=True -> ONLINE NON PORTÉ selon la logique existante.

Quand l'utilisateur clique sur :
- LIVE
- HISTORIQUE
- Mes rings
- un autre bouton

l'auto-refresh de cet écran Ring est arrêté pour ne pas écraser
la nouvelle page Telegram.
============================================================


============================================================
TELEGRAM - SUPPRESSION DU WARNING HORS PORTEE AU RETOUR ONLINE
============================================================

Avant :
Telegram pouvait conserver en bas du chat un ancien message :

    ⚠️ COLMI R10_6401
    🟡 HORS PORTÉE / OUT OF RANGE

même après que l'écran de la bague soit repassé ONLINE.

Maintenant :
1) le bot mémorise le message_id de chaque alerte HORS PORTEE ;
2) dès qu'une NOUVELLE donnée BLE valide arrive ;
3) update_live_state signale back_online_transition=True ;
4) l'écran Ring / LIVE repasse ONLINE ;
5) le message d'alerte HORS PORTEE devenu obsolète est SUPPRIMÉ du chat.

Exemple :

    13:03:57 -> HORS PORTEE
                -> warning Telegram envoyé

    13:05:04 -> nouvelle batterie MQTT
                -> ONLINE
                -> ancien warning HORS PORTEE supprimé

Le warning n'est donc plus visible sous l'état courant quand la bague
est revenue à portée.

La suppression concerne tous les destinataires auxquels le bot avait
envoyé cette alerte pendant le processus courant.
============================================================


============================================================
TELEGRAM - ARRET LIVE QUAND L'UTILISATEUR QUITTE LE LIVE
============================================================

Règle finale :

HORS PORTEE BLUETOOTH
---------------------
Ne ferme PAS le LIVE.

Le LIVE reste actif et continue automatiquement quand la bague revient.

SORTIE VOLONTAIRE DU LIVE
-------------------------
Le LIVE est maintenant arrêté immédiatement si l'utilisateur :

- clique "Mes rings"
- clique "Historique"
- revient sur l'écran "Ring"
- utilise /rings
- utilise /start
- clique "Arrêter LIVE"

Dans tous ces cas :
1) la session est retirée de live_sessions ;
2) telegram_live_sessions.active passe à FALSE en PostgreSQL ;
3) aucun warning "< 5 minutes" ne sera envoyé plus tard ;
4) si le warning avait déjà été envoyé, le bot tente de le supprimer.

PROTECTION CONTRE UNE RACE CONDITION
------------------------------------
Avant d'envoyer le warning "LIVE bientôt arrêté", le bot vérifie encore
que la session existe réellement.

Si l'utilisateur quitte LIVE pendant l'envoi du warning, le message
est supprimé immédiatement après son envoi.

PROLONGATION
------------
Quand l'utilisateur clique :

    Prolonger 30 min / Extend

l'ancien warning est supprimé puis :
- expires_at est repoussé ;
- warning_sent repasse à False ;
- un nouveau warning pourra être envoyé avant la nouvelle expiration.
============================================================


============================================================
TELEGRAM MINI APP / WEB APP PAR BAGUE + TRACKING POSTGRESQL
============================================================

Cette version part de la dernière version Telegram DANY
(stop LIVE on exit) et ajoute une Mini App / Web App par bague.

BOUTON TELEGRAM
---------------
Dans l'écran Ring :

    [ 📡 LIVE ] [ 📊 HISTORIQUE ]
    [ 🌐 VUE WEB / WEB APP ]
    [ ⬅️ Mes rings ]

Le bouton n'apparaît que si :

    TELEGRAM_WEBAPP_BASE_URL

est renseigné.

Exemple :

    TELEGRAM_WEBAPP_BASE_URL=https://dany.embedded-systems.biz

La page ouverte est :

    /webapp/ring/303242326401

La MAC sélectionne seulement la bague.
Elle n'est PAS utilisée comme secret.

AUTHENTIFICATION
----------------
La Web App transmet Telegram.WebApp.initData à Flask.

Flask :
1) vérifie la signature HMAC avec TELEGRAM_BOT_TOKEN ;
2) vérifie auth_date ;
3) récupère le Telegram user id signé ;
4) vérifie t_user_app_telegram ;
5) vérifie ring_telegram_access.can_view ;
6) vérifie que l'affectation et la bague sont actives.

Donc changer manuellement la MAC dans l'URL ne donne pas accès
à une bague non affectée.

INSTALLATION SQL
----------------

    psql -d dany -f telegram_webapp.sql

Tables ajoutées :

    telegram_webapp_sessions
    telegram_webapp_events

telegram_webapp_sessions contient notamment :

    telegram_user_id
    ring_id
    opened_at
    last_seen_at
    closed_at
    active

telegram_webapp_events conserve :

    OPEN
    CLOSE

Les heartbeats ne créent PAS une nouvelle ligne d'événement :
ils mettent seulement last_seen_at à jour afin d'éviter de gonfler la base.

ADMIN
-----
Nouvelle page :

    /telegram/webapp

Elle affiche :

    utilisateur Telegram
    Telegram ID
    bague
    MAC
    heure d'ouverture
    dernière activité
    heure de fermeture
    actif / inactif

Le dashboard principal contient aussi :

    🌐 Sessions Web App

ACTIF / INACTIF
---------------
Par défaut :

    TELEGRAM_WEBAPP_HEARTBEAT_SECONDS=20
    TELEGRAM_WEBAPP_ACTIVE_SECONDS=60

Donc si le navigateur disparaît sans envoyer CLOSE,
la session passe quand même inactive après environ 60 secondes.

WEB APP TEMPS REEL
------------------
La page affiche :

    statut de connexion
    batterie
    statut charging
    timestamp batterie
    HR
    SpO2
    Fatigue
    Health-check
    Steps
    RSSI

Elle interroge Flask toutes les 2 secondes et ne voit qu'une seule bague.

SECURITE / DEPLOIEMENT
----------------------
En production Telegram Mini App :
- utiliser HTTPS ;
- ne jamais exposer TELEGRAM_BOT_TOKEN au navigateur ;
- ne jamais faire confiance à initDataUnsafe ;
- la validation initData est faite côté Flask ;
- le token de session Web App est aléatoire et reste côté client/serveur.

IMPORTANT :
la page /telegram/webapp est une page ADMIN.
Le projet DANY actuel n'a pas encore de login Flask global :
si Flask est exposé sur Internet, protéger l'admin via reverse proxy,
VPN ou authentification avant mise en production.
============================================================


ADMIN WEB APP - SMART REFRESH
-----------------------------
La page /telegram/webapp ne recharge pas toute la page.

Toutes les 5 secondes :
    GET /api/telegram/webapp/sessions

met à jour uniquement :
- les compteurs
- la table des sessions
- Actif / Inactif
- last_seen_at

Aucun window.location.reload().
