import os
import re
import json
import threading
import hashlib
import hmac
import time
from urllib.parse import parse_qsl
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

# Charge les variables du fichier .env situe a cote de app.py
load_dotenv(Path(__file__).resolve().parent / ".env")

from flask import Flask, render_template, redirect, url_for, request, jsonify
import paho.mqtt.client as mqtt

from db_service import (
    enqueue_mqtt_message,
    start_db_worker,
    get_db_status,
    test_database,
    query_measurement_history,
    list_telegram_access,
    upsert_telegram_access,
    delete_telegram_access,
    list_telegram_users,
    set_telegram_user_active,
    list_pairing_requests,
    approve_pairing_request_admin,
    reject_pairing_request_admin,

    # Telegram Mini App / Web App
    get_webapp_ring_access,
    create_webapp_session,
    get_webapp_session,
    close_webapp_session,
    list_webapp_sessions,
    get_webapp_session_stats,
)

MQTT_HOST = os.getenv("MQTT_HOST", "51.83.40.138")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("MQTT_USER", "")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "eis/colmi/#")

FLASK_HOST = os.getenv("FLASK_HOST", "0.0.0.0")
FLASK_PORT = int(os.getenv("FLASK_PORT", "5000"))
DEVICE_OFFLINE_SECONDS = int(os.getenv("DEVICE_OFFLINE_SECONDS", "360"))
AUTO_REFRESH_SECONDS = int(os.getenv("AUTO_REFRESH_SECONDS", "2"))
SENSOR_STALE_SECONDS = int(os.getenv("SENSOR_STALE_SECONDS", "1800"))

# Ordre réel du cycle santé publié par la gateway.
# Sert uniquement à éviter d'afficher les valeurs du cycle précédent
# pendant qu'un nouveau cycle est déjà en cours.
SENSOR_CYCLE_SEQUENCE = (
    "heartRate",
    "spo2",
    "fatigue",
    "healthCheck",
)
STATE_FILE = Path(os.getenv("STATE_FILE", "colmi_state.json"))

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

TELEGRAM_WEBAPP_MAX_AGE_SECONDS = max(
    60,
    int(
        os.getenv(
            "TELEGRAM_WEBAPP_MAX_AGE_SECONDS",
            "86400",
        )
    ),
)

TELEGRAM_WEBAPP_HEARTBEAT_SECONDS = max(
    10,
    int(
        os.getenv(
            "TELEGRAM_WEBAPP_HEARTBEAT_SECONDS",
            "20",
        )
    ),
)

app = Flask(__name__)
state_lock = threading.RLock()
devices_state = {}
raw_messages = []
mqtt_status = {
    "connected": False,
    "message": "Connexion MQTT en cours...",
    "last_error": None,
    "message_count": 0,
    "last_message_time": None,
    "last_topic": None,
}


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def safe_str(value, default="N/A"):
    if value is None:
        return default
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def parse_datetime(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def format_datetime(value):
    dt = parse_datetime(value)
    if not dt:
        return safe_str(value, "-")
    return dt.astimezone().strftime("%d/%m/%Y %H:%M:%S")




# ============================================================
# TELEGRAM MINI APP / WEB APP
# ============================================================

def normalize_webapp_ring_key(value):
    return re.sub(
        r"[^0-9a-fA-F]",
        "",
        str(value or ""),
    ).lower()


def validate_telegram_webapp_init_data(init_data):
    """
    Validation serveur de Telegram.WebApp.initData avec le BOT TOKEN.

    Ne jamais utiliser initDataUnsafe comme preuve d'identité.
    """
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN absent : "
            "validation WebApp impossible"
        )

    if not init_data:
        raise ValueError(
            "initData Telegram absent"
        )

    pairs = dict(
        parse_qsl(
            str(init_data),
            keep_blank_values=True,
        )
    )

    received_hash = pairs.pop(
        "hash",
        None,
    )

    if not received_hash:
        raise ValueError(
            "hash Telegram absent"
        )

    data_check_string = "\n".join(
        f"{key}={pairs[key]}"
        for key in sorted(pairs)
    )

    secret_key = hmac.new(
        b"WebAppData",
        TELEGRAM_BOT_TOKEN.encode("utf-8"),
        hashlib.sha256,
    ).digest()

    calculated_hash = hmac.new(
        secret_key,
        data_check_string.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(
        calculated_hash,
        str(received_hash),
    ):
        raise PermissionError(
            "Signature Telegram WebApp invalide"
        )

    try:
        auth_date = int(
            pairs.get(
                "auth_date",
                "0",
            )
        )
    except Exception:
        auth_date = 0

    now_epoch = int(time.time())

    if (
        auth_date <= 0
        or now_epoch - auth_date
        > TELEGRAM_WEBAPP_MAX_AGE_SECONDS
        or auth_date - now_epoch > 60
    ):
        raise PermissionError(
            "initData Telegram expiré"
        )

    raw_user = pairs.get("user")

    if not raw_user:
        raise PermissionError(
            "Utilisateur Telegram absent"
        )

    try:
        user = json.loads(raw_user)
    except Exception as exc:
        raise PermissionError(
            "Utilisateur Telegram invalide"
        ) from exc

    if not user.get("id"):
        raise PermissionError(
            "Telegram user id absent"
        )

    return {
        "user": user,
        "auth_date": auth_date,
        "query_id": pairs.get("query_id"),
    }


def find_live_device_by_mac(mac):
    wanted = normalize_webapp_ring_key(
        mac
    )

    with state_lock:
        for dev in devices_state.values():
            current = normalize_webapp_ring_key(
                dev.get("mac")
            )

            if current == wanted:
                return dict(dev)

    return None


def _webapp_sensor_payload(data):
    if not isinstance(data, dict):
        return {
            "status": None,
            "reason": None,
            "value": data,
            "samples": None,
            "unit": None,
            "timestamp": None,
        }

    samples = data.get("samples")

    value = None

    for key in (
        "value_median",
        "median",
        "last",
        "value",
    ):
        if data.get(key) is not None:
            value = data.get(key)
            break

    return {
        "status": data.get("status"),
        "reason": data.get("reason"),
        "value": value,
        "samples": samples,
        "unit": data.get("unit"),
        "timestamp": data.get("timestamp"),
    }


def build_webapp_snapshot(access):
    """
    Copie minimale et sûre de l'état temps réel Flask/MQTT
    pour une seule bague autorisée.
    """
    dev = find_live_device_by_mac(
        access["mac"]
    )

    if not dev:
        return {
            "ring_name": access["ring_name"],
            "mac": access["mac"],
            "model": access.get("model"),
            "connection_status": "unknown",
            "connection_label":
                "⚪ En attente de données / Waiting for data",
            "battery": None,
            "battery_timestamp": None,
            "charging": None,
            "last_timestamp": None,
            "heart_rate": {},
            "spo2": {},
            "fatigue": {},
            "health_check": {},
            "steps": {},
            "rssi": None,
        }

    outside = bool(
        dev.get("outside")
    )

    last_dt = parse_datetime(
        dev.get("lastTimestamp")
    )

    expired = True

    if last_dt:
        current = (
            datetime.now(timezone.utc)
            .astimezone()
        )

        try:
            expired = (
                current
                - last_dt.astimezone()
            ).total_seconds() > DEVICE_OFFLINE_SECONDS
        except Exception:
            expired = True

    if outside:
        connection_status = "outside"
        connection_label = (
            "🟡 HORS PORTÉE BLUETOOTH / "
            "OUT OF BLE RANGE"
        )

    elif expired:
        connection_status = "stale"
        connection_label = (
            "⚪ AUCUNE DONNÉE RÉCENTE / "
            "NO RECENT DATA"
        )

    else:
        connection_status = "online"
        connection_label = (
            "🟢 ONLINE"
        )

    battery = dev.get("battery")

    if isinstance(battery, dict):
        battery_value = battery.get(
            "value"
        )
        battery_timestamp = battery.get(
            "timestamp"
        )
    else:
        battery_value = battery
        battery_timestamp = None

    steps = dev.get("steps")

    if not isinstance(steps, dict):
        steps = {
            "steps": steps,
        }

    return {
        "ring_name": (
            dev.get("deviceName")
            or access["ring_name"]
        ),
        "mac": access["mac"],
        "model": access.get("model"),

        "connection_status":
            connection_status,
        "connection_label":
            connection_label,

        "battery": battery_value,
        "battery_timestamp":
            battery_timestamp,
        "charging":
            dev.get("charging"),

        "last_timestamp":
            dev.get("lastTimestamp"),

        "heart_rate":
            _webapp_sensor_payload(
                dev.get("heartRate")
            ),

        "spo2":
            _webapp_sensor_payload(
                dev.get("spo2")
            ),

        "fatigue":
            _webapp_sensor_payload(
                dev.get("fatigue")
            ),

        "health_check":
            _webapp_sensor_payload(
                dev.get("healthCheck")
            ),

        "steps": {
            "steps":
                steps.get("steps"),
            "distance_m":
                steps.get("distance_m"),
            "calories_raw":
                steps.get("calories_raw"),
            "timestamp":
                steps.get("timestamp"),
        },

        "rssi":
            dev.get("rssi"),
    }


def webapp_access_from_session_token(
    session_token,
    *,
    touch=False,
):
    session = get_webapp_session(
        session_token,
        touch=touch,
    )

    if not session:
        return None, None

    access = {
        "telegram_user_id":
            session["telegram_user_id"],
        "id_telegram":
            session["id_telegram"],
        "ring_id":
            session["ring_id"],
        "ring_name":
            session["ring_name"],
        "mac":
            session["mac"],
        "model":
            session["model"],
    }

    return session, access


# ============================================================
# TELEGRAM - notification d'affectation
# ============================================================

def send_telegram_message(chat_id, text, reply_markup=None):
    """
    Envoie un message via l'API Telegram Bot.
    Retourne (True, None) ou (False, raison).
    """
    if not TELEGRAM_BOT_TOKEN:
        return False, "TELEGRAM_BOT_TOKEN absent du .env"

    if not chat_id:
        return False, "id_telegram absent"

    payload = {
        "chat_id": int(chat_id),
        "text": text,
    }

    if reply_markup:
        payload["reply_markup"] = reply_markup

    data = json.dumps(
        payload,
        ensure_ascii=False,
    ).encode("utf-8")

    req = urllib.request.Request(
        (
            "https://api.telegram.org/bot"
            f"{TELEGRAM_BOT_TOKEN}/sendMessage"
        ),
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            result = json.loads(
                response.read().decode("utf-8")
            )

        if result.get("ok") is True:
            return True, None

        return False, result.get("description") or "Erreur Telegram"

    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = str(exc)
        return False, body

    except Exception as exc:
        return False, str(exc)


def send_ring_assignment_notification(user_row, ring_row):
    """
    Informe l'utilisateur lorsqu'une nouvelle bague lui est affectée.
    user_row provient de list_telegram_access().
    ring_row provient de list_telegram_access().
    """
    chat_id = user_row.get("id_telegram")
    ring_name = ring_row.get("name") or "COLMI Ring"
    ring_id = ring_row.get("id")
    mac = ring_row.get("mac") or ""

    first_name = user_row.get("firstname") or ""
    hello = f" {first_name}" if first_name else ""
    text = (
        f"✅ Nouvelle bague affectée / New ring assigned{hello}\n\n"
        f"💍 {ring_name}\n"
        f"📡 MAC : {mac}\n\n"
        "La bague est maintenant disponible dans ton bot DANY.\n"
        "The ring is now available in your DANY bot.\n\n"
        "Tu peux consulter le LIVE et l'historique selon tes droits.\n"
        "You can view LIVE data and history according to your permissions."
    )

    reply_markup = None
    if ring_id:
        reply_markup = {
            "inline_keyboard": [
                [
                    {
                        "text": "💍 Ouvrir la bague / Open ring",
                        "callback_data": f"ring:{ring_id}",
                    }
                ]
            ]
        }

    return send_telegram_message(
        chat_id,
        text,
        reply_markup=reply_markup,
    )


def send_ring_unassignment_notification(user_row, ring_row):
    """
    Informe l'utilisateur après une désaffectation manuelle Flask.
    """
    chat_id = user_row.get("id_telegram")
    ring_name = ring_row.get("name") or "COLMI Ring"
    mac = ring_row.get("mac") or ""

    text = (
        "ℹ️ Bague désaffectée / Ring unassigned\n\n"
        f"💍 {ring_name}\n"
        f"📡 MAC : {mac}\n\n"
        "Cette bague n'est plus affectée à ton compte.\n"
        "This ring is no longer assigned to your account."
    )

    return send_telegram_message(
        chat_id,
        text,
    )


def send_pairing_rejected_notification(row):
    """
    Notification envoyée au client lorsque l'admin Flask refuse
    une demande d'appariement QR.
    """
    chat_id = row.get("id_telegram")
    ring_name = row.get("ring_name") or "COLMI Ring"
    mac = row.get("mac") or ""

    text = (
        "❌ Demande d'appariement refusée / Pairing request rejected\n\n"
        f"💍 {ring_name}\n"
        f"📡 MAC : {mac}\n\n"
        "La demande d'affectation n'a pas été autorisée.\n"
        "The pairing request was not approved."
    )

    return send_telegram_message(
        chat_id,
        text,
    )

def load_state():
    global devices_state
    if not STATE_FILE.exists():
        return
    try:
        with STATE_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            devices_state = data
    except Exception as exc:
        print("Impossible de charger l'état :", exc)


def save_state():
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(devices_state, f, ensure_ascii=False, indent=2)
        tmp.replace(STATE_FILE)
    except Exception as exc:
        print("Impossible de sauvegarder l'état :", exc)


def get_or_create_device(mac, device_name):
    if mac not in devices_state:
        devices_state[mac] = {
            "deviceName": device_name or "COLMI Device",
            "mac": mac,
            "battery": {},
            "steps": {},
            "heartRate": {},
            "spo2": {},
            "fatigue": {},
            "healthCheck": {},
            "measurementCycle": {
                "stage": None,
                "stageTimestamp": None,
            },
            "rssi": "N/A",
            "charging": False,
            "outside": False,
            "faultCode": None,
            "outsideMessage": None,
            "outsideTimestamp": None,
            "lastTimestamp": now_iso(),
            "lastDatetime": "-",
            "logs": [],
        }

    dev = devices_state[mac]
    dev.setdefault("deviceName", device_name or "COLMI Device")
    dev.setdefault("mac", mac)
    dev.setdefault("battery", {})
    dev.setdefault("steps", {})
    dev.setdefault("heartRate", {})
    dev.setdefault("spo2", {})
    dev.setdefault("fatigue", {})
    dev.setdefault("healthCheck", {})
    dev.setdefault(
        "measurementCycle",
        {
            "stage": None,
            "stageTimestamp": None,
        },
    )
    dev.setdefault("rssi", "N/A")
    dev.setdefault("charging", False)
    dev.setdefault("outside", False)
    dev.setdefault("faultCode", None)
    dev.setdefault("outsideMessage", None)
    dev.setdefault("outsideTimestamp", None)
    dev.setdefault("lastTimestamp", now_iso())
    dev.setdefault("lastDatetime", "-")
    dev.setdefault("logs", [])
    return dev



def fault_label(fault_code):
    """Libellé d'affichage basé sur fault_code."""
    code = safe_str(fault_code, "").strip()

    if code in ("device_not_found", "device_out_of_range"):
        return "Hors portée"

    return "Alerte" if code else "Alerte"


def clear_outside_state(dev):
    """Une donnée BLE valide prouve que la bague est revenue."""
    dev["outside"] = False
    dev["faultCode"] = None
    dev["outsideMessage"] = None
    dev["outsideTimestamp"] = None


def _sensor_waiting_state(cycle_timestamp=None):
    """
    État d'un capteur qui n'a pas encore commencé dans le cycle courant.

    Important :
    on ne met volontairement PAS de champ "timestamp" afin de ne pas
    afficher le timestamp de l'ancien cycle.
    """
    return {
        "value": None,
        "status": "waiting",
        "reason": None,
        "cycle_timestamp": cycle_timestamp,
    }


def _sensor_timestamp(data):
    if not isinstance(data, dict):
        return None
    return parse_datetime(data.get("timestamp"))


def _stage_timestamp(value):
    return parse_datetime(value)


def _belongs_to_previous_cycle(sensor_data, stage_timestamp):
    """
    True si le bloc affiché appartient clairement à un cycle plus ancien.

    Cas typique :
      HR nouveau cycle      : 12:17:34
      Fatigue ancien cycle  : 12:14:56
      => Fatigue doit devenir "En attente".
    """
    if not isinstance(sensor_data, dict) or not sensor_data:
        return True

    if safe_str(
        sensor_data.get("status"),
        "",
    ).strip().lower() == "waiting":
        return False

    current_dt = _sensor_timestamp(sensor_data)
    stage_dt = _stage_timestamp(stage_timestamp)

    if current_dt is not None and stage_dt is not None:
        # Normaliser les timezones avant comparaison.
        if current_dt.tzinfo is None:
            current_dt = current_dt.replace(tzinfo=timezone.utc)

        if stage_dt.tzinfo is None:
            stage_dt = stage_dt.replace(tzinfo=timezone.utc)

        return (
            current_dt.astimezone(timezone.utc)
            < stage_dt.astimezone(timezone.utc)
        )

    # Sans timestamp exploitable, mieux vaut ne pas conserver une ancienne
    # valeur/status dans la zone "cycle courant".
    return True


def prepare_measurement_stage(dev, sensor_key, stage_timestamp):
    """
    Synchronise l'affichage avec le cycle de mesure courant.

    Quand un message d'un capteur arrive, tous les capteurs qui viennent
    APRES lui dans la séquence et qui portent encore un timestamp plus ancien
    sont remis à "waiting".

    Exemple :
      HR 12:17:34 arrive
      Fatigue 12:14:56 existe encore
      Health 12:14:56 existe encore

      => Fatigue = waiting
      => Health  = waiting

    Le même mécanisme protège aussi contre un message MQTT ancien reçu
    en retard : un bloc plus récent n'est jamais écrasé.
    """
    if sensor_key not in SENSOR_CYCLE_SEQUENCE:
        return

    try:
        current_index = SENSOR_CYCLE_SEQUENCE.index(
            sensor_key
        )
    except ValueError:
        return

    for later_key in SENSOR_CYCLE_SEQUENCE[
        current_index + 1:
    ]:
        existing = dev.get(later_key)

        if _belongs_to_previous_cycle(
            existing,
            stage_timestamp,
        ):
            dev[later_key] = _sensor_waiting_state(
                stage_timestamp
            )

    dev["measurementCycle"] = {
        "stage": sensor_key,
        "stageTimestamp": stage_timestamp,
    }


def compact_rssi(value):
    if value is None:
        return "N/A"
    if isinstance(value, dict):
        value = value.get("value", value.get("rssi", "N/A"))
    text = safe_str(value)
    if text == "N/A":
        return text
    return text if "dbm" in text.lower() else f"{text} dBm"


def metric_rows(kind, data):
    if not isinstance(data, dict) or not data:
        return [("Valeur", "N/A", False)]

    if kind == "battery":
        level = data.get("value", data.get("level", "N/A"))
        charging = data.get("charging")
        if charging is True:
            charge_text = "En charge ⚡"
        elif charging is False:
            charge_text = "Débranché"
        else:
            charge_text = "N/A"
        rows = [("Niv", safe_str(level), False), ("Status", charge_text, False)]

    elif kind == "steps":
        rows = [
            ("Steps", safe_str(data.get("steps")), False),
            ("Distance", f'{safe_str(data.get("distance_m"))} m', False),
            ("Calories", safe_str(data.get("calories_raw")), False),
            ("Unité", safe_str(data.get("unit")), False),
        ]

    elif kind in ("heartRate", "spo2"):
        value = data.get("value")
        status = safe_str(data.get("status"), "").lower()
        reason = safe_str(data.get("reason"), "")

        if status == "hors_portee":
            rows = [
                ("Valeur", "Hors portée / Out of range", False),
                ("Code", reason or "device_not_found", False),
            ]
        elif status == "waiting":
            rows = [
                ("Valeur", "—", False),
            ]
        elif status == "en_cours":
            rows = [
                ("Valeur", "—", False),
            ]
        elif value is None:
            rows = [
              ("Valeur", "Not worn / Non portée", False),
              ("Raison", reason or "N/A", False),
              ("Statut", "Not worn / Non portée", False),
            ]
        else:
            rows = [("Valeur", safe_str(value), False)]
            if data.get("unit") is not None:
                rows.append(("Unité", safe_str(data.get("unit")), False))

    elif kind in ("fatigue", "healthCheck"):
        # Même affichage que HR / SpO2 :
        # on montre directement la valeur reçue dans payload["value"]["value"].
        value = data.get("value")
        unit = data.get("unit")
        status = safe_str(data.get("status"), "").lower()
        reason = safe_str(data.get("reason"), "")

        if status == "hors_portee":
            rows = [
                ("Valeur", "Hors portée / Out of range", False),
                ("Code", reason or "device_not_found", False),
            ]
        elif status == "waiting":
            rows = [
                ("Valeur", "—", False),
            ]
        elif status == "en_cours":
            rows = [
                ("Valeur", "—", False),
            ]
        elif value is None:
            rows = [
                ("Valeur", "Not worn / Non portée", False),
                ("Raison", reason or "N/A", False),
            ]
        else:
            rows = [("Valeur", safe_str(value), False)]

            if unit is not None:
                rows.append(("Unité", safe_str(unit), False))
    else:
        rows = [("Valeur", safe_str(data), False)]

    timestamp = data.get("timestamp")
    if timestamp:
        rows.append(("Timestamp", format_datetime(timestamp), True))
    return rows



def sensor_status_info(data):
    """
    Etat visuel du dernier message reçu sur un topic de mesure.

    - en_cours      -> En cours + animation
    - ok            -> Terminé / OK
    - non_connecte  -> Terminé / erreur
    - en_cours > SENSOR_STALE_SECONDS -> Bloqué / obsolète
    """
    if not isinstance(data, dict) or not data:
        return {
            "label": "N/A",
            "detail": "",
            "css": "sensor-status-idle",
            "running": False,
            "stale": False,
        }

    status = safe_str(data.get("status"), "").strip().lower()
    reason = safe_str(data.get("reason"), "").strip()
    ts = data.get("timestamp")

    if status == "waiting":
        return {
            "label": "En attente / Waiting",
            "detail": "Cycle courant / Current cycle",
            "css": "sensor-status-idle",
            "running": False,
            "stale": False,
        }

    if status == "en_cours":
        stale = False
        dt = parse_datetime(ts)

        if dt is not None:
            try:
                now = datetime.now(timezone.utc)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                age_seconds = (now - dt.astimezone(timezone.utc)).total_seconds()
                stale = age_seconds > SENSOR_STALE_SECONDS
            except Exception:
                stale = False

        if stale:
            return {
                "label": "Bloqué / obsolète",
                "detail": "plus de 30 min sans message de fin",
                "css": "sensor-status-stale",
                "running": False,
                "stale": True,
            }

        return {
            "label": "En cours / In progress",
            "detail": "En attente de données / Waiting for data",
            "css": "sensor-status-running",
            "running": True,
            "stale": False,
        }

    if status == "ok":
        return {
            "label": "Terminé / Done",
            "detail": "OK",
            "css": "sensor-status-done",
            "running": False,
            "stale": False,
        }

    if status == "non_connecte":
        detail = f"Erreur : {reason}" if reason else "Erreur"
        return {
            "label": "Terminé",
            "detail": detail,
            "css": "sensor-status-error",
            "running": False,
            "stale": False,
        }

    if status == "hors_portee":
        return {
            "label": "Hors portée / Out of range",
            "detail": reason,
            "css": "sensor-status-error",
            "running": False,
            "stale": False,
        }

    return {
        "label": status or "N/A",
        "detail": reason,
        "css": "sensor-status-idle",
        "running": False,
        "stale": False,
    }

def on_connect(client, userdata, flags, reason_code, properties=None):
    try:
        code = int(reason_code)
    except Exception:
        code = reason_code

    with state_lock:
        if code == 0:
            mqtt_status["connected"] = True
            mqtt_status["message"] = f"MQTT connecté : {MQTT_HOST}:{MQTT_PORT}"
            mqtt_status["last_error"] = None
            result, _ = client.subscribe(MQTT_TOPIC, qos=1)
            print(f"MQTT connecté / abonnement {MQTT_TOPIC} / résultat={result}")
        else:
            mqtt_status["connected"] = False
            mqtt_status["message"] = f"Échec MQTT : code {code}"
            mqtt_status["last_error"] = str(code)


def on_disconnect(client, userdata, disconnect_flags, reason_code, properties=None):
    with state_lock:
        mqtt_status["connected"] = False
        mqtt_status["message"] = "MQTT déconnecté - reconnexion automatique..."
        mqtt_status["last_error"] = str(reason_code)
    print("MQTT déconnecté :", reason_code)


def on_message(client, userdata, msg):
    topic = msg.topic
    received_at = now_iso()
    raw_payload = msg.payload.decode("utf-8", errors="replace")

    # Le flux brut doit toujours montrer ce qui arrive,
    # même si le JSON est invalide.
    with state_lock:
        raw_messages.insert(0, {
            "time": datetime.now().strftime("%H:%M:%S"),
            "topic": topic,
            "payload": raw_payload,
        })
        del raw_messages[50:]

        mqtt_status["message_count"] = int(
            mqtt_status.get("message_count", 0)
        ) + 1
        mqtt_status["last_message_time"] = received_at
        mqtt_status["last_topic"] = topic

    try:
        payload = json.loads(raw_payload)
    except Exception as exc:
        print(f"Payload MQTT invalide sur {topic} :", exc)
        return

    # Persistance asynchrone : ne bloque jamais le thread MQTT.
    enqueue_mqtt_message(topic, payload, received_at)

    with state_lock:
        topic_parts = topic.split("/")
        topic_mac = topic_parts[-2] if len(topic_parts) >= 2 else ""
        topic_model = topic_parts[-3] if len(topic_parts) >= 3 else ""

        # Les messages "en_cours" peuvent ne contenir que
        # status/reason/value/timestamp. Dans ce cas on récupère le MAC
        # et le modèle directement depuis le topic MQTT.
        mac = safe_str(payload.get("mac") or topic_mac, "").strip()
        if not mac:
            return

        device_name = payload.get("device")
        if not device_name:
            if topic_model:
                device_name = topic_model if topic_model.upper().startswith("COLMI") else f"COLMI {topic_model}"
            else:
                device_name = "COLMI Device"

        dev = get_or_create_device(mac, device_name)
        dev["deviceName"] = device_name
        dev["lastTimestamp"] = received_at
        payload_ts = payload.get("timestamp") or received_at
        dev["lastDatetime"] = payload_ts

        type_mesure = safe_str(payload.get("Type_mesure"), "").lower()
        sub_type = topic.split("/")[-1].lower()
        value = payload.get("value")

        # ----------------------------------------------------
        # BAGUE HORS PORTEE / BLE DEVICE NOT FOUND
        # ----------------------------------------------------
        if sub_type == "outside":
            fault_code = safe_str(payload.get("fault_code"), "").strip()

            is_outside_fault = fault_code in (
                "device_not_found",
                "device_out_of_range",
            )

            # Pour les deux codes BLE attendus, la bague est considérée Hors portée.
            # Si un autre fault_code arrive plus tard, on conserve quand même la trame
            # dans l'historique sans inventer un état Hors portée.
            if is_outside_fault:
                dev["outside"] = True
                dev["faultCode"] = fault_code
                dev["outsideMessage"] = payload.get("message")
                dev["outsideTimestamp"] = payload_ts

                # Les 4 capteurs ne doivent plus conserver leurs anciennes
                # valeurs quand la bague est hors portée.
                dev["heartRate"] = {
                    "value": None,
                    "reason": fault_code,
                    "status": "hors_portee",
                    "timestamp": payload_ts,
                }

                dev["spo2"] = {
                    "value": None,
                    "reason": fault_code,
                    "status": "hors_portee",
                    "timestamp": payload_ts,
                }

                dev["fatigue"] = {
                    "value": None,
                    "reason": fault_code,
                    "status": "hors_portee",
                    "timestamp": payload_ts,
                }

                dev["healthCheck"] = {
                    "value": None,
                    "reason": fault_code,
                    "status": "hors_portee",
                    "timestamp": payload_ts,
                }

        elif type_mesure == "battery" or sub_type == "battery":
            # Une lecture batterie valide signifie que la bague est revenue.
            clear_outside_state(dev)

            if isinstance(value, dict):
                dev["battery"] = value
                if "charging" in value:
                    dev["charging"] = bool(value["charging"])
            else:
                dev["battery"] = {
                    "value": value,
                    "charging": payload.get("charging"),
                    "timestamp": payload_ts,
                }
                if "charging" in payload:
                    dev["charging"] = bool(payload["charging"])

        elif type_mesure == "steps" or sub_type == "steps":
            # Une lecture steps valide signifie que la bague est revenue.
            clear_outside_state(dev)

            dev["steps"] = value if isinstance(value, dict) else {
                "steps": value,
                "timestamp": payload_ts,
            }

        elif type_mesure in ("heart_rate", "rate") or sub_type == "heart_rate":
            # HR est le début logique du cycle santé.
            # Dès qu'un nouveau HR arrive, les anciens SpO2/Fatigue/Health
            # ne doivent plus être présentés comme appartenant au cycle courant.
            prepare_measurement_stage(
                dev,
                "heartRate",
                payload_ts,
            )

            if isinstance(value, dict):
                heart_rate = dict(value)
            else:
                heart_rate = {
                    "value": value,
                    "timestamp": payload_ts,
                }

            heart_rate.setdefault("status", payload.get("status"))
            heart_rate.setdefault("reason", payload.get("reason"))
            heart_rate.setdefault("unit", payload.get("unit"))
            heart_rate.setdefault("timestamp", payload_ts)
            dev["heartRate"] = heart_rate

            # Ne retirer Hors portée que si une vraie valeur HR est revenue.
            if heart_rate.get("value") is not None:
                clear_outside_state(dev)

        elif type_mesure == "spo2" or sub_type == "spo2":
            # Quand SpO2 commence/termine, les anciennes valeurs Fatigue/Health
            # sont remises à "En attente" si elles sont plus anciennes.
            prepare_measurement_stage(
                dev,
                "spo2",
                payload_ts,
            )

            if isinstance(value, dict):
                spo2_data = dict(value)
            else:
                spo2_data = {
                    "value": value,
                    "timestamp": payload_ts,
                }

            spo2_data.setdefault("status", payload.get("status"))
            spo2_data.setdefault("reason", payload.get("reason"))
            spo2_data.setdefault("unit", payload.get("unit"))
            spo2_data.setdefault("timestamp", payload_ts)
            dev["spo2"] = spo2_data

            # Ne retirer Hors portée que si une vraie valeur SpO2 est revenue.
            if spo2_data.get("value") is not None:
                clear_outside_state(dev)

        elif type_mesure == "fatigue" or sub_type == "fatigue":
            # Health-check ancien ne doit pas rester "En cours" pendant
            # une nouvelle mesure Fatigue.
            prepare_measurement_stage(
                dev,
                "fatigue",
                payload_ts,
            )

            if isinstance(value, dict):
                fatigue = dict(value)
            else:
                fatigue = {
                    "value": value,
                    "timestamp": payload_ts,
                }

            # Conserver également le statut et la raison racine du payload.
            fatigue.setdefault("status", payload.get("status"))
            fatigue.setdefault("reason", payload.get("reason"))
            fatigue.setdefault("unit", payload.get("unit"))
            fatigue.setdefault("timestamp", payload_ts)
            dev["fatigue"] = fatigue

            # Une vraie mesure reçue prouve que la bague est joignable.
            if (
                fatigue.get("value_median") is not None
                or fatigue.get("last") is not None
                or fatigue.get("value") is not None
            ):
                clear_outside_state(dev)

        elif type_mesure == "health_check" or sub_type == "health_check":
            prepare_measurement_stage(
                dev,
                "healthCheck",
                payload_ts,
            )

            if isinstance(value, dict):
                health_check = dict(value)
            else:
                health_check = {
                    "value": value,
                    "timestamp": payload_ts,
                }

            health_check.setdefault("status", payload.get("status"))
            health_check.setdefault("reason", payload.get("reason"))
            health_check.setdefault("unit", payload.get("unit"))
            health_check.setdefault("timestamp", payload_ts)
            dev["healthCheck"] = health_check

            # Une vraie mesure reçue prouve que la bague est joignable.
            if (
                health_check.get("value_median") is not None
                or health_check.get("last") is not None
                or health_check.get("value") is not None
            ):
                clear_outside_state(dev)

        elif type_mesure == "rssi" or sub_type == "rssi":
            dev["rssi"] = value

            # Un RSSI reçu signifie que la bague est à nouveau visible.
            if value is not None:
                clear_outside_state(dev)

        elif sub_type == "snapshot":
            # Le snapshot n'efface PAS l'état Hors portée :
            # il peut être publié juste après l'alerte outside.
            if "charging" in payload:
                dev["charging"] = bool(payload["charging"])

        dev["logs"].insert(0, {
            "topic": topic,
            "subType": sub_type or type_mesure,
            "payload": payload,
            "datetime": payload_ts,
        })
        del dev["logs"][100:]
        save_state()


try:
    mqtt_client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=f"flask_colmi_{os.getpid()}",
        clean_session=True,
    )
except Exception:
    mqtt_client = mqtt.Client(
        client_id=f"flask_colmi_{os.getpid()}",
        clean_session=True,
    )

if MQTT_USER:
    mqtt_client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
mqtt_client.on_connect = on_connect
mqtt_client.on_disconnect = on_disconnect
mqtt_client.on_message = on_message
mqtt_client.reconnect_delay_set(min_delay=1, max_delay=10)


_mqtt_started = False
_mqtt_start_lock = threading.Lock()


def start_mqtt():
    """Démarre Paho une seule fois par process."""
    global _mqtt_started

    with _mqtt_start_lock:
        if _mqtt_started:
            return

        _mqtt_started = True

        try:
            print(f"Connexion MQTT TCP à {MQTT_HOST}:{MQTT_PORT}...")
            print(f"Abonnement MQTT : {MQTT_TOPIC}")
            mqtt_client.connect_async(
                MQTT_HOST,
                MQTT_PORT,
                keepalive=30,
            )
            mqtt_client.loop_start()

        except Exception as exc:
            _mqtt_started = False

            with state_lock:
                mqtt_status["connected"] = False
                mqtt_status["message"] = f"Erreur MQTT : {exc}"
                mqtt_status["last_error"] = str(exc)

            print("Erreur MQTT :", exc)


# ============================================================
# DEMARRAGE DES SERVICES
# ============================================================

_services_started = False
_services_start_lock = threading.Lock()


def start_services():
    """
    Démarre DB worker + test DB + MQTT une seule fois par process.
    Compatible python app.py et serveurs WSGI mono-processus.
    """
    global _services_started

    with _services_start_lock:
        if _services_started:
            return

        _services_started = True

        load_state()
        start_db_worker()
        test_database()
        start_mqtt()


@app.context_processor
def template_helpers():
    return {
        "metric_rows": metric_rows,
        "compact_rssi": compact_rssi,
        "format_datetime": format_datetime,
        "fault_label": fault_label,
        "sensor_status_info": sensor_status_info,
    }


def build_device_rows():
    """Construit une copie présentable de l'état courant sans exposer le lock aux templates."""
    current = datetime.now(timezone.utc).astimezone()
    with state_lock:
        rows = []
        for dev in devices_state.values():
            last_dt = parse_datetime(dev.get("lastTimestamp"))
            if last_dt:
                age = (current - last_dt.astimezone()).total_seconds()
            else:
                age = 999999

            item = dict(dev)
            item["isExpired"] = age > DEVICE_OFFLINE_SECONDS
            rows.append(item)

        rows.sort(
            key=lambda d: parse_datetime(d.get("lastTimestamp")) or datetime.min.replace(tzinfo=timezone.utc),
            reverse=True,
        )
    return rows


@app.route("/")
def index():
    rows = build_device_rows()
    with state_lock:
        raw_copy = list(raw_messages)
        status_copy = dict(mqtt_status)

    # Copie légère destinée au localStorage du navigateur.
    # On ne stocke pas les historiques complets ni le flux brut côté navigateur.
    browser_cache = []
    for dev in rows:
        browser_cache.append({
            "deviceName": dev.get("deviceName"),
            "mac": dev.get("mac"),
            "battery": dev.get("battery"),
            "steps": dev.get("steps"),
            "heartRate": dev.get("heartRate"),
            "spo2": dev.get("spo2"),
            "fatigue": dev.get("fatigue"),
            "healthCheck": dev.get("healthCheck"),
            "rssi": dev.get("rssi"),
            "charging": dev.get("charging", False),
            "outside": dev.get("outside", False),
            "faultCode": dev.get("faultCode"),
            "outsideMessage": dev.get("outsideMessage"),
            "outsideTimestamp": dev.get("outsideTimestamp"),
            "lastTimestamp": dev.get("lastTimestamp"),
            "lastDatetime": dev.get("lastDatetime"),
            "isExpired": dev.get("isExpired", False),
        })

    return render_template(
        "index.html",
        devices=rows,
        raw_messages=raw_copy,
        mqtt_status=status_copy,
        mqtt_topic=MQTT_TOPIC,
        auto_refresh=AUTO_REFRESH_SECONDS,
        browser_cache=browser_cache,
        db_status=get_db_status(),
    )


@app.route("/api/table")
def table_fragment():
    return render_template("_device_rows.html", devices=build_device_rows())


@app.route("/api/status")
def status_api():
    with state_lock:
        mqtt_copy = dict(mqtt_status)
    return jsonify({"ok": True, "mqtt": mqtt_copy, "db": get_db_status()})


@app.route("/api/mqtt/raw")
def mqtt_raw_fragment():
    """
    Fragment HTML léger du flux MQTT brut.
    Ne recharge jamais la page complète.
    """
    with state_lock:
        raw_copy = list(raw_messages)

    return render_template(
        "_mqtt_raw.html",
        raw_messages=raw_copy,
    )


@app.route("/api/db/history/<path:mac>")
def db_history_api(mac):
    try:
        hours = request.args.get("hours", "24")
        metric = request.args.get("metric") or None
        ring, rows = query_measurement_history(mac, hours=hours, metric=metric, limit=1000)
        if not ring:
            return jsonify({"ok": False, "error": "Bague inconnue dans PostgreSQL"}), 404
        return jsonify({"ok": True, "ring": ring, "rows": rows})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/telegram/<path:mac>", methods=["GET", "POST"])
def telegram_access_api(mac):
    """
    Affecte uniquement un utilisateur Telegram déjà connu dans
    t_user_app_telegram.

    Lors d'une nouvelle affectation (ou réactivation), un message
    Telegram est envoyé à id_telegram.
    """
    try:
        if request.method == "POST":
            data = request.get_json(silent=True) or request.form.to_dict()

            raw_user_id = str(
                data.get("telegram_user_id", "")
            ).strip()

            if not raw_user_id:
                return jsonify({
                    "ok": False,
                    "error": "telegram_user_id obligatoire",
                }), 400

            telegram_user_id = int(raw_user_id)

            # Etat avant UPSERT : évite de notifier lors d'une simple
            # modification de permissions.
            ring_before, access_before = list_telegram_access(mac)

            was_already_active = any(
                int(row.get("telegram_user_id")) == telegram_user_id
                and bool(row.get("active"))
                for row in access_before
            )

            access_id = upsert_telegram_access(mac, data)

            notification_sent = False
            notification_error = None

            if not was_already_active:
                ring_after, access_after = list_telegram_access(mac)

                target_user = next(
                    (
                        row
                        for row in access_after
                        if int(row.get("telegram_user_id"))
                        == telegram_user_id
                    ),
                    None,
                )

                if ring_after and target_user:
                    (
                        notification_sent,
                        notification_error,
                    ) = send_ring_assignment_notification(
                        target_user,
                        ring_after,
                    )

            return jsonify({
                "ok": True,
                "access_id": access_id,
                "notification_sent": notification_sent,
                "notification_error": notification_error,
            })

        ring, rows = list_telegram_access(mac)

        if not ring:
            return jsonify({
                "ok": False,
                "error": "Bague inconnue dans PostgreSQL",
            }), 404

        users = list_telegram_users(active_only=True)

        return jsonify({
            "ok": True,
            "ring": ring,
            "access": rows,
            "available_users": users,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.delete("/api/telegram/<path:mac>/<int:access_id>")
def telegram_access_delete_api(mac, access_id):
    try:
        # Sauvegarder l'utilisateur AVANT suppression pour garder id_telegram.
        ring, rows = list_telegram_access(mac)

        target_user = next(
            (
                row
                for row in rows
                if int(row.get("access_id")) == int(access_id)
            ),
            None,
        )

        deleted = delete_telegram_access(
            mac,
            access_id,
        )

        notification_sent = False
        notification_error = None

        if deleted and ring and target_user:
            (
                notification_sent,
                notification_error,
            ) = send_ring_unassignment_notification(
                target_user,
                ring,
            )

        return jsonify({
            "ok": bool(deleted),
            "notification_sent": notification_sent,
            "notification_error": notification_error,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400






# ============================================================
# TELEGRAM MINI APP / WEB APP ROUTES
# ============================================================

@app.route("/webapp/ring/<ring_key>")
def telegram_webapp_ring_page(ring_key):
    ring_key = normalize_webapp_ring_key(
        ring_key
    )

    if len(ring_key) != 12:
        return (
            "Invalid ring",
            404,
        )

    return render_template(
        "telegram_webapp.html",
        ring_key=ring_key,
        heartbeat_seconds=
            TELEGRAM_WEBAPP_HEARTBEAT_SECONDS,
        refresh_seconds=2,
    )


@app.post("/api/webapp/open")
def telegram_webapp_open_api():
    try:
        data = request.get_json(
            silent=True
        ) or {}

        ring_key = normalize_webapp_ring_key(
            data.get("ring_key")
        )

        validated = (
            validate_telegram_webapp_init_data(
                data.get("init_data")
            )
        )

        telegram_user = validated[
            "user"
        ]

        access = get_webapp_ring_access(
            int(telegram_user["id"]),
            ring_key,
        )

        if not access:
            return jsonify({
                "ok": False,
                "error":
                    "Accès non autorisé à cette bague / "
                    "Ring access denied",
            }), 403

        auth_dt = datetime.fromtimestamp(
            validated["auth_date"],
            tz=timezone.utc,
        )

        session = create_webapp_session(
            access["telegram_user_id"],
            access["ring_id"],
            telegram_auth_date=auth_dt,
            telegram_query_id=
                validated.get("query_id"),
        )

        return jsonify({
            "ok": True,

            "session_token":
                session["session_token"],

            "user": {
                "telegram_id":
                    access["id_telegram"],
                "firstname":
                    access.get("firstname"),
                "lastname":
                    access.get("lastname"),
                "pseudo":
                    access.get("pseudo"),
            },

            "ring": {
                "ring_id":
                    access["ring_id"],
                "name":
                    access["ring_name"],
                "mac":
                    access["mac"],
                "model":
                    access.get("model"),
            },

            "snapshot":
                build_webapp_snapshot(
                    access
                ),
        })

    except PermissionError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 403

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.post("/api/webapp/data")
def telegram_webapp_data_api():
    try:
        data = request.get_json(
            silent=True
        ) or {}

        session_token = data.get(
            "session_token"
        )

        session, access = (
            webapp_access_from_session_token(
                session_token,
                touch=True,
            )
        )

        if not session:
            return jsonify({
                "ok": False,
                "error":
                    "Session WebApp expirée ou accès retiré / "
                    "WebApp session expired or access revoked",
            }), 403

        return jsonify({
            "ok": True,
            "snapshot":
                build_webapp_snapshot(
                    access
                ),
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.post("/api/webapp/heartbeat")
def telegram_webapp_heartbeat_api():
    try:
        data = request.get_json(
            silent=True
        ) or {}

        session = get_webapp_session(
            data.get("session_token"),
            touch=True,
        )

        if not session:
            return jsonify({
                "ok": False,
                "error":
                    "Session inactive",
            }), 403

        return jsonify({
            "ok": True,
            "last_seen_at":
                session.get(
                    "last_seen_at"
                ),
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.post("/api/webapp/close")
def telegram_webapp_close_api():
    try:
        data = request.get_json(
            silent=True
        ) or {}

        close_webapp_session(
            data.get("session_token")
        )

        return jsonify({
            "ok": True,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.route("/telegram/webapp")
def telegram_webapp_admin_page():
    try:
        return render_template(
            "telegram_webapp_sessions.html",
            sessions=
                list_webapp_sessions(
                    limit=300
                ),
            stats=
                get_webapp_session_stats(),
            active_seconds=
                int(
                    os.getenv(
                        "TELEGRAM_WEBAPP_ACTIVE_SECONDS",
                        "60",
                    )
                ),
        )

    except Exception as exc:
        return render_template(
            "telegram_webapp_sessions.html",
            sessions=[],
            stats={},
            active_seconds=60,
            error=str(exc),
        ), 500


@app.get("/api/telegram/webapp/sessions")
def telegram_webapp_sessions_api():
    try:
        return jsonify({
            "ok": True,
            "sessions":
                list_webapp_sessions(
                    limit=300
                ),
            "stats":
                get_webapp_session_stats(),
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 500


@app.route("/telegram/pairing")
def telegram_pairing_page():
    """
    Administration des demandes d'appariement QR.
    """
    try:
        status = request.args.get("status", "pending").strip().lower()

        if status not in (
            "pending",
            "approved",
            "rejected",
            "cancelled",
            "all",
        ):
            status = "pending"

        rows = list_pairing_requests(
            status=None if status == "all" else status,
            limit=300,
        )

        return render_template(
            "telegram_pairing.html",
            requests=rows,
            current_status=status,
        )

    except Exception as exc:
        return render_template(
            "telegram_pairing.html",
            requests=[],
            current_status="pending",
            error=str(exc),
        ), 500


@app.get("/api/telegram/pairing")
def telegram_pairing_api():
    try:
        status = request.args.get("status", "pending").strip().lower()

        rows = list_pairing_requests(
            status=None if status == "all" else status,
            limit=300,
        )

        return jsonify({
            "ok": True,
            "requests": rows,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.post("/api/telegram/pairing/<int:request_id>/approve")
def telegram_pairing_approve_api(request_id):
    """
    Approuve depuis Flask, crée ring_telegram_access et
    notifie le client Telegram.
    """
    try:
        row = approve_pairing_request_admin(
            request_id,
            admin_label="Flask admin",
        )

        if not row:
            return jsonify({
                "ok": False,
                "error": "Demande introuvable / Request not found",
            }), 404

        if row.get("result") == "already_decided":
            return jsonify({
                "ok": False,
                "error": (
                    "Demande déjà traitée / "
                    "Request already processed"
                ),
                "status": row.get("status"),
            }), 409

        # Adapter au helper déjà utilisé lors d'une affectation manuelle.
        user_row = {
            "id_telegram": row.get("id_telegram"),
            "firstname": row.get("firstname"),
            "lastname": row.get("lastname"),
            "pseudo": row.get("pseudo"),
        }

        ring_row = {
            "id": row.get("ring_id"),
            "name": row.get("ring_name"),
            "mac": row.get("mac"),
            "model": row.get("model"),
        }

        (
            notification_sent,
            notification_error,
        ) = send_ring_assignment_notification(
            user_row,
            ring_row,
        )

        return jsonify({
            "ok": True,
            "status": "approved",
            "request_id": request_id,
            "notification_sent": notification_sent,
            "notification_error": notification_error,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.post("/api/telegram/pairing/<int:request_id>/reject")
def telegram_pairing_reject_api(request_id):
    """
    Refuse depuis Flask et informe le client Telegram.
    """
    try:
        row = reject_pairing_request_admin(
            request_id,
            admin_label="Flask admin",
        )

        if not row:
            return jsonify({
                "ok": False,
                "error": "Demande introuvable / Request not found",
            }), 404

        if row.get("result") == "already_decided":
            return jsonify({
                "ok": False,
                "error": (
                    "Demande déjà traitée / "
                    "Request already processed"
                ),
                "status": row.get("status"),
            }), 409

        (
            notification_sent,
            notification_error,
        ) = send_pairing_rejected_notification(
            row
        )

        return jsonify({
            "ok": True,
            "status": "rejected",
            "request_id": request_id,
            "notification_sent": notification_sent,
            "notification_error": notification_error,
        })

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
        }), 400


@app.route("/telegram/users")
def telegram_users_page():
    try:
        users = list_telegram_users(active_only=False)
        return render_template("telegram_users.html", users=users)
    except Exception as exc:
        return render_template("telegram_users.html", users=[], error=str(exc)), 500


@app.get("/api/telegram/users")
def telegram_users_api():
    try:
        active_only = request.args.get("active_only", "0").strip().lower() in ("1", "true", "yes", "on")
        return jsonify({"ok": True, "users": list_telegram_users(active_only=active_only)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.post("/api/telegram/users/<int:user_id>/active")
def telegram_user_active_api(user_id):
    try:
        data = request.get_json(silent=True) or {}
        active = bool(data.get("active"))
        row = set_telegram_user_active(user_id, active)
        if not row:
            return jsonify({"ok": False, "error": "Utilisateur Telegram introuvable"}), 404
        return jsonify({"ok": True, "user": row})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/history/<path:mac>")
def history_api(mac):
    with state_lock:
        dev = devices_state.get(mac)

        if not dev:
            return {
                "ok": False,
                "error": "Appareil inconnu"
            }, 404

        return {
            "ok": True,
            "device": {
                "deviceName": dev.get("deviceName", "COLMI Device"),
                "mac": dev.get("mac", mac),
            },
            "logs": list(dev.get("logs", [])),
        }

@app.route("/history/<path:mac>")
def history(mac):
    with state_lock:
        dev = devices_state.get(mac)
        if not dev:
            return "Appareil inconnu", 404
        device = dict(dev)
        logs = list(dev.get("logs", []))
    return render_template("history.html", device=device, logs=logs)


@app.post("/clear")
def clear():
    with state_lock:
        devices_state.clear()
        raw_messages.clear()
        try:
            if STATE_FILE.exists():
                STATE_FILE.unlink()
        except Exception:
            pass
    return redirect(url_for("index"))


# Démarrage également à l'import (Waitress / WSGI).
start_services()


if __name__ == "__main__":
    app.run(
        host=FLASK_HOST,
        port=FLASK_PORT,
        debug=False,
        threaded=True,
        use_reloader=False,
    )