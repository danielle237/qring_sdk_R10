import os
import time
import queue
import threading
import statistics
import secrets
import re
from datetime import datetime, timezone

try:
    import psycopg
    from psycopg.rows import dict_row
    from psycopg.types.json import Jsonb
except Exception:  # permet au dashboard de démarrer si psycopg n'est pas encore installé
    psycopg = None
    dict_row = None
    Jsonb = None

DB_ENABLED = os.getenv("DB_ENABLED", "1").strip().lower() not in ("0", "false", "no", "off")
DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "dany")
DB_USER = os.getenv("DB_USER", "dany")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_CONNECT_TIMEOUT = int(os.getenv("DB_CONNECT_TIMEOUT", "5"))
DB_QUEUE_SIZE = int(os.getenv("DB_QUEUE_SIZE", "5000"))
DB_MAX_RETRIES = int(os.getenv("DB_MAX_RETRIES", "5"))
GATEWAY_NAME = os.getenv("GATEWAY_NAME", "gateway_pi400_01")
GATEWAY_LOCATION = os.getenv("GATEWAY_LOCATION", "")
GATEWAY_SOFTWARE_VERSION = os.getenv("GATEWAY_SOFTWARE_VERSION", "DANY Flask DB V6")

PAIRING_DEFAULT_ALERTS = os.getenv(
    "PAIRING_DEFAULT_ALERTS", "0"
).strip().lower() in ("1", "true", "yes", "on")

TELEGRAM_WEBAPP_ACTIVE_SECONDS = max(
    30,
    int(os.getenv("TELEGRAM_WEBAPP_ACTIVE_SECONDS", "60")),
)

_db_queue = queue.Queue(maxsize=DB_QUEUE_SIZE)
_worker_started = False
_worker_lock = threading.Lock()
_status_lock = threading.Lock()
_db_status = {
    "enabled": DB_ENABLED,
    "connected": False,
    "message": "Base de données en attente" if DB_ENABLED else "Base de données désactivée",
    "last_error": None,
    "queue_size": 0,
    "stored_messages": 0,
    "dropped_messages": 0,

    # Diagnostic des écritures PostgreSQL.
    # La dernière erreur d'insertion reste mémorisée même après
    # une reconnexion/réussite, afin qu'elle reste visible dans Flask.
    "insert_errors": 0,
    "last_insert_error": None,
    "last_insert_error_time": None,
    "last_insert_error_topic": None,
    "last_insert_ok_time": None,
    "last_insert_ok_topic": None,
}


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def get_db_status():
    with _status_lock:
        out = dict(_db_status)
        out["queue_size"] = _db_queue.qsize()
        return out


def _set_status(**kwargs):
    with _status_lock:
        _db_status.update(kwargs)
        _db_status["queue_size"] = _db_queue.qsize()


def _connection_kwargs():
    return {
        "host": DB_HOST,
        "port": DB_PORT,
        "dbname": DB_NAME,
        "user": DB_USER,
        "password": DB_PASSWORD,
        "connect_timeout": DB_CONNECT_TIMEOUT,
    }


def get_connection(*, rows=False):
    if not DB_ENABLED:
        raise RuntimeError("DB_ENABLED=0")
    if psycopg is None:
        raise RuntimeError("Le module psycopg n'est pas installé. Installer psycopg[binary].")

    kwargs = _connection_kwargs()
    if rows:
        kwargs["row_factory"] = dict_row
    conn = psycopg.connect(**kwargs)
    conn.autocommit = True
    return conn


def test_database():
    if not DB_ENABLED:
        _set_status(connected=False, message="Base de données désactivée", last_error=None)
        return False
    try:
        with get_connection(rows=True) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT current_database() AS db, now() AS now")
                row = cur.fetchone()
        _set_status(
            connected=True,
            message=f"PostgreSQL connecté : {row['db']}",
            last_error=None,
        )
        return True
    except Exception as exc:
        _set_status(connected=False, message=f"PostgreSQL indisponible : {exc}", last_error=str(exc))
        return False


def enqueue_mqtt_message(topic, payload, received_at=None):
    """Ajoute un message MQTT dans la file DB sans bloquer le thread MQTT."""
    if not DB_ENABLED:
        return False

    item = {
        "topic": topic,
        "payload": payload,
        "received_at": received_at or now_iso(),
        "retry": 0,
    }
    try:
        _db_queue.put_nowait(item)
        _set_status(queue_size=_db_queue.qsize())
        return True
    except queue.Full:
        with _status_lock:
            _db_status["dropped_messages"] += 1
            _db_status["insert_errors"] += 1
            _db_status["last_insert_error"] = (
                "File PostgreSQL pleine : message MQTT non mis en file"
            )
            _db_status["last_insert_error_time"] = now_iso()
            _db_status["last_insert_error_topic"] = topic
            _db_status["message"] = (
                "Attention : file DB pleine, message ignoré"
            )
        return False


def start_db_worker():
    global _worker_started
    if not DB_ENABLED:
        _set_status(connected=False, message="Base de données désactivée")
        return
    with _worker_lock:
        if _worker_started:
            return
        _worker_started = True
        thread = threading.Thread(target=_db_worker, name="colmi-db-worker", daemon=True)
        thread.start()


def _db_worker():
    conn = None
    gateway_id = None

    while True:
        item = _db_queue.get()
        try:
            if conn is None or conn.closed:
                conn = get_connection()
                gateway_id = _ensure_gateway(conn)
                _set_status(
                    connected=True,
                    message=f"PostgreSQL connecté : {DB_NAME}",
                    last_error=None,
                )

            _process_message(conn, gateway_id, item)

            with _status_lock:
                _db_status["stored_messages"] += 1
                _db_status["connected"] = True
                _db_status["last_error"] = None
                _db_status["queue_size"] = _db_queue.qsize()

                # Dernière insertion réussie.
                _db_status["last_insert_ok_time"] = now_iso()
                _db_status["last_insert_ok_topic"] = item.get("topic")

        except Exception as exc:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
            conn = None
            gateway_id = None

            item["retry"] = int(item.get("retry", 0)) + 1

            # Conserver un diagnostic durable de l'erreur d'écriture.
            with _status_lock:
                _db_status["insert_errors"] += 1
                _db_status["last_insert_error"] = str(exc)
                _db_status["last_insert_error_time"] = now_iso()
                _db_status["last_insert_error_topic"] = item.get("topic")

            _set_status(
                connected=False,
                message=f"Erreur PostgreSQL : {exc}",
                last_error=str(exc),
            )

            if item["retry"] <= DB_MAX_RETRIES:
                time.sleep(min(5, item["retry"]))
                try:
                    _db_queue.put_nowait(item)
                except queue.Full:
                    with _status_lock:
                        _db_status["dropped_messages"] += 1
                        _db_status["insert_errors"] += 1
                        _db_status["last_insert_error"] = (
                            "File PostgreSQL pleine pendant retry : message abandonné"
                        )
                        _db_status["last_insert_error_time"] = now_iso()
                        _db_status["last_insert_error_topic"] = item.get("topic")
            else:
                print(f"DB: abandon après {DB_MAX_RETRIES} tentatives: {exc}")

        finally:
            _db_queue.task_done()


def _ensure_gateway(conn):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO gateways (name, location, software_version, last_seen)
            VALUES (%s, %s, %s, NOW())
            ON CONFLICT (name)
            DO UPDATE SET
                location = COALESCE(NULLIF(EXCLUDED.location, ''), gateways.location),
                software_version = EXCLUDED.software_version,
                last_seen = NOW(),
                updated_at = NOW()
            RETURNING id
            """,
            (GATEWAY_NAME, GATEWAY_LOCATION, GATEWAY_SOFTWARE_VERSION),
        )
        return cur.fetchone()[0]


def _topic_info(topic):
    parts = [p for p in str(topic).split("/") if p]
    sub_type = parts[-1].lower() if parts else ""
    mac = parts[-2] if len(parts) >= 2 else ""
    model_token = parts[-3] if len(parts) >= 3 else ""
    base_topic = "/".join(parts[:3]) if len(parts) >= 3 else "/".join(parts[:-2])
    return sub_type, mac, model_token, base_topic


def _normalize_model(device_name, model_token):
    token = (model_token or "").strip()
    if token:
        return token.split("_")[0]
    name = (device_name or "").replace("COLMI", "").strip()
    if name:
        return name.split("_")[0].split()[0]
    return None


def _ensure_ring(conn, topic, payload):
    sub_type, topic_mac, model_token, base_topic = _topic_info(topic)
    mac = str(payload.get("mac") or topic_mac or "").strip()
    if not mac:
        raise ValueError(f"MAC introuvable pour topic {topic}")

    device_name = str(payload.get("device") or (f"COLMI {model_token}" if model_token else "COLMI Device"))
    infos = payload.get("device_infos") if isinstance(payload.get("device_infos"), dict) else {}
    hw_version = payload.get("hw_version") or infos.get("hw_version")
    fw_version = payload.get("fw_version") or infos.get("fw_version")
    model = _normalize_model(device_name, model_token)

    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO rings (
                mac, name, model, hw_version, fw_version, mqtt_base_topic, last_seen
            )
            VALUES (%s, %s, %s, %s, %s, %s, NOW())
            ON CONFLICT (mac)
            DO UPDATE SET
                name = EXCLUDED.name,
                model = COALESCE(EXCLUDED.model, rings.model),
                hw_version = COALESCE(EXCLUDED.hw_version, rings.hw_version),
                fw_version = COALESCE(EXCLUDED.fw_version, rings.fw_version),
                mqtt_base_topic = COALESCE(EXCLUDED.mqtt_base_topic, rings.mqtt_base_topic),
                last_seen = NOW(),
                updated_at = NOW()
            RETURNING id
            """,
            (mac, device_name, model, hw_version, fw_version, base_topic or None),
        )
        ring_id = cur.fetchone()[0]

    return ring_id, mac, sub_type


def _float_value(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        text = value.strip().replace(",", ".")
        for suffix in ("%", "bpm", "dbm", "°c", "c"):
            if text.lower().endswith(suffix):
                text = text[: -len(suffix)].strip()
                break
        try:
            return float(text)
        except Exception:
            return None
    return None


def _numeric_samples(value):
    if not isinstance(value, (list, tuple)):
        return None
    out = []
    for item in value:
        num = _float_value(item)
        if num is not None:
            out.append(num)
    return out or None


def _extract_sensor(payload):
    root_status = str(payload.get("status") or "").strip().lower()
    root_reason = payload.get("reason")
    root_unit = payload.get("unit")
    raw = payload.get("value")

    if isinstance(raw, dict):
        data = raw
        status = str(data.get("status") or root_status or "ok").strip().lower()
        reason = data.get("reason") or root_reason
        unit = data.get("unit") or root_unit
        samples = _numeric_samples(data.get("samples") or payload.get("samples"))

        candidate = data.get("value_median")
        if candidate is None:
            candidate = data.get("median")
        if candidate is None:
            candidate = data.get("last")
        if candidate is None:
            candidate = data.get("value")
        if candidate is None:
            candidate = payload.get("value2")
    else:
        status = root_status or "ok"
        reason = root_reason
        unit = root_unit
        samples = _numeric_samples(raw) or _numeric_samples(payload.get("samples"))
        candidate = payload.get("value2") if payload.get("value2") is not None else raw

    if samples and (_float_value(candidate) is None):
        candidate = statistics.median(samples)

    value = _float_value(candidate)
    return status, reason, unit, value, samples


def _insert_measurement(
    conn,
    *,
    when,
    ring_id,
    gateway_id,
    metric,
    value,
    samples=None,
    unit=None,
    status="ok",
    reason=None,
    experimental=False,
    extra=None,
):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ring_measurements (
                time, ring_id, gateway_id, metric, value, samples, unit,
                status, reason, experimental, extra
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                when,
                ring_id,
                gateway_id,
                metric,
                value,
                samples,
                unit,
                status or "ok",
                reason,
                bool(experimental),
                Jsonb(extra or {}),
            ),
        )


def _ensure_current_row(conn, ring_id, gateway_id, when, *, online=True):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ring_current_state (
                ring_id, gateway_id, online, last_measurement_at, updated_at
            )
            VALUES (%s, %s, %s, %s, NOW())
            ON CONFLICT (ring_id)
            DO UPDATE SET
                gateway_id = EXCLUDED.gateway_id,
                online = EXCLUDED.online,
                last_measurement_at = EXCLUDED.last_measurement_at,
                updated_at = NOW()
            """,
            (ring_id, gateway_id, online, when),
        )


def _update_current_fields(conn, ring_id, fields):
    allowed = {
        "gateway_id",
        "online",
        "battery",
        "charging",
        "heart_rate",
        "spo2",
        "hrv",
        "fatigue",
        "health_check",
        "temperature",
        "steps",
        "distance_m",
        "calories_raw",
        "rssi",
        "wear_status",
        "ble_status",
        "last_measurement_at",
    }
    clean = {k: v for k, v in fields.items() if k in allowed}
    if not clean:
        return
    assignments = ", ".join(f"{key} = %s" for key in clean)
    values = list(clean.values()) + [ring_id]
    with conn.cursor() as cur:
        cur.execute(
            f"UPDATE ring_current_state SET {assignments}, updated_at = NOW() WHERE ring_id = %s",
            values,
        )


def _insert_event(conn, *, when, ring_id, gateway_id, event_type, severity="info", reason=None, details=None):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO ring_events (
                time, ring_id, gateway_id, event_type, severity, reason, details
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (when, ring_id, gateway_id, event_type, severity, reason, Jsonb(details or {})),
        )


def _get_current_wear_status(conn, ring_id):
    with conn.cursor() as cur:
        cur.execute("SELECT wear_status FROM ring_current_state WHERE ring_id = %s", (ring_id,))
        row = cur.fetchone()
        return row[0] if row else None


def _process_message(conn, gateway_id, item):
    topic = item["topic"]
    payload = item["payload"] if isinstance(item.get("payload"), dict) else {}
    received_at = item.get("received_at") or now_iso()
    ring_id, mac, sub_type = _ensure_ring(conn, topic, payload)

    when = payload.get("timestamp") or received_at
    type_mesure = str(payload.get("Type_mesure") or "").strip().lower()
    metric = type_mesure or sub_type
    if metric == "rate":
        metric = "heart_rate"

    # La présence d'un message MQTT valide met à jour la gateway.
    with conn.cursor() as cur:
        cur.execute("UPDATE gateways SET last_seen = NOW(), updated_at = NOW() WHERE id = %s", (gateway_id,))

    root_status = str(payload.get("status") or "").strip().lower()

    # --------------------------------------------------------
    # Messages de progression : état live uniquement, PAS historique.
    # --------------------------------------------------------
    if root_status == "en_cours":
        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        return

    # --------------------------------------------------------
    # OUTSIDE / HORS PORTEE
    # --------------------------------------------------------
    if sub_type == "outside":
        fault_code = str(payload.get("fault_code") or "").strip()
        _ensure_current_row(conn, ring_id, gateway_id, when, online=False)
        _update_current_fields(
            conn,
            ring_id,
            {
                "online": False,
                "heart_rate": None,
                "spo2": None,
                "fatigue": None,
                "health_check": None,
                "ble_status": fault_code or "outside",
                "last_measurement_at": when,
            },
        )
        _insert_event(
            conn,
            when=when,
            ring_id=ring_id,
            gateway_id=gateway_id,
            event_type="out_of_zone" if fault_code in ("device_not_found", "device_out_of_range") else "ble_alert",
            severity="warning",
            reason=fault_code or None,
            details=payload,
        )
        return

    # --------------------------------------------------------
    # BATTERIE
    # --------------------------------------------------------
    if metric == "battery" or sub_type == "battery":
        raw = payload.get("value")
        if isinstance(raw, dict):
            level = raw.get("value", raw.get("level"))
            charging = raw.get("charging", payload.get("charging"))
        else:
            level = payload.get("value2", raw)
            charging = payload.get("charging")

        level_num = _float_value(level)
        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        _insert_measurement(
            conn,
            when=when,
            ring_id=ring_id,
            gateway_id=gateway_id,
            metric="battery",
            value=level_num,
            unit="%",
            status="ok",
            extra={"charging": bool(charging) if charging is not None else None},
        )
        _update_current_fields(
            conn,
            ring_id,
            {
                "online": True,
                "battery": level_num,
                "charging": charging,
                "ble_status": "ok",
                "last_measurement_at": when,
            },
        )
        return

    # --------------------------------------------------------
    # STEPS : 3 mesures historisées séparément
    # --------------------------------------------------------
    if metric == "steps" or sub_type == "steps":
        raw = payload.get("value")
        data = raw if isinstance(raw, dict) else payload
        steps = _float_value(data.get("steps", payload.get("value2", raw)))
        distance = _float_value(data.get("distance_m", payload.get("distance_m")))
        calories = _float_value(data.get("calories_raw", payload.get("calories_raw")))

        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        if steps is not None:
            _insert_measurement(conn, when=when, ring_id=ring_id, gateway_id=gateway_id, metric="steps", value=steps, unit="steps")
        if distance is not None:
            _insert_measurement(conn, when=when, ring_id=ring_id, gateway_id=gateway_id, metric="distance", value=distance, unit="m")
        if calories is not None:
            _insert_measurement(conn, when=when, ring_id=ring_id, gateway_id=gateway_id, metric="calories", value=calories, unit="raw")

        _update_current_fields(
            conn,
            ring_id,
            {
                "online": True,
                "steps": steps,
                "distance_m": distance,
                "calories_raw": calories,
                "ble_status": "ok",
                "last_measurement_at": when,
            },
        )
        return

    # --------------------------------------------------------
    # WEAR STATUS : état courant + événement uniquement si changement
    # --------------------------------------------------------
    if metric == "wear_status" or sub_type == "wear_status":
        wear = str(payload.get("value") or payload.get("status") or "unknown")
        reason = payload.get("reason")
        previous = _get_current_wear_status(conn, ring_id)
        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        _update_current_fields(
            conn,
            ring_id,
            {
                "wear_status": wear,
                "charging": payload.get("charging"),
                "last_measurement_at": when,
            },
        )
        if previous != wear:
            event_type = "ring_removed" if wear in ("removed", "probably_removed") else "ring_worn" if wear == "worn" else "wear_status_changed"
            _insert_event(
                conn,
                when=when,
                ring_id=ring_id,
                gateway_id=gateway_id,
                event_type=event_type,
                severity="info",
                reason=reason,
                details=payload,
            )
        return

    # --------------------------------------------------------
    # RSSI
    # --------------------------------------------------------
    if metric == "rssi" or sub_type == "rssi":
        rssi = _float_value(payload.get("value"))
        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        if rssi is not None:
            _insert_measurement(conn, when=when, ring_id=ring_id, gateway_id=gateway_id, metric="rssi", value=rssi, unit="dBm")
        _update_current_fields(conn, ring_id, {"online": True, "rssi": rssi, "last_measurement_at": when})
        return

    # --------------------------------------------------------
    # SNAPSHOT : met à jour quelques états mais n'efface pas un OUTSIDE
    # --------------------------------------------------------
    if sub_type == "snapshot":
        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        fields = {
            "charging": payload.get("charging"),
            "wear_status": payload.get("wear_status"),
            "last_measurement_at": when,
        }
        if payload.get("battery") is not None:
            fields["battery"] = _float_value(payload.get("battery"))
        if payload.get("steps") is not None:
            fields["steps"] = _float_value(payload.get("steps"))
        if payload.get("distance_m") is not None:
            fields["distance_m"] = _float_value(payload.get("distance_m"))
        _update_current_fields(conn, ring_id, fields)
        return

    # --------------------------------------------------------
    # MESURES SANTE / SCORES
    # --------------------------------------------------------
    sensor_map = {
        "heart_rate": ("heart_rate", "bpm", False),
        "spo2": ("spo2", "%", False),
        "hrv": ("hrv", "raw", True),
        "fatigue": ("fatigue", "score", True),
        "health_check": ("health_check", "score", True),
        "temperature": ("temperature", "°C", False),
        "blood_sugar": ("blood_sugar_proxy", "raw", True),
        "blood_sugar_proxy": ("blood_sugar_proxy", "raw", True),
    }

    if metric in sensor_map or sub_type in sensor_map:
        key = metric if metric in sensor_map else sub_type
        metric_name, default_unit, experimental = sensor_map[key]
        status, reason, unit, value, samples = _extract_sensor(payload)
        unit = unit or default_unit

        # Les statuts finaux, y compris les échecs, sont historisés.
        if status == "en_cours":
            return

        _ensure_current_row(conn, ring_id, gateway_id, when, online=True)
        _insert_measurement(
            conn,
            when=when,
            ring_id=ring_id,
            gateway_id=gateway_id,
            metric=metric_name,
            value=value,
            samples=samples,
            unit=unit,
            status=status or "ok",
            reason=reason,
            experimental=experimental,
            extra={"source": "ring_firmware"},
        )

        current_column = metric_name if metric_name != "blood_sugar_proxy" else None
        fields = {
            "online": True,
            "ble_status": "ok" if status == "ok" else status,
            "last_measurement_at": when,
        }
        if current_column:
            fields[current_column] = value
        _update_current_fields(conn, ring_id, fields)
        return

    # Message inconnu : on garde seulement last_seen via rings/gateways.


# ============================================================================
# API / ADMIN TELEGRAM
# ============================================================================

def _get_ring_by_mac(conn, mac):
    with conn.cursor() as cur:
        cur.execute(
            "SELECT id, mac::text AS mac, name, model FROM rings WHERE mac = %s::macaddr",
            (mac,),
        )
        return cur.fetchone()


def list_telegram_users(active_only=False):
    """Liste les utilisateurs réellement connus du bot (/start)."""
    where = "WHERE u.active = TRUE" if active_only else ""
    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT
                    u.id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.langue_user,
                    u.date_premiere_connexion,
                    u.date_last_connexion,
                    u.active,
                    COUNT(rta.id) FILTER (WHERE rta.active = TRUE) AS rings_count
                FROM t_user_app_telegram u
                LEFT JOIN ring_telegram_access rta
                    ON rta.telegram_user_id = u.id
                {where}
                GROUP BY
                    u.id, u.id_telegram, u.firstname, u.lastname, u.pseudo,
                    u.langue_user, u.date_premiere_connexion,
                    u.date_last_connexion, u.active
                ORDER BY
                    u.active DESC,
                    u.firstname NULLS LAST,
                    u.lastname NULLS LAST,
                    u.pseudo NULLS LAST,
                    u.id_telegram
                """
            )
            return [dict(r) for r in cur.fetchall()]


def set_telegram_user_active(user_id, active):
    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE t_user_app_telegram
                SET active = %s,
                    updated_at = NOW()
                WHERE id = %s
                RETURNING
                    id, id_telegram, firstname, lastname, pseudo,
                    langue_user, date_premiere_connexion,
                    date_last_connexion, active
                """,
                (bool(active), int(user_id)),
            )
            row = cur.fetchone()
            return dict(row) if row else None


def list_telegram_access(mac):
    with get_connection(rows=True) as conn:
        ring = _get_ring_by_mac(conn, mac)
        if not ring:
            return None, []

        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    rta.id AS access_id,
                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.langue_user,
                    u.active AS user_active,
                    rta.can_view,
                    rta.can_view_history,
                    rta.can_live,
                    rta.can_receive_alerts,
                    rta.can_admin,
                    rta.active
                FROM ring_telegram_access rta
                JOIN t_user_app_telegram u
                    ON u.id = rta.telegram_user_id
                WHERE rta.ring_id = %s
                ORDER BY
                    u.firstname NULLS LAST,
                    u.lastname NULLS LAST,
                    u.pseudo NULLS LAST,
                    u.id_telegram
                """,
                (ring["id"],),
            )
            rows = cur.fetchall()

        return dict(ring), [dict(r) for r in rows]


def upsert_telegram_access(mac, data):
    raw_user_id = str(data.get("telegram_user_id", "")).strip()
    if not raw_user_id:
        raise ValueError("telegram_user_id obligatoire")

    telegram_user_id = int(raw_user_id)

    def as_bool(name, default=False):
        value = data.get(name, default)
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "on", "oui")

    with get_connection(rows=True) as conn:
        ring = _get_ring_by_mac(conn, mac)
        if not ring:
            raise LookupError("Bague inconnue dans PostgreSQL")

        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, id_telegram, firstname, lastname, pseudo, active
                FROM t_user_app_telegram
                WHERE id = %s
                """,
                (telegram_user_id,),
            )
            user = cur.fetchone()
            if not user:
                raise LookupError("Utilisateur Telegram inconnu : il doit d'abord faire /start")
            if not user["active"]:
                raise ValueError("Utilisateur Telegram désactivé")

            cur.execute(
                """
                INSERT INTO ring_telegram_access (
                    ring_id,
                    telegram_user_id,
                    can_view,
                    can_view_history,
                    can_live,
                    can_receive_alerts,
                    can_admin,
                    active
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, TRUE)
                ON CONFLICT (ring_id, telegram_user_id)
                DO UPDATE SET
                    can_view = EXCLUDED.can_view,
                    can_view_history = EXCLUDED.can_view_history,
                    can_live = EXCLUDED.can_live,
                    can_receive_alerts = EXCLUDED.can_receive_alerts,
                    can_admin = EXCLUDED.can_admin,
                    active = TRUE,
                    updated_at = NOW()
                RETURNING id
                """,
                (
                    ring["id"],
                    telegram_user_id,
                    as_bool("can_view", True),
                    as_bool("can_view_history", True),
                    as_bool("can_live", True),
                    as_bool("can_receive_alerts", False),
                    as_bool("can_admin", False),
                ),
            )
            return cur.fetchone()["id"]


def delete_telegram_access(mac, access_id):
    with get_connection(rows=True) as conn:
        ring = _get_ring_by_mac(conn, mac)
        if not ring:
            raise LookupError("Bague inconnue")

        with conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM ring_telegram_access
                WHERE id = %s
                  AND ring_id = %s
                RETURNING id
                """,
                (access_id, ring["id"]),
            )
            return bool(cur.fetchone())



# ============================================================================
# ADMIN QR PAIRING - FLASK
# ============================================================================

def list_pairing_requests(status=None, limit=200):
    """
    Liste les demandes d'appariement QR.

    status:
      - None / "all" : toutes
      - pending
      - approved
      - rejected
      - cancelled
    """
    limit = max(1, min(int(limit), 1000))

    allowed = {
        "pending",
        "approved",
        "rejected",
        "cancelled",
    }

    params = []
    where = ""

    if status and str(status).lower() != "all":
        status = str(status).lower().strip()

        if status not in allowed:
            raise ValueError("Statut pairing invalide")

        where = "WHERE pr.status = %s"
        params.append(status)

    params.append(limit)

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT
                    pr.id AS request_id,
                    pr.status,
                    pr.requested_at,
                    pr.decided_at,
                    pr.decided_by_telegram_id,
                    pr.decided_by_source,
                    pr.decided_by_label,

                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,

                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.langue_user,
                    u.active AS user_active

                FROM ring_pairing_requests pr

                JOIN rings r
                  ON r.id = pr.ring_id

                JOIN t_user_app_telegram u
                  ON u.id = pr.telegram_user_id

                {where}

                ORDER BY
                    CASE WHEN pr.status = 'pending' THEN 0 ELSE 1 END,
                    pr.requested_at DESC

                LIMIT %s
                """,
                params,
            )

            return [dict(row) for row in cur.fetchall()]


def get_pairing_request_admin(request_id):
    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    pr.id AS request_id,
                    pr.status,
                    pr.requested_at,
                    pr.decided_at,

                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,

                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.langue_user,
                    u.active AS user_active

                FROM ring_pairing_requests pr

                JOIN rings r
                  ON r.id = pr.ring_id

                JOIN t_user_app_telegram u
                  ON u.id = pr.telegram_user_id

                WHERE pr.id = %s
                """,
                (int(request_id),),
            )

            row = cur.fetchone()
            return dict(row) if row else None


def approve_pairing_request_admin(
    request_id,
    *,
    admin_label="Flask admin",
):
    """
    Approuve une demande PENDING depuis le dashboard Flask.

    Crée/réactive ring_telegram_access avec les permissions de base.
    Retourne la demande enrichie pour permettre la notification Telegram.
    """
    with get_connection(rows=True) as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        pr.id AS request_id,
                        pr.status,
                        pr.ring_id,
                        pr.telegram_user_id,

                        r.name AS ring_name,
                        r.mac::text AS mac,
                        r.model,

                        u.id_telegram,
                        u.firstname,
                        u.lastname,
                        u.pseudo,
                        u.active AS user_active

                    FROM ring_pairing_requests pr

                    JOIN rings r
                      ON r.id = pr.ring_id

                    JOIN t_user_app_telegram u
                      ON u.id = pr.telegram_user_id

                    WHERE pr.id = %s
                    FOR UPDATE
                    """,
                    (int(request_id),),
                )

                row = cur.fetchone()

                if not row:
                    return None

                row = dict(row)

                if row["status"] != "pending":
                    row["result"] = "already_decided"
                    return row

                if not row.get("user_active"):
                    raise ValueError(
                        "Utilisateur Telegram désactivé"
                    )

                cur.execute(
                    """
                    INSERT INTO ring_telegram_access (
                        ring_id,
                        telegram_user_id,
                        can_view,
                        can_view_history,
                        can_live,
                        can_receive_alerts,
                        can_admin,
                        active
                    )
                    VALUES (
                        %s, %s,
                        TRUE, TRUE, TRUE, %s, FALSE, TRUE
                    )

                    ON CONFLICT (ring_id, telegram_user_id)

                    DO UPDATE SET
                        can_view = TRUE,
                        can_view_history = TRUE,
                        can_live = TRUE,
                        can_receive_alerts = EXCLUDED.can_receive_alerts,
                        can_admin = FALSE,
                        active = TRUE,
                        updated_at = NOW()
                    """,
                    (
                        row["ring_id"],
                        row["telegram_user_id"],
                        bool(PAIRING_DEFAULT_ALERTS),
                    ),
                )

                cur.execute(
                    """
                    UPDATE ring_pairing_requests

                    SET
                        status = 'approved',
                        decided_at = NOW(),
                        decided_by_telegram_id = NULL,
                        decided_by_source = 'flask',
                        decided_by_label = %s

                    WHERE id = %s
                    """,
                    (
                        str(admin_label)[:128],
                        int(request_id),
                    ),
                )

                row["result"] = "approved"
                row["status"] = "approved"
                return row


def reject_pairing_request_admin(
    request_id,
    *,
    admin_label="Flask admin",
):
    """
    Refuse une demande QR depuis le dashboard Flask.
    """
    with get_connection(rows=True) as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        pr.id AS request_id,
                        pr.status,
                        pr.ring_id,
                        pr.telegram_user_id,

                        r.name AS ring_name,
                        r.mac::text AS mac,
                        r.model,

                        u.id_telegram,
                        u.firstname,
                        u.lastname,
                        u.pseudo

                    FROM ring_pairing_requests pr

                    JOIN rings r
                      ON r.id = pr.ring_id

                    JOIN t_user_app_telegram u
                      ON u.id = pr.telegram_user_id

                    WHERE pr.id = %s
                    FOR UPDATE
                    """,
                    (int(request_id),),
                )

                row = cur.fetchone()

                if not row:
                    return None

                row = dict(row)

                if row["status"] != "pending":
                    row["result"] = "already_decided"
                    return row

                cur.execute(
                    """
                    UPDATE ring_pairing_requests

                    SET
                        status = 'rejected',
                        decided_at = NOW(),
                        decided_by_telegram_id = NULL,
                        decided_by_source = 'flask',
                        decided_by_label = %s

                    WHERE id = %s
                    """,
                    (
                        str(admin_label)[:128],
                        int(request_id),
                    ),
                )

                row["result"] = "rejected"
                row["status"] = "rejected"
                return row


# ============================================================================
# TELEGRAM MINI APP / WEB APP
# ============================================================================

def _normalize_webapp_ring_key(value):
    return re.sub(
        r"[^0-9a-fA-F]",
        "",
        str(value or ""),
    ).lower()


def get_webapp_ring_access(telegram_id, ring_key):
    """
    Vérifie qu'un utilisateur Telegram actif peut voir cette bague.

    ring_key peut être :
      303242326401
      30:32:42:32:64:01
    """
    ring_key = _normalize_webapp_ring_key(ring_key)

    if len(ring_key) != 12:
        return None

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.langue_user,

                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,

                    rta.can_view,
                    rta.can_view_history,
                    rta.can_live,
                    rta.can_receive_alerts,
                    rta.can_admin

                FROM t_user_app_telegram u

                JOIN ring_telegram_access rta
                  ON rta.telegram_user_id = u.id

                JOIN rings r
                  ON r.id = rta.ring_id

                WHERE u.id_telegram = %s
                  AND u.active = TRUE
                  AND rta.active = TRUE
                  AND rta.can_view = TRUE
                  AND r.active = TRUE
                  AND LOWER(REPLACE(r.mac::text, ':', '')) = %s

                LIMIT 1
                """,
                (
                    int(telegram_id),
                    ring_key,
                ),
            )

            row = cur.fetchone()
            return dict(row) if row else None


def create_webapp_session(
    telegram_user_id,
    ring_id,
    *,
    telegram_auth_date=None,
    telegram_query_id=None,
):
    """
    Ouvre une session WebApp persistée.

    Le token n'est envoyé qu'à la WebApp déjà authentifiée par initData.
    """
    session_token = secrets.token_urlsafe(36)

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO telegram_webapp_sessions (
                    session_token,
                    telegram_user_id,
                    ring_id,
                    telegram_auth_date,
                    telegram_query_id,
                    active
                )
                VALUES (
                    %s, %s, %s, %s, %s, TRUE
                )
                RETURNING
                    id,
                    session_token,
                    opened_at,
                    last_seen_at,
                    active
                """,
                (
                    session_token,
                    int(telegram_user_id),
                    int(ring_id),
                    telegram_auth_date,
                    telegram_query_id,
                ),
            )

            row = dict(cur.fetchone())

            cur.execute(
                """
                INSERT INTO telegram_webapp_events (
                    session_id,
                    event_type
                )
                VALUES (%s, 'OPEN')
                """,
                (row["id"],),
            )

            return row


def get_webapp_session(session_token, *, touch=False):
    if not session_token:
        return None

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            if touch:
                cur.execute(
                    """
                    UPDATE telegram_webapp_sessions
                    SET
                        last_seen_at = NOW(),
                        active = TRUE
                    WHERE session_token = %s
                      AND closed_at IS NULL
                    RETURNING id
                    """,
                    (str(session_token),),
                )

                if not cur.fetchone():
                    return None

            cur.execute(
                """
                SELECT
                    s.id AS session_id,
                    s.session_token,
                    s.opened_at,
                    s.last_seen_at,
                    s.closed_at,
                    s.active,

                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    u.active AS user_active,

                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,
                    r.active AS ring_active,

                    rta.active AS access_active,
                    rta.can_view

                FROM telegram_webapp_sessions s

                JOIN t_user_app_telegram u
                  ON u.id = s.telegram_user_id

                JOIN rings r
                  ON r.id = s.ring_id

                LEFT JOIN ring_telegram_access rta
                  ON rta.telegram_user_id = s.telegram_user_id
                 AND rta.ring_id = s.ring_id

                WHERE s.session_token = %s
                LIMIT 1
                """,
                (str(session_token),),
            )

            row = cur.fetchone()

            if not row:
                return None

            row = dict(row)

            if (
                row.get("closed_at") is not None
                or not row.get("user_active")
                or not row.get("ring_active")
                or not row.get("access_active")
                or not row.get("can_view")
            ):
                return None

            return row


def close_webapp_session(session_token):
    if not session_token:
        return False

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE telegram_webapp_sessions
                SET
                    active = FALSE,
                    closed_at = COALESCE(closed_at, NOW()),
                    last_seen_at = NOW()
                WHERE session_token = %s
                  AND closed_at IS NULL
                RETURNING id
                """,
                (str(session_token),),
            )

            row = cur.fetchone()

            if not row:
                return False

            session_id = row["id"]

            cur.execute(
                """
                INSERT INTO telegram_webapp_events (
                    session_id,
                    event_type
                )
                VALUES (%s, 'CLOSE')
                """,
                (session_id,),
            )

            return True


def list_webapp_sessions(limit=300):
    """
    Liste admin : qui a ouvert quelle bague, quand, et dernière activité.

    Une session sans heartbeat récent est marquée inactive même si
    le navigateur n'a pas pu envoyer CLOSE.
    """
    limit = max(1, min(int(limit), 1000))

    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE telegram_webapp_sessions
                SET active = FALSE
                WHERE active = TRUE
                  AND closed_at IS NULL
                  AND last_seen_at
                      < NOW()
                        - (%s * INTERVAL '1 second')
                """,
                (int(TELEGRAM_WEBAPP_ACTIVE_SECONDS),),
            )

            cur.execute(
                """
                SELECT
                    s.id AS session_id,
                    s.opened_at,
                    s.last_seen_at,
                    s.closed_at,
                    s.active,

                    (
                        s.closed_at IS NULL
                        AND s.last_seen_at
                            >= NOW()
                               - (%s * INTERVAL '1 second')
                    ) AS is_active,

                    u.id AS telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,

                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model

                FROM telegram_webapp_sessions s

                JOIN t_user_app_telegram u
                  ON u.id = s.telegram_user_id

                JOIN rings r
                  ON r.id = s.ring_id

                ORDER BY s.opened_at DESC
                LIMIT %s
                """,
                (
                    int(TELEGRAM_WEBAPP_ACTIVE_SECONDS),
                    limit,
                ),
            )

            return [
                dict(row)
                for row in cur.fetchall()
            ]


def get_webapp_session_stats():
    with get_connection(rows=True) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    COUNT(*) AS total_sessions,

                    COUNT(*) FILTER (
                        WHERE closed_at IS NULL
                          AND last_seen_at
                              >= NOW()
                                 - (%s * INTERVAL '1 second')
                    ) AS active_now,

                    COUNT(DISTINCT telegram_user_id)
                        AS unique_users,

                    COUNT(DISTINCT ring_id)
                        AS unique_rings

                FROM telegram_webapp_sessions
                """,
                (int(TELEGRAM_WEBAPP_ACTIVE_SECONDS),),
            )

            row = cur.fetchone()
            return dict(row) if row else {}



def query_measurement_history(mac, hours=24, metric=None, limit=500):
    hours = max(1, min(int(hours), 24 * 365))
    limit = max(1, min(int(limit), 5000))
    with get_connection(rows=True) as conn:
        ring = _get_ring_by_mac(conn, mac)
        if not ring:
            return None, []
        params = [ring["id"], hours]
        metric_clause = ""
        if metric:
            metric_clause = "AND metric = %s"
            params.append(metric)
        params.append(limit)
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT time, metric, value, samples, unit, status, reason, experimental, extra
                FROM ring_measurements
                WHERE ring_id = %s
                  AND time >= NOW() - (%s || ' hours')::interval
                  {metric_clause}
                ORDER BY time DESC
                LIMIT %s
                """,
                params,
            )
            rows = cur.fetchall()
        return dict(ring), [dict(r) for r in rows]