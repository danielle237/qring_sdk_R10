#!/usr/bin/env python3
import os
import re
import secrets
import argparse
from pathlib import Path

from dotenv import load_dotenv
import psycopg
from psycopg.rows import dict_row
import qrcode


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(Path(os.getenv("DANY_ENV_FILE", BASE_DIR / ".env")))

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "dany")
DB_USER = os.getenv("DB_USER", "")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
BOT_USERNAME = os.getenv("TELEGRAM_BOT_USERNAME", "").lstrip("@")


def get_conn():
    return psycopg.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        row_factory=dict_row,
        autocommit=False,
    )


def safe_name(value):
    return re.sub(
        r"[^A-Za-z0-9._-]+",
        "_",
        str(value or "ring"),
    )


def main():
    parser = argparse.ArgumentParser(
        description="Generate a secure Telegram pairing QR for one ring."
    )
    parser.add_argument("--mac", required=True)
    parser.add_argument(
        "--bot",
        default=BOT_USERNAME,
        help="Telegram bot username without @",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="PNG output filename",
    )
    args = parser.parse_args()

    bot = str(args.bot or "").lstrip("@").strip()
    if not bot:
        raise SystemExit(
            "TELEGRAM_BOT_USERNAME absent. "
            "Use --bot MyBot or set it in .env"
        )

    token = secrets.token_urlsafe(18)

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, name, mac::text AS mac
                FROM rings
                WHERE mac = %s::macaddr
                  AND active = TRUE
                """,
                (args.mac,),
            )
            ring = cur.fetchone()

            if not ring:
                raise SystemExit("Ring not found")

            # Rotate previous printed token if a new QR is generated.
            cur.execute(
                """
                UPDATE ring_pairing_tokens
                SET active = FALSE
                WHERE ring_id = %s
                  AND active = TRUE
                """,
                (ring["id"],),
            )

            cur.execute(
                """
                INSERT INTO ring_pairing_tokens (
                    ring_id,
                    token,
                    active
                )
                VALUES (%s, %s, TRUE)
                RETURNING id
                """,
                (
                    ring["id"],
                    token,
                ),
            )

        conn.commit()

    deep_link = (
        f"https://t.me/{bot}"
        f"?start=pair_{token}"
    )

    output = Path(
        args.output
        or f"pairing_{safe_name(ring['name'])}.png"
    )

    img = qrcode.make(deep_link)
    img.save(output)

    print("Ring       :", ring["name"])
    print("MAC        :", ring["mac"])
    print("Deep link  :", deep_link)
    print("QR PNG     :", output.resolve())
    print()
    print(
        "The QR creates a pending pairing request. "
        "It does NOT auto-assign the ring."
    )


if __name__ == "__main__":
    main()
