-- ============================================================
-- DANY / COLMI - QR PAIRING
-- PostgreSQL migration
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS ring_pairing_tokens (
    id BIGSERIAL PRIMARY KEY,
    ring_id BIGINT NOT NULL REFERENCES rings(id) ON DELETE CASCADE,
    token VARCHAR(64) NOT NULL UNIQUE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    expires_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Une seule étiquette QR active par bague.
CREATE UNIQUE INDEX IF NOT EXISTS uq_ring_pairing_token_active
ON ring_pairing_tokens(ring_id)
WHERE active = TRUE;


CREATE TABLE IF NOT EXISTS ring_pairing_requests (
    id BIGSERIAL PRIMARY KEY,
    ring_id BIGINT NOT NULL REFERENCES rings(id) ON DELETE CASCADE,
    telegram_user_id BIGINT NOT NULL
        REFERENCES t_user_app_telegram(id) ON DELETE CASCADE,
    pairing_token_id BIGINT NULL
        REFERENCES ring_pairing_tokens(id) ON DELETE SET NULL,

    status VARCHAR(16) NOT NULL DEFAULT 'pending'
        CHECK (
            status IN (
                'pending',
                'approved',
                'rejected',
                'cancelled'
            )
        ),

    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    decided_at TIMESTAMPTZ NULL,
    decided_by_telegram_id BIGINT NULL,
    decided_by_source VARCHAR(16) NULL,
    decided_by_label VARCHAR(128) NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_ring_pairing_request_pending
ON ring_pairing_requests(ring_id, telegram_user_id)
WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS ix_ring_pairing_requests_status
ON ring_pairing_requests(status, requested_at DESC);



-- Compatible avec une installation qui a déjà exécuté une version
-- précédente de qr_pairing.sql.
ALTER TABLE ring_pairing_requests
    ADD COLUMN IF NOT EXISTS decided_by_source VARCHAR(16) NULL;

ALTER TABLE ring_pairing_requests
    ADD COLUMN IF NOT EXISTS decided_by_label VARCHAR(128) NULL;

COMMIT;
