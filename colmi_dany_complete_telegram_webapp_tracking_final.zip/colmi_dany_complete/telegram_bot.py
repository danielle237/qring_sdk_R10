import os
import json
import time
import asyncio
import logging
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path

from dotenv import load_dotenv

# ============================================================
# DANY TELEGRAM BOT V2 - LIVE / HISTORY / QR PAIRING
# Le bot lit DB + MQTT depuis le MEME .env que Flask.
# Place ce fichier dans le même dossier que app.py/.env.
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = Path(os.getenv("DANY_ENV_FILE", BASE_DIR / ".env"))
load_dotenv(ENV_FILE)

import psycopg
from psycopg.rows import dict_row
import paho.mqtt.client as mqtt

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.constants import ChatType
from telegram.error import BadRequest, Forbidden, RetryAfter
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

# ---------------- Configuration .env ----------------

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_PRIVATE_ONLY = os.getenv("TELEGRAM_PRIVATE_ONLY", "1").lower() not in (
    "0", "false", "no", "off"
)
LIVE_REFRESH_SECONDS = max(
    1.0, float(os.getenv("TELEGRAM_LIVE_REFRESH_SECONDS", "2"))
)

RING_OVERVIEW_REFRESH_SECONDS = max(
    1.0,
    float(
        os.getenv(
            "TELEGRAM_RING_OVERVIEW_REFRESH_SECONDS",
            "2",
        )
    ),
)

LIVE_SESSION_MINUTES = max(
    1, int(os.getenv("TELEGRAM_LIVE_SESSION_MINUTES", "30"))
)

LIVE_WARNING_MINUTES = max(
    1, int(os.getenv("TELEGRAM_LIVE_WARNING_MINUTES", "5"))
)

# Si plusieurs mesures physiologiques échouent avec
# reason=measurement_failed dans la même fenêtre, la bague est considérée
# ONLINE mais NON PORTÉE.
WEAR_FAILURE_THRESHOLD = max(
    2, int(os.getenv("TELEGRAM_WEAR_FAILURE_THRESHOLD", "2"))
)

WEAR_FAILURE_WINDOW_SECONDS = max(
    30, int(os.getenv("TELEGRAM_WEAR_FAILURE_WINDOW_SECONDS", "180"))
)

PHYSIO_METRICS = (
    "heart_rate",
    "spo2",
    "fatigue",
    "health_check",
)

def _parse_int_set(raw):
    out = set()
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.add(int(part))
        except ValueError:
            pass
    return out


# Administrateurs globaux du bot, séparés par des virgules.
# Exemple : TELEGRAM_ADMIN_IDS=123456789,987654321
TELEGRAM_ADMIN_IDS = _parse_int_set(
    os.getenv("TELEGRAM_ADMIN_IDS", "")
)

# Permissions accordées lorsqu'un administrateur accepte une demande QR.
PAIRING_DEFAULT_ALERTS = os.getenv(
    "PAIRING_DEFAULT_ALERTS", "0"
).strip().lower() in ("1", "true", "yes", "on")

# URL HTTPS publique du Flask DANY.
# Exemple : https://dany.embedded-systems.biz
TELEGRAM_WEBAPP_BASE_URL = os.getenv(
    "TELEGRAM_WEBAPP_BASE_URL",
    "",
).strip().rstrip("/")

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "smart_ring")
DB_USER = os.getenv("DB_USER", "")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_CONNECT_TIMEOUT = int(os.getenv("DB_CONNECT_TIMEOUT", "5"))

MQTT_HOST = os.getenv("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("MQTT_USER", "")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "eis/colmi/#")

logging.basicConfig(
    level=os.getenv("TELEGRAM_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("dany.telegram")

# ---------------- Etat process ----------------

telegram_app = None
telegram_loop = None

# ring_id -> état courant construit avec PostgreSQL + MQTT
live_state = {}
live_state_lock = threading.RLock()

# (chat_id, ring_id) -> session live
live_sessions = {}
live_sessions_lock = threading.RLock()

# (chat_id, ring_id) -> écran "Ring" avant d'entrer en LIVE.
# Cet écran est mis à jour automatiquement par les messages MQTT.
ring_overview_sessions = {}
ring_overview_sessions_lock = threading.RLock()

# Messages Telegram "HORS PORTÉE" envoyés par le bot.
# Clé : (ring_id, chat_id)
# Valeur : message_id Telegram
#
# Quand la bague redevient ONLINE, ces messages sont supprimés du chat
# afin de ne pas laisser un warning obsolète sous l'écran courant.
outside_alert_messages = {}
outside_alert_messages_lock = threading.RLock()

# Liste des rings / mqtt_base_topic
rings_cache = []
rings_cache_lock = threading.RLock()
rings_cache_at = 0.0


# ============================================================
# PostgreSQL
# ============================================================

def get_connection():
    """Connexion entièrement issue du .env."""
    return psycopg.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        connect_timeout=DB_CONNECT_TIMEOUT,
        row_factory=dict_row,
        autocommit=True,
    )


def db_healthcheck():
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database() AS db, current_user AS usr")
            return cur.fetchone()


def register_user_from_start(tg_user):
    """Crée/actualise l'utilisateur via la procédure PostgreSQL add_user_2()."""
    now = datetime.now(timezone.utc)
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                CALL add_user_2(
                    %s, %s, %s, %s, %s, %s, %s, NULL
                )
                """,
                (
                    int(tg_user.id),
                    tg_user.first_name,
                    tg_user.last_name,
                    now,
                    now,
                    tg_user.username,
                    tg_user.language_code,
                ),
            )
            try:
                return cur.fetchone()
            except Exception:
                return None


def get_accessible_rings(telegram_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    u.id AS telegram_user_id,
                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,
                    r.mqtt_base_topic,
                    a.can_view,
                    a.can_view_history,
                    a.can_live,
                    a.can_receive_alerts,
                    a.can_admin
                FROM t_user_app_telegram u
                JOIN ring_telegram_access a
                    ON a.telegram_user_id = u.id
                JOIN rings r
                    ON r.id = a.ring_id
                WHERE u.id_telegram = %s
                  AND u.active = TRUE
                  AND a.active = TRUE
                  AND a.can_view = TRUE
                  AND r.active = TRUE
                ORDER BY r.name, r.id
                """,
                (int(telegram_id),),
            )
            return list(cur.fetchall())


def get_ring_access(telegram_id, ring_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    u.id AS telegram_user_id,
                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,
                    r.mqtt_base_topic,
                    a.can_view,
                    a.can_view_history,
                    a.can_live,
                    a.can_receive_alerts,
                    a.can_admin
                FROM t_user_app_telegram u
                JOIN ring_telegram_access a
                    ON a.telegram_user_id = u.id
                JOIN rings r
                    ON r.id = a.ring_id
                WHERE u.id_telegram = %s
                  AND r.id = %s
                  AND u.active = TRUE
                  AND a.active = TRUE
                  AND r.active = TRUE
                """,
                (int(telegram_id), int(ring_id)),
            )
            return cur.fetchone()


def get_current_state(ring_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    r.id AS ring_id,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model,
                    r.mqtt_base_topic,
                    s.online,
                    s.battery,
                    s.charging,
                    s.heart_rate,
                    s.spo2,
                    s.hrv,
                    s.fatigue,
                    s.health_check,
                    s.temperature,
                    s.steps,
                    s.distance_m,
                    s.calories_raw,
                    s.rssi,
                    s.wear_status,
                    s.ble_status,
                    s.last_measurement_at,
                    s.updated_at
                FROM rings r
                LEFT JOIN ring_current_state s
                    ON s.ring_id = r.id
                WHERE r.id = %s
                """,
                (int(ring_id),),
            )
            return cur.fetchone()



def get_latest_battery_detail(ring_id):
    """
    Dernière mesure batterie historisée.
    Permet d'afficher le vrai timestamp de la batterie dans Telegram,
    y compris après un redémarrage du bot.
    """
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    value,
                    unit,
                    status,
                    reason,
                    time,
                    extra
                FROM ring_measurements
                WHERE ring_id = %s
                  AND metric = 'battery'
                ORDER BY time DESC
                LIMIT 1
                """,
                (int(ring_id),),
            )

            row = cur.fetchone()
            return dict(row) if row else None


def get_latest_sensor_details(ring_id):
    """Dernier résultat complet par capteur, avec samples conservés en DB."""
    metrics = ("heart_rate", "spo2", "hrv", "fatigue", "health_check", "temperature")
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT DISTINCT ON (metric)
                    metric, value, samples, unit, status, reason, time
                FROM ring_measurements
                WHERE ring_id = %s
                  AND metric = ANY(%s)
                ORDER BY metric, time DESC
                """,
                (int(ring_id), list(metrics)),
            )
            return [dict(r) for r in cur.fetchall()]




def seed_live_state_from_db(ring_id):
    """
    Amorce / resynchronise le LIVE depuis PostgreSQL.

    Ordre d'interprétation :
      1) device_not_found / device_out_of_range -> HORS PORTEE
      2) charging=True -> ONLINE NON PORTE
      3) >= N measurement_failed récents -> ONLINE NON PORTE
      4) au moins une mesure physiologique OK récente -> ONLINE PORTE
    """
    current = get_current_state(ring_id) or {}
    details = get_latest_sensor_details(ring_id)
    battery_detail = get_latest_battery_detail(ring_id)

    now_dt = datetime.now(timezone.utc)

    with live_state_lock:
        state = live_state.setdefault(
            int(ring_id),
            {},
        )

        for key, value in dict(current).items():
            if value is not None:
                state[key] = value

        # Timestamp exact de la dernière batterie, lu dans ring_measurements.
        if battery_detail:
            state["battery_timestamp"] = battery_detail.get("time")

            if battery_detail.get("value") is not None:
                state["battery"] = battery_detail.get("value")

            extra = battery_detail.get("extra")
            if isinstance(extra, dict) and extra.get("charging") is not None:
                state["charging"] = bool(extra.get("charging"))

        recent_failures = []
        recent_successes = []

        for row in details:
            metric = row["metric"]
            samples = row.get("samples")
            row_time = row.get("time")

            if samples:
                state[f"{metric}_samples"] = list(samples)

            state[f"{metric}_unit"] = row.get("unit")
            state[f"{metric}_status"] = row.get("status") or "ok"
            state[f"{metric}_reason"] = row.get("reason")
            state[f"{metric}_timestamp"] = row_time

            if metric in PHYSIO_METRICS and row_time:
                try:
                    if row_time.tzinfo is None:
                        row_time = row_time.replace(tzinfo=timezone.utc)

                    age = (
                        now_dt
                        - row_time.astimezone(timezone.utc)
                    ).total_seconds()

                    if age <= WEAR_FAILURE_WINDOW_SECONDS:
                        status = str(
                            row.get("status") or ""
                        ).strip().lower()

                        reason = str(
                            row.get("reason") or ""
                        ).strip().lower()

                        if reason == "measurement_failed":
                            recent_failures.append(metric)

                        elif status == "ok":
                            recent_successes.append(metric)

                except Exception:
                    pass

        ble_status = str(
            state.get("ble_status") or ""
        ).strip().lower()

        outside = (
            state.get("online") is False
            or ble_status in (
                "device_not_found",
                "device_out_of_range",
                "outside",
                "hors_portee",
            )
        )

        state["outside"] = outside

        if outside:
            reason = (
                ble_status
                or "device_out_of_range"
            )

            ts = (
                state.get("last_measurement_at")
                or state.get("updated_at")
            )

            for metric in PHYSIO_METRICS:
                state[f"{metric}_status"] = "hors_portee"
                state[f"{metric}_reason"] = reason
                state[f"{metric}_timestamp"] = ts
                state[f"{metric}_samples"] = None

            return dict(state)

        # ONLINE : inférence du port.
        if state.get("charging") is True:
            state["wear_inferred"] = "not_worn"
            state["wear_inferred_reason"] = "charging"

        elif len(set(recent_failures)) >= WEAR_FAILURE_THRESHOLD:
            state["wear_inferred"] = "not_worn"
            state["wear_inferred_reason"] = (
                "measurement_failed:"
                + ",".join(sorted(set(recent_failures)))
            )

        elif recent_successes:
            state["wear_inferred"] = "worn"
            state["wear_inferred_reason"] = (
                "measurement_ok:"
                + ",".join(sorted(set(recent_successes)))
            )

        return dict(state)

def get_history_summary(ring_id, hours):
    hours = max(1, min(int(hours), 24 * 365))
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    metric,
                    COUNT(*) FILTER (
                        WHERE status='ok' AND value IS NOT NULL
                    ) AS samples_count,
                    AVG(value) FILTER (
                        WHERE status='ok' AND value IS NOT NULL
                    ) AS avg_value,
                    MIN(value) FILTER (
                        WHERE status='ok' AND value IS NOT NULL
                    ) AS min_value,
                    MAX(value) FILTER (
                        WHERE status='ok' AND value IS NOT NULL
                    ) AS max_value,
                    (
                        ARRAY_AGG(value ORDER BY time DESC)
                        FILTER (WHERE status='ok' AND value IS NOT NULL)
                    )[1] AS last_value,
                    MAX(time) AS last_time,
                    COUNT(*) FILTER (
                        WHERE status <> 'ok'
                    ) AS error_count
                FROM ring_measurements
                WHERE ring_id = %s
                  AND time >= NOW() - (%s || ' hours')::interval
                GROUP BY metric
                ORDER BY metric
                """,
                (int(ring_id), hours),
            )
            return list(cur.fetchall())



def get_metric_history(ring_id, metric, hours, limit=100):
    allowed = {
        "heart_rate",
        "spo2",
        "fatigue",
        "health_check",
    }

    if metric not in allowed:
        raise ValueError("Métrique historique non autorisée")

    hours = max(1, min(int(hours), 24 * 365))
    limit = max(1, min(int(limit), 200))

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    time,
                    metric,
                    value,
                    samples,
                    unit,
                    status,
                    reason
                FROM ring_measurements
                WHERE ring_id = %s
                  AND metric = %s
                  AND time >= NOW() - (%s || ' hours')::interval
                ORDER BY time DESC
                LIMIT %s
                """,
                (
                    int(ring_id),
                    metric,
                    hours,
                    limit,
                ),
            )
            return [dict(r) for r in cur.fetchall()]


def get_alert_chat_ids(ring_id):
    """
    Destinataires d'une alerte hors portée :
    - TELEGRAM_ADMIN_IDS
    - utilisateurs affectés avec can_receive_alerts=TRUE
    """
    result = set(TELEGRAM_ADMIN_IDS)

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT DISTINCT u.id_telegram
                FROM ring_telegram_access a
                JOIN t_user_app_telegram u
                  ON u.id = a.telegram_user_id
                WHERE a.ring_id = %s
                  AND a.active = TRUE
                  AND a.can_receive_alerts = TRUE
                  AND u.active = TRUE
                  AND u.id_telegram IS NOT NULL
                """,
                (int(ring_id),),
            )

            for row in cur.fetchall():
                try:
                    result.add(int(row["id_telegram"]))
                except Exception:
                    pass

    return sorted(result)


def get_pairing_request(request_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    pr.id AS request_id,
                    pr.status,
                    pr.requested_at,
                    pr.ring_id,
                    pr.telegram_user_id,
                    u.id_telegram,
                    u.firstname,
                    u.lastname,
                    u.pseudo,
                    r.name AS ring_name,
                    r.mac::text AS mac,
                    r.model
                FROM ring_pairing_requests pr
                JOIN t_user_app_telegram u
                  ON u.id = pr.telegram_user_id
                JOIN rings r
                  ON r.id = pr.ring_id
                WHERE pr.id = %s
                """,
                (int(request_id),),
            )
            row = cur.fetchone()
            return dict(row) if row else None


def create_pairing_request(telegram_id, token):
    """
    Le QR ne donne PAS automatiquement accès.
    Il crée une demande PENDING que l'admin accepte ou refuse.
    """
    token = str(token or "").strip()

    if not token:
        return {"status": "invalid"}

    with get_connection() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        u.id AS telegram_user_id,
                        pt.id AS pairing_token_id,
                        r.id AS ring_id,
                        r.name AS ring_name,
                        r.mac::text AS mac,
                        r.model
                    FROM t_user_app_telegram u
                    JOIN ring_pairing_tokens pt
                      ON pt.token = %s
                    JOIN rings r
                      ON r.id = pt.ring_id
                    WHERE u.id_telegram = %s
                      AND u.active = TRUE
                      AND pt.active = TRUE
                      AND (
                          pt.expires_at IS NULL
                          OR pt.expires_at > NOW()
                      )
                      AND r.active = TRUE
                    LIMIT 1
                    """,
                    (
                        token,
                        int(telegram_id),
                    ),
                )

                row = cur.fetchone()

                if not row:
                    return {"status": "invalid"}

                row = dict(row)

                cur.execute(
                    """
                    SELECT id
                    FROM ring_telegram_access
                    WHERE ring_id = %s
                      AND telegram_user_id = %s
                      AND active = TRUE
                    LIMIT 1
                    """,
                    (
                        row["ring_id"],
                        row["telegram_user_id"],
                    ),
                )

                if cur.fetchone():
                    row["status"] = "already_assigned"
                    return row

                cur.execute(
                    """
                    SELECT id
                    FROM ring_pairing_requests
                    WHERE ring_id = %s
                      AND telegram_user_id = %s
                      AND status = 'pending'
                    ORDER BY requested_at DESC
                    LIMIT 1
                    """,
                    (
                        row["ring_id"],
                        row["telegram_user_id"],
                    ),
                )

                pending = cur.fetchone()

                if pending:
                    row["request_id"] = pending["id"]
                    row["status"] = "already_pending"
                    return row

                cur.execute(
                    """
                    INSERT INTO ring_pairing_requests (
                        ring_id,
                        telegram_user_id,
                        pairing_token_id,
                        status,
                        requested_at
                    )
                    VALUES (%s, %s, %s, 'pending', NOW())
                    RETURNING id
                    """,
                    (
                        row["ring_id"],
                        row["telegram_user_id"],
                        row["pairing_token_id"],
                    ),
                )

                created = cur.fetchone()
                row["request_id"] = created["id"]
                row["status"] = "pending"
                return row


def approve_pairing_request(request_id, admin_telegram_id):
    """
    Accepte une demande QR et crée/réactive ring_telegram_access.
    """
    with get_connection() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        pr.id AS request_id,
                        pr.status,
                        pr.ring_id,
                        pr.telegram_user_id,
                        u.id_telegram,
                        u.firstname,
                        u.lastname,
                        u.pseudo,
                        r.name AS ring_name,
                        r.mac::text AS mac,
                        r.model
                    FROM ring_pairing_requests pr
                    JOIN t_user_app_telegram u
                      ON u.id = pr.telegram_user_id
                    JOIN rings r
                      ON r.id = pr.ring_id
                    WHERE pr.id = %s
                    FOR UPDATE
                    """,
                    (int(request_id),),
                )

                row = cur.fetchone()

                if not row:
                    return None

                row = dict(row)

                if row["status"] != "pending":
                    row["result"] = "already_decided"
                    return row

                cur.execute(
                    """
                    INSERT INTO ring_telegram_access (
                        ring_id,
                        telegram_user_id,
                        can_view,
                        can_view_history,
                        can_live,
                        can_receive_alerts,
                        can_admin,
                        active
                    )
                    VALUES (%s, %s, TRUE, TRUE, TRUE, %s, FALSE, TRUE)
                    ON CONFLICT (ring_id, telegram_user_id)
                    DO UPDATE SET
                        can_view = TRUE,
                        can_view_history = TRUE,
                        can_live = TRUE,
                        can_receive_alerts = EXCLUDED.can_receive_alerts,
                        can_admin = FALSE,
                        active = TRUE,
                        updated_at = NOW()
                    """,
                    (
                        row["ring_id"],
                        row["telegram_user_id"],
                        bool(PAIRING_DEFAULT_ALERTS),
                    ),
                )

                cur.execute(
                    """
                    UPDATE ring_pairing_requests
                    SET
                        status = 'approved',
                        decided_at = NOW(),
                        decided_by_telegram_id = %s
                    WHERE id = %s
                    """,
                    (
                        int(admin_telegram_id),
                        int(request_id),
                    ),
                )

                row["result"] = "approved"
                return row


def reject_pairing_request(request_id, admin_telegram_id):
    with get_connection() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        pr.id AS request_id,
                        pr.status,
                        pr.ring_id,
                        pr.telegram_user_id,
                        u.id_telegram,
                        u.firstname,
                        u.lastname,
                        u.pseudo,
                        r.name AS ring_name,
                        r.mac::text AS mac
                    FROM ring_pairing_requests pr
                    JOIN t_user_app_telegram u
                      ON u.id = pr.telegram_user_id
                    JOIN rings r
                      ON r.id = pr.ring_id
                    WHERE pr.id = %s
                    FOR UPDATE
                    """,
                    (int(request_id),),
                )

                row = cur.fetchone()

                if not row:
                    return None

                row = dict(row)

                if row["status"] != "pending":
                    row["result"] = "already_decided"
                    return row

                cur.execute(
                    """
                    UPDATE ring_pairing_requests
                    SET
                        status = 'rejected',
                        decided_at = NOW(),
                        decided_by_telegram_id = %s
                    WHERE id = %s
                    """,
                    (
                        int(admin_telegram_id),
                        int(request_id),
                    ),
                )

                row["result"] = "rejected"
                return row

def db_start_live_session(telegram_user_id, ring_id, chat_id, message_id):
    expires_at = datetime.now(timezone.utc) + timedelta(
        minutes=LIVE_SESSION_MINUTES
    )
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO telegram_live_sessions (
                    telegram_user_id,
                    ring_id,
                    chat_id,
                    telegram_message_id,
                    active,
                    started_at,
                    last_update_at,
                    expires_at
                )
                VALUES (%s,%s,%s,%s,TRUE,NOW(),NOW(),%s)
                ON CONFLICT (telegram_user_id, ring_id, chat_id)
                DO UPDATE SET
                    telegram_message_id=EXCLUDED.telegram_message_id,
                    active=TRUE,
                    started_at=NOW(),
                    last_update_at=NOW(),
                    expires_at=EXCLUDED.expires_at
                """,
                (
                    int(telegram_user_id),
                    int(ring_id),
                    int(chat_id),
                    int(message_id),
                    expires_at,
                ),
            )


def db_stop_live_session(telegram_user_id, ring_id, chat_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE telegram_live_sessions
                SET active=FALSE, last_update_at=NOW()
                WHERE telegram_user_id=%s
                  AND ring_id=%s
                  AND chat_id=%s
                """,
                (
                    int(telegram_user_id),
                    int(ring_id),
                    int(chat_id),
                ),
            )



async def stop_live_sessions_for_chat(
    chat_id,
    *,
    ring_id=None,
    bot=None,
):
    """
    Arrête proprement les sessions LIVE actives d'un chat.

    Utilisé quand l'utilisateur quitte volontairement le LIVE :
      - Mes rings
      - Historique
      - retour écran Ring
      - /start
      - /rings

    IMPORTANT :
    une perte BLE / HORS PORTEE n'appelle jamais cette fonction.
    Le LIVE continue donc normalement pendant une perte de portée.
    """
    chat_id = int(chat_id)
    wanted_ring_id = (
        int(ring_id)
        if ring_id is not None
        else None
    )

    stopped = []

    with live_sessions_lock:
        for key, session in list(
            live_sessions.items()
        ):
            session_chat_id = int(
                session.get("chat_id")
            )
            session_ring_id = int(
                session.get("ring_id")
            )

            if session_chat_id != chat_id:
                continue

            if (
                wanted_ring_id is not None
                and session_ring_id
                != wanted_ring_id
            ):
                continue

            stopped.append(
                dict(session)
            )

            live_sessions.pop(
                key,
                None,
            )

    for session in stopped:
        try:
            db_stop_live_session(
                session["telegram_user_id"],
                session["ring_id"],
                session["chat_id"],
            )
        except Exception:
            log.exception(
                "Erreur arrêt LIVE DB chat=%s ring=%s",
                session.get("chat_id"),
                session.get("ring_id"),
            )

        # Si l'avertissement "< 5 min" a déjà été envoyé,
        # il devient lui aussi obsolète quand l'utilisateur quitte LIVE.
        warning_message_id = session.get(
            "warning_message_id"
        )

        if (
            bot is not None
            and warning_message_id
        ):
            try:
                await bot.delete_message(
                    chat_id=session["chat_id"],
                    message_id=warning_message_id,
                )
            except Exception:
                # Un message déjà supprimé n'est pas une erreur fonctionnelle.
                pass

    return len(stopped)


def db_extend_live_session(
    telegram_user_id,
    ring_id,
    chat_id,
    minutes,
):
    """
    Prolonge la session LIVE en DB sans remettre started_at à zéro.
    """
    minutes = max(1, int(minutes))

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE telegram_live_sessions
                SET
                    active=TRUE,
                    last_update_at=NOW(),
                    expires_at=NOW() + (%s || ' minutes')::interval
                WHERE telegram_user_id=%s
                  AND ring_id=%s
                  AND chat_id=%s
                """,
                (
                    minutes,
                    int(telegram_user_id),
                    int(ring_id),
                    int(chat_id),
                ),
            )


# ============================================================
# MQTT
# ============================================================

def refresh_rings_cache(force=False):
    global rings_cache_at
    now = time.monotonic()

    with rings_cache_lock:
        if not force and rings_cache and now - rings_cache_at < 60:
            return list(rings_cache)

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    id AS ring_id,
                    name AS ring_name,
                    mac::text AS mac,
                    mqtt_base_topic
                FROM rings
                WHERE active=TRUE
                  AND mqtt_base_topic IS NOT NULL
                """
            )
            rows = [dict(r) for r in cur.fetchall()]

    rows.sort(
        key=lambda r: len(r.get("mqtt_base_topic") or ""),
        reverse=True,
    )

    with rings_cache_lock:
        rings_cache[:] = rows
        rings_cache_at = now

    return rows


def ring_from_topic(topic):
    for ring in refresh_rings_cache():
        base = (ring.get("mqtt_base_topic") or "").rstrip("/")
        if base and (topic == base or topic.startswith(base + "/")):
            return ring, topic[len(base):].lstrip("/")
    return None, None


def normalize_metric(metric_path):
    metric = (metric_path or "").split("/")[-1].strip().lower()
    return {
        "heart-rate": "heart_rate",
        "heart_rate": "heart_rate",
        "spo2": "spo2",
        "hrv": "hrv",
        "fatigue": "fatigue",
        "health-check": "health_check",
        "health_check": "health_check",
        "battery": "battery",
        "steps": "steps",
        "rssi": "rssi",
        "temperature": "temperature",
        "outside": "outside",
        "wear": "wear_status",
        "wear-status": "wear_status",
        "wear_status": "wear_status",
        "wearing": "wear_status",
    }.get(metric, metric)


def extract_samples(payload):
    """Récupère la liste de samples exactement comme le dashboard DANY."""
    candidates = []

    raw = payload.get("value")
    if isinstance(raw, dict):
        candidates.extend([raw.get("samples"), raw.get("value")])

    candidates.extend([payload.get("samples"), raw])

    for candidate in candidates:
        if isinstance(candidate, (list, tuple)):
            out = []
            for item in candidate:
                if isinstance(item, (int, float)):
                    f = float(item)
                    out.append(int(f) if f.is_integer() else f)
            if out:
                return out

    return None


def numeric_value(payload):
    """Valeur simple pour batterie/pas/RSSI ou repli technique."""
    raw = payload.get("value")

    if isinstance(raw, (int, float)):
        return float(raw)

    if isinstance(raw, dict):
        for key in ("last", "value", "value_median", "median"):
            v = raw.get(key)
            if isinstance(v, (int, float)):
                return float(v)

    for key in ("last", "value2", "value_median", "median"):
        v = payload.get(key)
        if isinstance(v, (int, float)):
            return float(v)

    return None




def _recent_measurement_failed_count(state, now_epoch):
    count = 0

    for metric in PHYSIO_METRICS:
        failed_at = state.get(
            f"{metric}_measurement_failed_epoch"
        )

        if not isinstance(
            failed_at,
            (int, float),
        ):
            continue

        if (
            now_epoch - float(failed_at)
            <= WEAR_FAILURE_WINDOW_SECONDS
        ):
            count += 1

    return count


def _set_inferred_wear(state, value, reason, timestamp):
    state["wear_inferred"] = value
    state["wear_inferred_reason"] = reason
    state["wear_inferred_at"] = timestamp


def update_live_state(ring_id, metric, payload):
    """
    Etat unique Telegram.

    Priorité :
      HORS PORTEE
      > ONLINE NON PORTE
      > ONLINE PORTE

    L'échec measurement_failed n'est pas interprété comme une perte BLE.
    Si plusieurs capteurs physiologiques échouent dans la même fenêtre,
    on considère la bague ONLINE mais NON PORTEE.
    """
    now_dt = datetime.now(timezone.utc)
    now_iso = now_dt.isoformat()
    now_epoch = now_dt.timestamp()

    with live_state_lock:
        state = live_state.setdefault(
            int(ring_id),
            {
                "ring_id": int(ring_id),
                "online": True,
                "outside": False,
            },
        )

        was_outside = bool(
            state.get("outside")
        )

        timestamp = (
            payload.get("timestamp")
            or now_iso
        )

        state["updated_at"] = timestamp

        status = str(
            payload.get("status") or ""
        ).strip().lower()

        reason = payload.get("reason")
        reason_text = str(
            reason or ""
        ).strip().lower()

        unit = payload.get("unit")

        fault_code = str(
            payload.get("fault_code")
            or payload.get("reason")
            or ""
        ).strip().lower()

        # ----------------------------------------------------
        # 1) HORS PORTEE
        # ----------------------------------------------------
        if metric == "outside" or fault_code in (
            "device_not_found",
            "device_out_of_range",
        ):
            state["online"] = False
            state["outside"] = True
            state["ble_status"] = (
                fault_code
                or "device_out_of_range"
            )
            state["outside_timestamp"] = timestamp

            for sensor in PHYSIO_METRICS:
                state[f"{sensor}_status"] = "hors_portee"
                state[f"{sensor}_reason"] = state["ble_status"]
                state[f"{sensor}_timestamp"] = timestamp
                state[f"{sensor}_samples"] = None

            return {
                "outside_transition":
                    not was_outside,
                "back_online_transition": False,
            }

        # Une donnée BLE valide prouve que la bague est de nouveau joignable.
        #
        # IMPORTANT :
        # il faut aussi effacer l'ancien ble_status=device_out_of_range.
        # Sinon presence_line() peut continuer à afficher HORS PORTEE alors
        # que Batterie / HR / SpO2 viennent réellement d'arriver.
        back_online_transition = was_outside

        state["online"] = True
        state["outside"] = False
        state["ble_status"] = "ok"
        state["outside_timestamp"] = None
        state["last_ble_seen_at"] = timestamp

        # ----------------------------------------------------
        # 2) PORT explicite
        # ----------------------------------------------------
        if metric == "wear_status":
            wear_value = (
                payload.get("wear_status")
                if payload.get("wear_status")
                is not None
                else payload.get("value")
            )

            if wear_value is not None:
                wear_text = str(
                    wear_value
                ).strip().lower()

                state["wear_status"] = wear_text

                if _is_not_worn(wear_text):
                    _set_inferred_wear(
                        state,
                        "not_worn",
                        "wear_status",
                        timestamp,
                    )
                else:
                    _set_inferred_wear(
                        state,
                        "worn",
                        "wear_status",
                        timestamp,
                    )

            return {
                "outside_transition": False,
                "back_online_transition": back_online_transition,
            }

        if "wear_status" in payload:
            state["wear_status"] = str(
                payload.get("wear_status")
            ).strip().lower()

        # ----------------------------------------------------
        # 3) CHARGE
        # ----------------------------------------------------
        if metric == "battery":
            value = numeric_value(payload)

            if value is not None:
                state["battery"] = value

            # Timestamp de CETTE mesure batterie.
            state["battery_timestamp"] = timestamp

            if "charging" in payload:
                charging = bool(
                    payload.get("charging")
                )
                state["charging"] = charging

                if charging:
                    _set_inferred_wear(
                        state,
                        "not_worn",
                        "charging",
                        timestamp,
                    )

            return {
                "outside_transition": False,
                "back_online_transition": back_online_transition,
            }

        # ----------------------------------------------------
        # Normalisation état mesure
        # ----------------------------------------------------
        if (
            status in (
                "en_cours",
                "encours",
                "in_progress",
                "progress",
                "measuring",
            )
            or reason_text
            == "measurement_started"
        ):
            status = "en_cours"

        sampled_metric = metric in (
            "heart_rate",
            "spo2",
            "hrv",
            "fatigue",
            "health_check",
            "temperature",
        )

        if sampled_metric:
            state[f"{metric}_status"] = (
                status or "ok"
            )
            state[f"{metric}_reason"] = reason
            state[f"{metric}_timestamp"] = timestamp

            if unit is not None:
                state[f"{metric}_unit"] = unit

            if status == "en_cours":
                state[f"{metric}_samples"] = None

                return {
                    "outside_transition": False,
                }

            samples = extract_samples(payload)
            value = numeric_value(payload)

            if samples is not None:
                state[f"{metric}_samples"] = samples

            if value is not None:
                state[metric] = value

            # ------------------------------------------------
            # measurement_failed : la bague répond,
            # donc ce n'est PAS "non connecté".
            # ------------------------------------------------
            if (
                metric in PHYSIO_METRICS
                and reason_text == "measurement_failed"
            ):
                state[
                    f"{metric}_measurement_failed_epoch"
                ] = now_epoch

                failed_count = (
                    _recent_measurement_failed_count(
                        state,
                        now_epoch,
                    )
                )

                if (
                    failed_count
                    >= WEAR_FAILURE_THRESHOLD
                ):
                    _set_inferred_wear(
                        state,
                        "not_worn",
                        (
                            f"{failed_count}_"
                            "measurement_failed"
                        ),
                        timestamp,
                    )

                return {
                    "outside_transition": False,
                }

            # ------------------------------------------------
            # Une vraie mesure physiologique OK prouve
            # que la bague est portée.
            # ------------------------------------------------
            if (
                metric in PHYSIO_METRICS
                and status == "ok"
                and (
                    samples
                    or value is not None
                )
            ):
                state[
                    f"{metric}_measurement_failed_epoch"
                ] = None

                _set_inferred_wear(
                    state,
                    "worn",
                    f"{metric}_ok",
                    timestamp,
                )

                state[
                    "last_measurement_at"
                ] = timestamp

            elif status == "ok":
                state[
                    "last_measurement_at"
                ] = timestamp

            return {
                "outside_transition": False,
                "back_online_transition": back_online_transition,
            }

        # ----------------------------------------------------
        # Valeurs simples
        # ----------------------------------------------------
        value = numeric_value(payload)

        if metric == "rssi" and value is not None:
            state["rssi"] = value

        elif metric == "steps":
            if isinstance(
                payload.get("steps"),
                (int, float),
            ):
                state["steps"] = float(
                    payload["steps"]
                )

            elif value is not None:
                state["steps"] = value

            if isinstance(
                payload.get("distance_m"),
                (int, float),
            ):
                state["distance_m"] = float(
                    payload["distance_m"]
                )

            if isinstance(
                payload.get("calories_raw"),
                (int, float),
            ):
                state["calories_raw"] = float(
                    payload["calories_raw"]
                )

        return {
            "outside_transition": False,
            "back_online_transition": back_online_transition,
        }

def mqtt_on_connect(client, userdata, flags, reason_code, properties=None):
    log.info("MQTT connecté : %s", reason_code)
    refresh_rings_cache(force=True)
    client.subscribe(MQTT_TOPIC)
    log.info("MQTT abonnement : %s", MQTT_TOPIC)



def mqtt_on_message(client, userdata, msg):
    try:
        ring, metric_path = ring_from_topic(msg.topic)

        if not ring:
            return

        payload = json.loads(
            msg.payload.decode(
                "utf-8",
                errors="replace",
            )
        )

        metric = normalize_metric(metric_path)

        transition = update_live_state(
            ring["ring_id"],
            metric,
            payload,
        ) or {}

        raw_status = str(
            payload.get("status") or ""
        ).strip().lower()

        raw_reason = str(
            payload.get("reason") or ""
        ).strip().lower()

        is_measurement_transition = (
            raw_status in (
                "en_cours",
                "encours",
                "in_progress",
                "progress",
                "measuring",
                "ok",
                "non_connecte",
                "error",
                "failed",
            )
            or raw_reason == "measurement_started"
            or metric == "outside"
        )

        if is_measurement_transition:
            log.info(
                "LIVE MQTT ring=%s metric=%s status=%s reason=%s",
                ring["ring_id"],
                metric,
                raw_status,
                raw_reason,
            )

        schedule_ring_live_update(
            ring["ring_id"],
            force=is_measurement_transition,
        )

        # L'écran intermédiaire de la bague est lui aussi temps réel.
        schedule_ring_overview_update(
            ring["ring_id"],
            force=is_measurement_transition,
        )

        # Une seule notification par transition vers hors portée.
        if transition.get("outside_transition"):
            schedule_outside_alert(
                ring["ring_id"],
                ring["ring_name"],
                payload,
            )

        # Dès qu'une NOUVELLE donnée valide prouve le retour ONLINE,
        # supprimer le warning HORS PORTÉE devenu obsolète dans le chat.
        if transition.get("back_online_transition"):
            schedule_clear_outside_alerts(
                ring["ring_id"]
            )

    except Exception:
        log.exception(
            "Erreur MQTT topic=%s",
            msg.topic,
        )

def start_mqtt():
    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id="dany_telegram_bot",
    )

    if MQTT_USER:
        client.username_pw_set(
            MQTT_USER,
            MQTT_PASSWORD or None,
        )

    client.on_connect = mqtt_on_connect
    client.on_message = mqtt_on_message

    client.connect_async(
        MQTT_HOST,
        MQTT_PORT,
        keepalive=60,
    )
    client.loop_start()

    return client


# ============================================================
# Affichage
# ============================================================

def fmt_num(value):
    if value is None:
        return "—"
    try:
        f = float(value)
        if abs(f - round(f)) < 1e-9:
            return str(int(round(f)))
        return f"{f:.1f}"
    except Exception:
        return str(value)


def fmt_time(value):
    if not value:
        return "—"

    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(
                value.replace("Z", "+00:00")
            )
        except Exception:
            return value

    try:
        return value.astimezone().strftime("%d/%m %H:%M:%S")
    except Exception:
        return str(value)


def fmt_samples(samples):
    if not samples:
        return "—"
    return "[" + ", ".join(fmt_num(v) for v in samples) + "]"




def sensor_block(state, metric, label, default_unit=""):
    status = str(
        state.get(f"{metric}_status") or ""
    ).strip().lower()

    reason = state.get(
        f"{metric}_reason"
    )
    reason_text = str(
        reason or ""
    ).strip().lower()

    unit = (
        state.get(f"{metric}_unit")
        or default_unit
    )

    timestamp = state.get(
        f"{metric}_timestamp"
    )

    samples = state.get(
        f"{metric}_samples"
    )

    lines = [label]

    # HORS PORTEE : priorité absolue.
    if status in (
        "hors_portee",
        "outside",
        "device_not_found",
        "device_out_of_range",
    ):
        lines.append(
            "🟡 Hors portée / Out of range"
        )

        if timestamp:
            lines.append(
                f"Timestamp : {fmt_time(timestamp)}"
            )

        return lines

    # MESURE EN COURS.
    if status in (
        "en_cours",
        "encours",
        "in_progress",
        "progress",
        "measuring",
    ):
        lines.append(
            "🟠 En cours / In progress"
        )
        lines.append(
            "En attente de données / Waiting for data"
        )

    # MESURE OK.
    elif status == "ok":
        lines.append(
            "🟢 Terminé / Done — OK"
        )
        lines.append(
            f"Valeur : {fmt_samples(samples)}"
        )

    # measurement_failed + inférence non porté.
    elif (
        reason_text == "measurement_failed"
        and inferred_not_worn(state)
    ):
        lines.append(
            "🟠 Mesure impossible — Bague non portée / "
            "Measurement failed — Ring not worn"
        )
        lines.append(
            "Valeur : —"
        )

    # measurement_failed sans preuve suffisante de retrait.
    elif reason_text == "measurement_failed":
        lines.append(
            "🔴 Échec de mesure / Measurement failed"
        )
        lines.append(
            "Valeur : —"
        )

    elif status in (
        "non_connecte",
        "error",
        "failed",
    ):
        lines.append(
            "🔴 Erreur capteur / Sensor error"
        )

        if reason:
            lines.append(
                f"Raison / Reason : {reason}"
            )

        lines.append(
            "Valeur : —"
        )

    else:
        # HRV / température peuvent ne pas être disponibles.
        if samples:
            lines.append(
                f"Valeur : {fmt_samples(samples)}"
            )
        else:
            simple_value = state.get(metric)

            lines.append(
                f"Valeur : {fmt_num(simple_value)}"
            )

    if unit:
        lines.append(
            f"Unité : {unit}"
        )

    if timestamp:
        lines.append(
            f"Timestamp : {fmt_time(timestamp)}"
        )

    return lines

def _is_not_worn(value):
    text = str(value or "").strip().lower()

    return text in (
        "not_worn",
        "not-worn",
        "unworn",
        "removed",
        "off_wrist",
        "off-wrist",
        "non_porte",
        "non-porté",
        "non_porté",
        "false",
        "0",
        "no",
    )



def inferred_not_worn(state):
    """
    Retourne True si l'état fonctionnel conclut NON PORTE.
    """
    if state.get("charging") is True:
        return True

    inferred = str(
        state.get("wear_inferred") or ""
    ).strip().lower()

    if inferred == "not_worn":
        return True

    if _is_not_worn(
        state.get("wear_status")
    ):
        return True

    return False


def presence_line(state):
    """
    Trois états client :

      🟢 ONLINE — PORTÉ / WORN
      🟠 ONLINE — NON PORTÉ / NOT WORN
      🟡 HORS PORTÉE / OUT OF RANGE
    """
    ble_status = str(
        state.get("ble_status") or ""
    ).strip().lower()

    outside = (
        bool(state.get("outside"))
        or state.get("online") is False
        or ble_status in (
            "device_not_found",
            "device_out_of_range",
            "outside",
            "hors_portee",
        )
    )

    if outside:
        return (
            "🟡 HORS PORTÉE / "
            "OUT OF RANGE"
        )

    if inferred_not_worn(state):
        return (
            "🟠 ONLINE — NON PORTÉ / "
            "NOT WORN"
        )

    return (
        "🟢 ONLINE — PORTÉ / WORN"
    )


def charging_text(state):
    charging = state.get("charging")

    if charging is True:
        return "En charge / Charging"

    if charging is False:
        return (
            "Débranchée du chargeur / "
            "Not charging"
        )

    return "—"


def format_ring_overview(access, state):
    """
    Ecran intermédiaire visible après avoir choisi une bague.

    Cet écran reste en temps réel tant que l'utilisateur ne quitte
    pas cette vue :
      - statut ONLINE / RETIREE / OUT OF RANGE
      - batterie
      - statut de charge
      - timestamp exact de la batterie
    """
    return "\n".join(
        [
            f"💍 {access['ring_name']}",
            "",
            presence_line(state),
            f"MAC : {access['mac']}",
            "",
            f"🔋 Batterie : {fmt_num(state.get('battery'))} %",
            f"🔌 Statut : {charging_text(state)}",
            (
                "🕒 Batterie / Battery timestamp : "
                f"{fmt_time(state.get('battery_timestamp'))}"
            ),
            "",
            "Choisis une fonction / Choose a function:",
        ]
    )


def format_live(ring_name, state):
    charging_txt = charging_text(state)

    lines = [
        f"💍 {ring_name}",
        "",
        presence_line(state),
        "",
        f"🔋 Batterie : {fmt_num(state.get('battery'))} %",
        f"🔌 Statut : {charging_txt}",
        (
            "🕒 Batterie / Battery timestamp : "
            f"{fmt_time(state.get('battery_timestamp'))}"
        ),
        "",
    ]

    for metric, label, unit in (
        (
            "heart_rate",
            "❤️ Rythme Cardiaque (HR)",
            "bpm",
        ),
        (
            "spo2",
            "🫁 SpO₂",
            "%",
        ),
        (
            "fatigue",
            "⚡ Fatigue",
            "index",
        ),
        (
            "health_check",
            "🩺 Health-check",
            "index",
        ),
        (
            "hrv",
            "💓 HRV",
            "",
        ),
        (
            "temperature",
            "🌡 Température",
            "°C",
        ),
    ):
        lines.extend(
            sensor_block(
                state,
                metric,
                label,
                unit,
            )
        )
        lines.append("")

    lines.extend(
        [
            f"🚶 Pas : {fmt_num(state.get('steps'))}",
            f"📏 Distance : {fmt_num(state.get('distance_m'))} m",
            f"🔥 Calories : {fmt_num(state.get('calories_raw'))}",
            f"📶 RSSI : {fmt_num(state.get('rssi'))} dBm",
            f"💍 Port : {state.get('wear_status') or '—'}",
            f"Mise à jour : {fmt_time(state.get('updated_at'))}",
        ]
    )

    return "\n".join(lines)

def format_history(ring_name, rows, hours):
    period = {
        1: "1 heure",
        24: "24 heures",
        168: "7 jours",
        720: "30 jours",
    }.get(hours, f"{hours} h")

    lines = [
        f"📊 Historique — {ring_name}",
        f"Période : {period}",
        "",
    ]

    if not rows:
        lines.append("Aucune donnée sur cette période.")
        return "\n".join(lines)

    for row in rows:
        label = METRIC_LABEL.get(row["metric"], row["metric"])
        lines.append(label)

        if row["samples_count"]:
            lines.append(
                "  dernier={}  moy={}  min={}  max={}".format(
                    fmt_num(row["last_value"]),
                    fmt_num(row["avg_value"]),
                    fmt_num(row["min_value"]),
                    fmt_num(row["max_value"]),
                )
            )
        else:
            lines.append("  aucune valeur valide")

        if row["error_count"]:
            lines.append(f"  erreurs={row['error_count']}")

        lines.append("")

    return "\n".join(lines).strip()


# ============================================================
# LIVE Telegram
# ============================================================


def live_keyboard(ring_id):
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "🔄 Actualiser / Refresh",
                    callback_data=(
                        f"refreshlive:{ring_id}"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "⏹ Arrêter LIVE / Stop LIVE",
                    callback_data=(
                        f"stoplive:{ring_id}"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "📊 Historique / History",
                    callback_data=(
                        f"history:{ring_id}"
                    ),
                ),
                InlineKeyboardButton(
                    "⬅️ Mes rings",
                    callback_data="rings",
                ),
            ],
        ]
    )


def clear_ring_overview_sessions(chat_id, ring_id=None):
    """
    Arrête les mises à jour automatiques de l'écran Ring.

    On l'appelle dès que l'utilisateur quitte cet écran
    (LIVE, historique, liste des rings, etc.).
    """
    chat_id = int(chat_id)

    with ring_overview_sessions_lock:
        keys = [
            key
            for key in ring_overview_sessions
            if key[0] == chat_id
            and (
                ring_id is None
                or key[1] == int(ring_id)
            )
        ]

        for key in keys:
            ring_overview_sessions.pop(
                key,
                None,
            )


def register_ring_overview_session(
    *,
    chat_id,
    message_id,
    access,
):
    """
    Enregistre l'écran de détail d'une bague pour qu'il soit
    rafraîchi automatiquement depuis MQTT.
    """
    chat_id = int(chat_id)
    ring_id = int(access["ring_id"])

    # Un seul écran overview actif par chat.
    clear_ring_overview_sessions(
        chat_id
    )

    with ring_overview_sessions_lock:
        ring_overview_sessions[
            (
                chat_id,
                ring_id,
            )
        ] = {
            "chat_id": chat_id,
            "message_id": int(message_id),
            "ring_id": ring_id,
            "access": dict(access),
            "last_edit": 0.0,
        }


def schedule_ring_overview_update(
    ring_id,
    force=False,
):
    """
    Met à jour l'écran Ring lorsqu'une nouvelle donnée MQTT arrive.

    Le statut OUT OF RANGE disparaît donc immédiatement à la réception
    d'une nouvelle batterie / mesure valide, exactement comme dans LIVE.
    """
    if (
        telegram_loop is None
        or telegram_app is None
    ):
        return

    ring_id = int(ring_id)

    with ring_overview_sessions_lock:
        sessions = [
            dict(session)
            for (
                _chat_id,
                rid,
            ), session in (
                ring_overview_sessions.items()
            )
            if rid == ring_id
        ]

    now = time.monotonic()

    for session in sessions:
        key = (
            session["chat_id"],
            session["ring_id"],
        )

        with ring_overview_sessions_lock:
            original = (
                ring_overview_sessions.get(
                    key
                )
            )

            if not original:
                continue

            if (
                not force
                and now
                - original.get(
                    "last_edit",
                    0,
                )
                < RING_OVERVIEW_REFRESH_SECONDS
            ):
                continue

            original["last_edit"] = now

        asyncio.run_coroutine_threadsafe(
            refresh_ring_overview_message(
                session
            ),
            telegram_loop,
        )


async def refresh_ring_overview_message(
    session,
):
    with live_state_lock:
        state = dict(
            live_state.get(
                session["ring_id"],
                {},
            )
        )

    access = session["access"]

    try:
        await telegram_app.bot.edit_message_text(
            chat_id=session["chat_id"],
            message_id=session["message_id"],
            text=format_ring_overview(
                access,
                state,
            ),
            reply_markup=ring_keyboard(
                access
            ),
        )

    except BadRequest as exc:
        if (
            "message is not modified"
            not in str(exc).lower()
        ):
            log.warning(
                "Telegram ring overview : %s",
                exc,
            )

    except RetryAfter as exc:
        log.warning(
            "Rate limit Telegram overview : %s",
            exc.retry_after,
        )

    except Forbidden:
        clear_ring_overview_sessions(
            session["chat_id"],
            session["ring_id"],
        )

    except Exception:
        log.exception(
            "Erreur refresh ring overview"
        )


def schedule_ring_live_update(ring_id, force=False):
    """
    Rafraîchit le message LIVE.

    force=True est utilisé pour les changements d'état des mesures
    (en_cours / ok / non_connecte / erreur). Ils ne doivent jamais être
    masqués par le throttle général LIVE_REFRESH_SECONDS.
    """
    if telegram_loop is None:
        return

    with live_sessions_lock:
        sessions = [
            dict(s)
            for (_, rid), s in live_sessions.items()
            if rid == int(ring_id)
        ]

    now = time.monotonic()

    for session in sessions:
        key = (session["chat_id"], session["ring_id"])

        with live_sessions_lock:
            original = live_sessions.get(key)
            if not original:
                continue

            if (
                not force
                and now - original.get("last_edit", 0) < LIVE_REFRESH_SECONDS
            ):
                continue

            original["last_edit"] = now

        asyncio.run_coroutine_threadsafe(
            refresh_live_message(session),
            telegram_loop,
        )


async def refresh_live_message(session):
    with live_state_lock:
        state = dict(
            live_state.get(session["ring_id"], {})
        )

    text = format_live(
        session["ring_name"],
        state,
    )

    try:
        await telegram_app.bot.edit_message_text(
            chat_id=session["chat_id"],
            message_id=session["message_id"],
            text=text,
            reply_markup=live_keyboard(session["ring_id"]),
        )
    except BadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            log.warning("Telegram : %s", exc)
    except RetryAfter as exc:
        log.warning("Rate limit Telegram : %s", exc.retry_after)
    except Forbidden:
        log.warning("Bot bloqué / chat interdit")
    except Exception:
        log.exception("Erreur refresh LIVE")



# ============================================================
# NOTIFICATIONS TELEGRAM
# ============================================================

def is_global_admin(telegram_id):
    try:
        return int(telegram_id) in TELEGRAM_ADMIN_IDS
    except Exception:
        return False


async def send_assignment_notification_bot(
    bot_api,
    *,
    chat_id,
    ring_id,
    ring_name,
    mac,
    first_name=None,
):
    hello = f" {first_name}" if first_name else ""

    text = (
        f"✅ Nouvelle bague affectée / New ring assigned{hello}\n\n"
        f"💍 {ring_name}\n"
        f"📡 MAC : {mac}\n\n"
        "La bague est maintenant affectée à ton compte.\n"
        "The ring is now assigned to your account."
    )

    markup = InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(
                "💍 Ouvrir la bague / Open ring",
                callback_data=f"ring:{ring_id}",
            )
        ]]
    )

    await bot_api.send_message(
        chat_id=int(chat_id),
        text=text,
        reply_markup=markup,
    )


async def send_unassignment_notification_bot(
    bot_api,
    *,
    chat_id,
    ring_name,
    mac,
):
    await bot_api.send_message(
        chat_id=int(chat_id),
        text=(
            "ℹ️ Bague désaffectée / Ring unassigned\n\n"
            f"💍 {ring_name}\n"
            f"📡 MAC : {mac}\n\n"
            "Cette bague n'est plus affectée à ton compte.\n"
            "This ring is no longer assigned to your account."
        ),
    )



def schedule_clear_outside_alerts(ring_id):
    """
    Supprime du chat les anciens messages HORS PORTÉE de cette bague
    dès que la bague redevient ONLINE.
    """
    if telegram_loop is None or telegram_app is None:
        return

    asyncio.run_coroutine_threadsafe(
        clear_outside_alerts(
            ring_id
        ),
        telegram_loop,
    )


async def clear_outside_alerts(ring_id):
    ring_id = int(ring_id)

    with outside_alert_messages_lock:
        targets = [
            (
                chat_id,
                message_id,
            )
            for (
                rid,
                chat_id,
            ), message_id
            in outside_alert_messages.items()
            if rid == ring_id
        ]

    for chat_id, message_id in targets:
        try:
            await telegram_app.bot.delete_message(
                chat_id=int(chat_id),
                message_id=int(message_id),
            )

        except BadRequest as exc:
            # Message déjà supprimé / trop ancien / introuvable :
            # on nettoie quand même notre cache.
            log.info(
                "Suppression warning HORS PORTEE chat=%s msg=%s : %s",
                chat_id,
                message_id,
                exc,
            )

        except Forbidden:
            log.warning(
                "Suppression warning impossible, bot bloqué chat=%s",
                chat_id,
            )

        except Exception:
            log.exception(
                "Erreur suppression warning HORS PORTEE chat=%s",
                chat_id,
            )

        finally:
            with outside_alert_messages_lock:
                outside_alert_messages.pop(
                    (
                        ring_id,
                        int(chat_id),
                    ),
                    None,
                )


def schedule_outside_alert(
    ring_id,
    ring_name,
    payload,
):
    if telegram_loop is None or telegram_app is None:
        return

    asyncio.run_coroutine_threadsafe(
        send_outside_alert(
            ring_id,
            ring_name,
            payload,
        ),
        telegram_loop,
    )


async def send_outside_alert(
    ring_id,
    ring_name,
    payload,
):
    try:
        recipients = get_alert_chat_ids(
            ring_id
        )

        if not recipients:
            return

        reason = (
            payload.get("fault_code")
            or payload.get("reason")
            or "device_out_of_range"
        )

        timestamp = (
            payload.get("timestamp")
            or datetime.now(
                timezone.utc
            ).isoformat()
        )

        text = (
            f"⚠️ {ring_name}\n\n"
            "🟡 HORS PORTÉE / OUT OF RANGE\n"
            f"Code : {reason}\n"
            f"Timestamp : {fmt_time(timestamp)}"
        )

        for chat_id in recipients:
            try:
                sent = await telegram_app.bot.send_message(
                    chat_id=int(chat_id),
                    text=text,
                )

                # Mémoriser le message pour pouvoir le retirer
                # automatiquement dès le retour ONLINE.
                with outside_alert_messages_lock:
                    previous_message_id = (
                        outside_alert_messages.get(
                            (
                                int(ring_id),
                                int(chat_id),
                            )
                        )
                    )

                    outside_alert_messages[
                        (
                            int(ring_id),
                            int(chat_id),
                        )
                    ] = sent.message_id

                # Si un vieux warning de la même bague existait encore,
                # essayer de le supprimer pour éviter les doublons.
                if (
                    previous_message_id
                    and previous_message_id
                    != sent.message_id
                ):
                    try:
                        await telegram_app.bot.delete_message(
                            chat_id=int(chat_id),
                            message_id=int(previous_message_id),
                        )
                    except Exception:
                        pass
            except Forbidden:
                log.warning(
                    "Alerte hors portée impossible : "
                    "bot bloqué chat=%s",
                    chat_id,
                )
            except Exception:
                log.exception(
                    "Erreur alerte outside chat=%s",
                    chat_id,
                )

    except Exception:
        log.exception(
            "Erreur préparation alerte hors portée"
        )


async def notify_pairing_admins(
    context,
    request_row,
    tg_user,
):
    if not TELEGRAM_ADMIN_IDS:
        log.warning(
            "Demande QR créée mais TELEGRAM_ADMIN_IDS est vide"
        )
        return

    user_label = (
        f"{tg_user.first_name or ''} "
        f"{tg_user.last_name or ''}"
    ).strip()

    if tg_user.username:
        user_label += f" (@{tg_user.username})"

    text = (
        "🔗 Nouvelle demande d'appariement / "
        "New pairing request\n\n"
        f"👤 {user_label or tg_user.id}\n"
        f"Telegram ID : {tg_user.id}\n\n"
        f"💍 {request_row['ring_name']}\n"
        f"📡 MAC : {request_row['mac']}\n\n"
        "Autoriser cette affectation ? / "
        "Approve this assignment?"
    )

    markup = InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(
                "✅ Autoriser / Approve",
                callback_data=(
                    f"pairapprove:"
                    f"{request_row['request_id']}"
                ),
            ),
            InlineKeyboardButton(
                "❌ Refuser / Reject",
                callback_data=(
                    f"pairreject:"
                    f"{request_row['request_id']}"
                ),
            ),
        ]]
    )

    for admin_id in sorted(
        TELEGRAM_ADMIN_IDS
    ):
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=text,
                reply_markup=markup,
            )
        except Exception:
            log.exception(
                "Impossible de notifier admin %s",
                admin_id,
            )


# ============================================================
# Telegram handlers
# ============================================================

async def private_only(update):
    if not TELEGRAM_PRIVATE_ONLY:
        return True

    chat = update.effective_chat
    if chat and chat.type != ChatType.PRIVATE:
        if update.callback_query:
            await update.callback_query.answer(
                "Utilise le bot en message privé.",
                show_alert=True,
            )
        elif update.effective_message:
            await update.effective_message.reply_text(
                "Utilise le bot en message privé."
            )
        return False

    return True


def rings_keyboard(rings):
    rows = [
        [
            InlineKeyboardButton(
                f"💍 {r['ring_name']}",
                callback_data=f"ring:{r['ring_id']}",
            )
        ]
        for r in rings
    ]

    rows.append(
        [InlineKeyboardButton("🔄 Actualiser", callback_data="rings")]
    )
    return InlineKeyboardMarkup(rows)


def ring_keyboard(access):
    buttons = []

    if access["can_live"]:
        buttons.append(
            InlineKeyboardButton(
                "📡 LIVE",
                callback_data=f"live:{access['ring_id']}",
            )
        )

    if access["can_view_history"]:
        buttons.append(
            InlineKeyboardButton(
                "📊 HISTORIQUE",
                callback_data=f"history:{access['ring_id']}",
            )
        )

    rows = []

    if buttons:
        rows.append(buttons)

    # Mini App Telegram :
    # l'URL ne contient que la MAC comme identifiant de bague.
    # L'autorisation réelle est vérifiée côté Flask avec initData signé.
    if (
        TELEGRAM_WEBAPP_BASE_URL
        and access.get("can_view")
    ):
        mac_key = (
            str(access.get("mac") or "")
            .replace(":", "")
            .replace("-", "")
            .lower()
        )

        if len(mac_key) == 12:
            rows.append(
                [
                    InlineKeyboardButton(
                        "🌐 VUE WEB / WEB APP",
                        web_app=WebAppInfo(
                            url=(
                                f"{TELEGRAM_WEBAPP_BASE_URL}"
                                f"/webapp/ring/{mac_key}"
                            )
                        ),
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅️ Mes rings",
                callback_data="rings",
            )
        ]
    )

    return InlineKeyboardMarkup(rows)


def history_metric_keyboard(ring_id):
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "❤️ HR",
                    callback_data=(
                        f"histmetric:{ring_id}:heart_rate"
                    ),
                ),
                InlineKeyboardButton(
                    "🫁 SpO₂",
                    callback_data=(
                        f"histmetric:{ring_id}:spo2"
                    ),
                ),
            ],
            [
                InlineKeyboardButton(
                    "⚡ Fatigue",
                    callback_data=(
                        f"histmetric:{ring_id}:fatigue"
                    ),
                ),
                InlineKeyboardButton(
                    "🩺 Health",
                    callback_data=(
                        f"histmetric:{ring_id}:health_check"
                    ),
                ),
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Ring",
                    callback_data=f"ring:{ring_id}",
                )
            ],
        ]
    )


def history_period_keyboard(
    ring_id,
    metric,
):
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "1 h",
                    callback_data=(
                        f"histperiod:{ring_id}:"
                        f"{metric}:1"
                    ),
                ),
                InlineKeyboardButton(
                    "24 h",
                    callback_data=(
                        f"histperiod:{ring_id}:"
                        f"{metric}:24"
                    ),
                ),
            ],
            [
                InlineKeyboardButton(
                    "7 jours",
                    callback_data=(
                        f"histperiod:{ring_id}:"
                        f"{metric}:168"
                    ),
                ),
                InlineKeyboardButton(
                    "30 jours",
                    callback_data=(
                        f"histperiod:{ring_id}:"
                        f"{metric}:720"
                    ),
                ),
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Capteurs / Sensors",
                    callback_data=(
                        f"history:{ring_id}"
                    ),
                )
            ],
        ]
    )


def history_result_keyboard(
    ring_id,
    metric,
):
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "⏱ Autre durée / Other period",
                    callback_data=(
                        f"histmetric:{ring_id}:"
                        f"{metric}"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Capteurs / Sensors",
                    callback_data=(
                        f"history:{ring_id}"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Ring",
                    callback_data=f"ring:{ring_id}",
                )
            ],
        ]
    )


HISTORY_METRIC_LABEL = {
    "heart_rate": "❤️ Rythme Cardiaque (HR)",
    "spo2": "🫁 SpO₂",
    "fatigue": "⚡ Fatigue",
    "health_check": "🩺 Health-check",
}


def format_metric_history(
    ring_name,
    metric,
    rows,
    hours,
):
    period = {
        1: "1 heure / 1 hour",
        24: "24 heures / 24 hours",
        168: "7 jours / 7 days",
        720: "30 jours / 30 days",
    }.get(
        int(hours),
        f"{hours} h",
    )

    label = HISTORY_METRIC_LABEL.get(
        metric,
        metric,
    )

    lines = [
        f"📊 {ring_name}",
        label,
        f"Période / Period : {period}",
        "",
    ]

    if not rows:
        lines.append(
            "Aucune donnée / No data."
        )
        return "\n".join(lines)

    # Telegram a une limite de taille.
    # 35 lignes de mesures gardent le message confortable.
    for row in rows[:35]:
        status = str(
            row.get("status") or ""
        ).lower()

        timestamp = fmt_time(
            row.get("time")
        )

        samples = row.get("samples")
        unit = row.get("unit") or ""

        if status == "ok":
            value_txt = (
                fmt_samples(samples)
                if samples
                else fmt_num(
                    row.get("value")
                )
            )

            lines.extend(
                [
                    f"🕒 {timestamp}",
                    f"Valeur : {value_txt}",
                ]
            )

            if unit:
                lines.append(
                    f"Unité : {unit}"
                )

        else:
            lines.extend(
                [
                    f"🕒 {timestamp}",
                    f"Statut : {status or '—'}",
                ]
            )

            if row.get("reason"):
                lines.append(
                    "Raison / Reason : "
                    f"{row['reason']}"
                )

        lines.append("")

    if len(rows) > 35:
        lines.append(
            f"… {len(rows) - 35} autres mesures "
            "non affichées / more records hidden."
        )

    return "\n".join(lines).strip()


async def start_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not await private_only(update):
        return

    user = update.effective_user

    if update.effective_chat:
        clear_ring_overview_sessions(
            update.effective_chat.id
        )

        # /start signifie que l'utilisateur quitte l'écran LIVE.
        await stop_live_sessions_for_chat(
            update.effective_chat.id,
            bot=context.bot,
        )

    try:
        register_user_from_start(user)

    except Exception as exc:
        log.exception("Erreur /start DB")

        await update.effective_message.reply_text(
            f"⚠️ Erreur PostgreSQL : {exc}"
        )
        return

    # --------------------------------------------------------
    # QR DEEP LINK :
    # https://t.me/BOT?start=pair_<token>
    # --------------------------------------------------------
    start_arg = (
        context.args[0]
        if context.args
        else ""
    )

    if start_arg.startswith("pair_"):
        token = start_arg[len("pair_"):]

        try:
            result = create_pairing_request(
                user.id,
                token,
            )

        except Exception as exc:
            log.exception(
                "Erreur demande QR"
            )
            await update.effective_message.reply_text(
                "⚠️ Erreur lors de la demande "
                "d'appariement / Pairing request error.\n"
                f"{exc}"
            )
            return

        status = result.get("status")

        if status == "invalid":
            await update.effective_message.reply_text(
                "❌ QR invalide ou expiré / "
                "Invalid or expired QR code."
            )
            return

        if status == "already_assigned":
            await update.effective_message.reply_text(
                "✅ Cette bague est déjà affectée "
                "à ton compte / This ring is already "
                "assigned to your account.\n\n"
                f"💍 {result['ring_name']}"
            )
            return

        if status == "already_pending":
            await update.effective_message.reply_text(
                "⏳ Une demande est déjà en attente / "
                "A pairing request is already pending.\n\n"
                f"💍 {result['ring_name']}"
            )
            return

        await update.effective_message.reply_text(
            "📲 Demande d'appariement reçue / "
            "Pairing request received\n\n"
            f"💍 {result['ring_name']}\n"
            f"📡 MAC : {result['mac']}\n\n"
            "La demande a été envoyée à l'administrateur.\n"
            "The request was sent to the administrator."
        )

        await notify_pairing_admins(
            context,
            result,
            user,
        )
        return

    rings = get_accessible_rings(
        user.id
    )

    if not rings:
        await update.effective_message.reply_text(
            "✅ Connexion Telegram enregistrée / "
            "Telegram connection registered.\n\n"
            "Aucune bague ne t'est encore affectée.\n"
            "No ring is assigned to your account yet.\n\n"
            "Tu peux aussi scanner le QR de la bague "
            "pour demander son appariement.\n"
            "You can also scan the ring QR code "
            "to request pairing."
        )
        return

    await update.effective_message.reply_text(
        "💍 DANY — Mes rings / My rings",
        reply_markup=rings_keyboard(
            rings
        ),
    )


async def rings_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not await private_only(update):
        return

    user = update.effective_user

    if update.effective_chat:
        clear_ring_overview_sessions(
            update.effective_chat.id
        )

        # Aller vers "Mes rings" ferme toute session LIVE de ce chat.
        await stop_live_sessions_for_chat(
            update.effective_chat.id,
            bot=context.bot,
        )

    rings = get_accessible_rings(
        user.id
    )

    text = (
        "💍 Mes rings / My rings"
        if rings
        else (
            "Aucune bague affectée / "
            "No ring assigned."
        )
    )

    markup = (
        rings_keyboard(rings)
        if rings
        else None
    )

    if update.callback_query:
        await update.callback_query.answer()

        await update.callback_query.edit_message_text(
            text,
            reply_markup=markup,
        )

    else:
        await update.effective_message.reply_text(
            text,
            reply_markup=markup,
        )


async def callback_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not await private_only(update):
        return

    q = update.callback_query
    user = update.effective_user
    data = q.data or ""

    # Le clic signifie que l'utilisateur quitte éventuellement
    # l'écran Ring précédent. On stoppe son auto-refresh avant
    # de changer le contenu du message.
    if q.message:
        clear_ring_overview_sessions(
            q.message.chat_id
        )

    # --------------------------------------------------------
    # ADMIN : APPROBATION QR
    # --------------------------------------------------------
    if data.startswith("pairapprove:"):
        if not is_global_admin(user.id):
            await q.answer(
                "Admin uniquement / Admin only.",
                show_alert=True,
            )
            return

        await q.answer()

        request_id = int(
            data.split(":", 1)[1]
        )

        try:
            row = approve_pairing_request(
                request_id,
                user.id,
            )

            if not row:
                await q.edit_message_text(
                    "❌ Demande introuvable / "
                    "Request not found."
                )
                return

            if row.get("result") == "already_decided":
                await q.edit_message_text(
                    "ℹ️ Demande déjà traitée / "
                    "Request already processed."
                )
                return

            await q.edit_message_text(
                "✅ Appariement autorisé / "
                "Pairing approved\n\n"
                f"💍 {row['ring_name']}\n"
                f"👤 Telegram ID : {row['id_telegram']}"
            )

            try:
                await send_assignment_notification_bot(
                    context.bot,
                    chat_id=row["id_telegram"],
                    ring_id=row["ring_id"],
                    ring_name=row["ring_name"],
                    mac=row["mac"],
                    first_name=row.get(
                        "firstname"
                    ),
                )
            except Exception:
                log.exception(
                    "Notification affectation QR impossible"
                )

        except Exception as exc:
            log.exception(
                "Erreur approbation QR"
            )
            await q.edit_message_text(
                "⚠️ Erreur / Error : "
                f"{exc}"
            )

        return

    # --------------------------------------------------------
    # ADMIN : REFUS QR
    # --------------------------------------------------------
    if data.startswith("pairreject:"):
        if not is_global_admin(user.id):
            await q.answer(
                "Admin uniquement / Admin only.",
                show_alert=True,
            )
            return

        await q.answer()

        request_id = int(
            data.split(":", 1)[1]
        )

        try:
            row = reject_pairing_request(
                request_id,
                user.id,
            )

            if not row:
                await q.edit_message_text(
                    "❌ Demande introuvable / "
                    "Request not found."
                )
                return

            if row.get("result") == "already_decided":
                await q.edit_message_text(
                    "ℹ️ Demande déjà traitée / "
                    "Request already processed."
                )
                return

            await q.edit_message_text(
                "❌ Appariement refusé / "
                "Pairing rejected\n\n"
                f"💍 {row['ring_name']}"
            )

            try:
                await context.bot.send_message(
                    chat_id=int(
                        row["id_telegram"]
                    ),
                    text=(
                        "❌ Demande d'appariement refusée / "
                        "Pairing request rejected\n\n"
                        f"💍 {row['ring_name']}\n"
                        f"📡 MAC : {row['mac']}"
                    ),
                )
            except Exception:
                log.exception(
                    "Notification refus QR impossible"
                )

        except Exception as exc:
            log.exception(
                "Erreur refus QR"
            )
            await q.edit_message_text(
                f"⚠️ Erreur / Error : {exc}"
            )

        return

    if data == "rings":
        await rings_handler(
            update,
            context,
        )
        return

    if data.startswith("ring:"):
        await q.answer()

        ring_id = int(
            data.split(":")[1]
        )

        # Retour volontaire vers l'écran de la bague :
        # la session LIVE de cette bague est terminée.
        await stop_live_sessions_for_chat(
            q.message.chat_id,
            ring_id=ring_id,
            bot=context.bot,
        )

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if not access:
            await q.edit_message_text(
                "⛔ Accès refusé / Access denied."
            )
            return

        state = seed_live_state_from_db(
            ring_id
        )

        await q.edit_message_text(
            format_ring_overview(
                access,
                state,
            ),
            reply_markup=ring_keyboard(
                access
            ),
        )

        register_ring_overview_session(
            chat_id=q.message.chat_id,
            message_id=q.message.message_id,
            access=access,
        )

        return

    if data.startswith("live:"):
        await q.answer()

        ring_id = int(
            data.split(":")[1]
        )

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if (
            not access
            or not access["can_live"]
        ):
            await q.answer(
                "LIVE non autorisé / "
                "LIVE not allowed.",
                show_alert=True,
            )
            return

        state = seed_live_state_from_db(
            ring_id
        )

        await q.edit_message_text(
            format_live(
                access["ring_name"],
                state,
            ),
            reply_markup=live_keyboard(
                ring_id
            ),
        )

        session = {
            "telegram_user_id":
                int(
                    access[
                        "telegram_user_id"
                    ]
                ),
            "ring_id": ring_id,
            "ring_name":
                access["ring_name"],
            "chat_id":
                int(q.message.chat_id),
            "message_id":
                int(q.message.message_id),
            "last_edit": 0.0,
            "expires_at":
                time.time()
                + LIVE_SESSION_MINUTES
                * 60,
            "warning_sent": False,
        }

        with live_sessions_lock:
            live_sessions[
                (
                    session["chat_id"],
                    ring_id,
                )
            ] = session

        db_start_live_session(
            session["telegram_user_id"],
            ring_id,
            session["chat_id"],
            session["message_id"],
        )
        return


    if data.startswith("refreshlive:"):
        ring_id = int(
            data.split(":")[1]
        )

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if (
            not access
            or not access["can_live"]
        ):
            await q.answer(
                "LIVE non autorisé / LIVE not allowed.",
                show_alert=True,
            )
            return

        try:
            # Resynchronisation DB + cache LIVE.
            state = seed_live_state_from_db(
                ring_id
            )

            try:
                await q.edit_message_text(
                    format_live(
                        access["ring_name"],
                        state,
                    ),
                    reply_markup=live_keyboard(
                        ring_id
                    ),
                )

            except BadRequest as exc:
                # Si le contenu n'a pas changé, le refresh a quand même réussi.
                if (
                    "message is not modified"
                    not in str(exc).lower()
                ):
                    raise

            await q.answer(
                "✅ LIVE actualisé / LIVE refreshed",
                show_alert=True,
            )

        except Exception as exc:
            log.exception(
                "Erreur refresh manuel LIVE"
            )

            await q.answer(
                "⚠️ Actualisation impossible / Refresh failed\n"
                f"{exc}",
                show_alert=True,
            )

        return


    if data.startswith("extendlive:"):
        ring_id = int(
            data.split(":")[1]
        )

        key = (
            int(q.message.chat_id),
            ring_id,
        )

        warning_message_id = None

        with live_sessions_lock:
            session = live_sessions.get(
                key
            )

            if session:
                warning_message_id = session.pop(
                    "warning_message_id",
                    None,
                )

                session["expires_at"] = (
                    time.time()
                    + LIVE_SESSION_MINUTES
                    * 60
                )
                session["warning_sent"] = False

        if warning_message_id:
            try:
                await context.bot.delete_message(
                    chat_id=q.message.chat_id,
                    message_id=warning_message_id,
                )
            except Exception:
                pass

        if not session:
            await q.answer(
                "LIVE déjà arrêté / LIVE already stopped.",
                show_alert=True,
            )
            return

        try:
            db_extend_live_session(
                session[
                    "telegram_user_id"
                ],
                ring_id,
                session["chat_id"],
                LIVE_SESSION_MINUTES,
            )

        except Exception:
            log.exception(
                "Erreur prolongation LIVE DB"
            )

        try:
            await q.edit_message_text(
                "✅ LIVE prolongé / LIVE extended\n\n"
                f"+ {LIVE_SESSION_MINUTES} min"
            )

        except Exception:
            pass

        await q.answer(
            (
                "✅ LIVE prolongé de "
                f"{LIVE_SESSION_MINUTES} min / "
                "LIVE extended"
            ),
            show_alert=True,
        )

        return


    if data.startswith("stoplive:"):
        await q.answer()

        ring_id = int(
            data.split(":")[1]
        )

        await stop_live_sessions_for_chat(
            q.message.chat_id,
            ring_id=ring_id,
            bot=context.bot,
        )

        await q.edit_message_text(
            "⏹ LIVE arrêté / LIVE stopped.",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "⬅️ Ring",
                        callback_data=(
                            f"ring:{ring_id}"
                        ),
                    )
                ]]
            ),
        )
        return

    # --------------------------------------------------------
    # HISTORIQUE : capteur puis durée
    # --------------------------------------------------------
    if data.startswith("history:"):
        await q.answer()

        ring_id = int(
            data.split(":")[1]
        )

        # Passer du LIVE à l'historique est une sortie volontaire du LIVE.
        await stop_live_sessions_for_chat(
            q.message.chat_id,
            ring_id=ring_id,
            bot=context.bot,
        )

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if (
            not access
            or not access[
                "can_view_history"
            ]
        ):
            await q.answer(
                "Historique non autorisé / "
                "History not allowed.",
                show_alert=True,
            )
            return

        await q.edit_message_text(
            f"📊 Historique — "
            f"{access['ring_name']}\n"
            "Choisis le capteur / "
            "Choose sensor:",
            reply_markup=
                history_metric_keyboard(
                    ring_id
                ),
        )
        return

    if data.startswith("histmetric:"):
        await q.answer()

        _, ring_raw, metric = (
            data.split(":", 2)
        )

        ring_id = int(ring_raw)

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if (
            not access
            or not access[
                "can_view_history"
            ]
        ):
            await q.answer(
                "Historique non autorisé / "
                "History not allowed.",
                show_alert=True,
            )
            return

        label = HISTORY_METRIC_LABEL.get(
            metric,
            metric,
        )

        await q.edit_message_text(
            f"📊 {access['ring_name']}\n"
            f"{label}\n\n"
            "Choisis la durée / "
            "Choose period:",
            reply_markup=
                history_period_keyboard(
                    ring_id,
                    metric,
                ),
        )
        return

    if data.startswith("histperiod:"):
        await q.answer()

        _, ring_raw, metric, hours_raw = (
            data.split(":", 3)
        )

        ring_id = int(ring_raw)
        hours = int(hours_raw)

        access = get_ring_access(
            user.id,
            ring_id,
        )

        if (
            not access
            or not access[
                "can_view_history"
            ]
        ):
            await q.answer(
                "Historique non autorisé / "
                "History not allowed.",
                show_alert=True,
            )
            return

        rows = get_metric_history(
            ring_id,
            metric,
            hours,
        )

        await q.edit_message_text(
            format_metric_history(
                access["ring_name"],
                metric,
                rows,
                hours,
            ),
            reply_markup=
                history_result_keyboard(
                    ring_id,
                    metric,
                ),
        )
        return

    await q.answer(
        "Commande inconnue / Unknown command."
    )


async def status_handler(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not await private_only(update):
        return

    try:
        row = db_healthcheck()

        await update.effective_message.reply_text(
            "✅ DANY Telegram Bot\n"
            f"PostgreSQL : OK ({row['db']})\n"
            f"Utilisateur DB : {row['usr']}\n"
            f"MQTT : {MQTT_HOST}:{MQTT_PORT}\n"
            f"Topic : {MQTT_TOPIC}\n"
            f"Admins : {len(TELEGRAM_ADMIN_IDS)}"
        )

    except Exception as exc:
        await update.effective_message.reply_text(
            f"⚠️ PostgreSQL : {exc}"
        )



async def cleanup_live_sessions(
    context: ContextTypes.DEFAULT_TYPE,
):
    """
    Contrôle périodique des sessions LIVE.

    - < LIVE_WARNING_MINUTES : une notification UNE seule fois.
    - expiration : arrêt du LIVE.
    - HORS PORTEE ne ferme jamais le LIVE.
    """
    now = time.time()
    warning_seconds = (
        LIVE_WARNING_MINUTES
        * 60
    )

    warnings = []
    expired = []

    with live_sessions_lock:
        for key, session in list(
            live_sessions.items()
        ):
            remaining = (
                session["expires_at"]
                - now
            )

            if remaining <= 0:
                expired.append(
                    (
                        key,
                        dict(session),
                    )
                )
                continue

            if (
                remaining
                <= warning_seconds
                and not session.get(
                    "warning_sent",
                    False,
                )
            ):
                # Marquer avant envoi pour éviter plusieurs warnings.
                session["warning_sent"] = True

                warnings.append(
                    (
                        key,
                        dict(session),
                        remaining,
                    )
                )

    # --------------------------------------------------------
    # WARNING LIVE
    # --------------------------------------------------------
    for key, session, remaining in warnings:
        try:
            mins = max(
                1,
                int(
                    remaining // 60
                )
            )

            # Re-vérifier juste avant l'envoi :
            # l'utilisateur a peut-être quitté LIVE entre le scan
            # des sessions et ce point.
            with live_sessions_lock:
                still_active = (
                    key in live_sessions
                )

            if not still_active:
                continue

            sent_warning = await context.bot.send_message(
                chat_id=
                    session["chat_id"],
                text=(
                    "⚠️ LIVE bientôt arrêté / "
                    "LIVE ending soon\n\n"
                    f"💍 {session['ring_name']}\n\n"
                    "Le LIVE s'arrêtera automatiquement "
                    f"dans moins de {LIVE_WARNING_MINUTES} minutes.\n"
                    "The LIVE will stop automatically "
                    f"in less than {LIVE_WARNING_MINUTES} minutes.\n\n"
                    f"Temps restant approximatif / "
                    f"Approx. remaining: {mins} min"
                ),
                reply_markup=
                    InlineKeyboardMarkup(
                        [[
                            InlineKeyboardButton(
                                (
                                    "🔄 Prolonger "
                                    f"{LIVE_SESSION_MINUTES} min / "
                                    "Extend"
                                ),
                                callback_data=(
                                    f"extendlive:"
                                    f"{session['ring_id']}"
                                ),
                            )
                        ]]
                    ),
            )

            # Mémoriser le warning uniquement si LIVE est encore actif.
            # Si l'utilisateur a quitté LIVE pendant l'appel Telegram,
            # supprimer immédiatement le warning qui vient d'être envoyé.
            delete_immediately = False

            with live_sessions_lock:
                current = live_sessions.get(
                    key
                )

                if current:
                    current[
                        "warning_message_id"
                    ] = sent_warning.message_id
                else:
                    delete_immediately = True

            if delete_immediately:
                try:
                    await context.bot.delete_message(
                        chat_id=
                            session["chat_id"],
                        message_id=
                            sent_warning.message_id,
                    )
                except Exception:
                    pass

        except Exception:
            log.exception(
                "Erreur warning fin LIVE"
            )

    # --------------------------------------------------------
    # EXPIRATION
    # --------------------------------------------------------
    for key, session in expired:
        with live_sessions_lock:
            live_sessions.pop(
                key,
                None,
            )

        try:
            db_stop_live_session(
                session[
                    "telegram_user_id"
                ],
                session["ring_id"],
                session["chat_id"],
            )

        except Exception:
            log.exception(
                "Erreur stop session DB"
            )

        try:
            await context.bot.edit_message_text(
                chat_id=
                    session["chat_id"],
                message_id=
                    session["message_id"],
                text=(
                    "⏹ LIVE arrêté automatiquement / "
                    "LIVE stopped automatically after "
                    f"{LIVE_SESSION_MINUTES} min."
                ),
            )

        except Exception:
            pass

# ============================================================
# MAIN
# ============================================================

async def post_init(app):
    global telegram_loop

    telegram_loop = asyncio.get_running_loop()
    log.info("Telegram bot prêt")


def validate_config():
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN absent du fichier .env"
        )

    if not DB_USER:
        raise RuntimeError(
            "DB_USER absent du fichier .env"
        )


def main():
    global telegram_app

    validate_config()

    health = db_healthcheck()

    log.info(
        "PostgreSQL OK : db=%s user=%s",
        health["db"],
        health["usr"],
    )

    if not TELEGRAM_ADMIN_IDS:
        log.warning(
            "TELEGRAM_ADMIN_IDS vide : "
            "les demandes QR seront enregistrées "
            "mais aucun admin ne recevra les boutons."
        )

    mqtt_client = start_mqtt()

    telegram_app = (
        Application.builder()
        .token(TELEGRAM_BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    telegram_app.add_handler(
        CommandHandler(
            "start",
            start_handler,
        )
    )

    telegram_app.add_handler(
        CommandHandler(
            "rings",
            rings_handler,
        )
    )

    telegram_app.add_handler(
        CommandHandler(
            "status",
            status_handler,
        )
    )

    telegram_app.add_handler(
        CallbackQueryHandler(
            callback_handler
        )
    )

    if telegram_app.job_queue:
        telegram_app.job_queue.run_repeating(
            cleanup_live_sessions,
            interval=60,
            first=60,
        )

    try:
        telegram_app.run_polling(
            allowed_updates=
                Update.ALL_TYPES,
        )

    finally:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()


if __name__ == "__main__":
    main()
