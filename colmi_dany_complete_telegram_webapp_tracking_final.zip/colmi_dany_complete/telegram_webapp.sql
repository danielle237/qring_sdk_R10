-- ============================================================
-- DANY / COLMI - TELEGRAM MINI APP / WEB APP TRACKING
-- PostgreSQL migration
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS telegram_webapp_sessions (
    id BIGSERIAL PRIMARY KEY,

    session_token VARCHAR(128) NOT NULL UNIQUE,

    telegram_user_id BIGINT NOT NULL
        REFERENCES t_user_app_telegram(id) ON DELETE CASCADE,

    ring_id BIGINT NOT NULL
        REFERENCES rings(id) ON DELETE CASCADE,

    opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ NULL,

    active BOOLEAN NOT NULL DEFAULT TRUE,

    telegram_auth_date TIMESTAMPTZ NULL,
    telegram_query_id TEXT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_telegram_webapp_sessions_last_seen
ON telegram_webapp_sessions(last_seen_at DESC);

CREATE INDEX IF NOT EXISTS ix_telegram_webapp_sessions_user
ON telegram_webapp_sessions(telegram_user_id, opened_at DESC);

CREATE INDEX IF NOT EXISTS ix_telegram_webapp_sessions_ring
ON telegram_webapp_sessions(ring_id, opened_at DESC);

CREATE INDEX IF NOT EXISTS ix_telegram_webapp_sessions_active
ON telegram_webapp_sessions(active, last_seen_at DESC);


CREATE TABLE IF NOT EXISTS telegram_webapp_events (
    id BIGSERIAL PRIMARY KEY,

    session_id BIGINT NOT NULL
        REFERENCES telegram_webapp_sessions(id) ON DELETE CASCADE,

    event_type VARCHAR(32) NOT NULL
        CHECK (
            event_type IN (
                'OPEN',
                'CLOSE'
            )
        ),

    event_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_telegram_webapp_events_session
ON telegram_webapp_events(session_id, event_at DESC);

COMMIT;
